## ⚙️ KOLEJNOŚĆ AKTUALIZACJI REJESTRÓW (przyjęta 2026-09-10e)

Rejestry aktów żyją w trzech warstwach: **moduł DR → lokalna `MAPA-AKTOW` →
`ROUTING-MAP` (ta mapa) → `audyt-systemu-v4/references/mapa_dzu_*.md`**.
Kierunek *autorytetu* biegnie w dół — moduł jest miejscem, gdzie akt naprawdę
pracuje. Kierunek *pracy aktualizacyjnej* biegnie odwrotnie:

```
1. Rozstrzygnij w ŹRÓDLE URZĘDOWYM (RZĄD 1, ELI po adresie)
2. Zamknij pozycje oznaczone jako wymagające weryfikacji w tej mapie
3. Zapisz stan w ROUTING-MAP i mapie centralnej — JEDEN zweryfikowany numer
4. Dopiero potem wyrównaj moduły DR do tego stanu (ZASADA 8)
```

⛔ **Dlaczego nie odwrotnie.** Szesnaście map dziedzinowych aktualizowanych
niezależnie rozjeżdża się szybciej, niż testy to wychwytują, a T11 widzi
wyłącznie *rozbieżność między rejestrami*, nie *błąd wpisany zgodnie wszędzie*
(F-82). Jeden zweryfikowany punkt odniesienia, do którego wyrównuje się moduły,
zamyka tę klasę rozjazdów u źródła.

⛔ **Czego ta kolejność NIE znosi.** ROUTING-MAP **nigdy nie staje się źródłem
weryfikacji**. Każdy numer rozstrzyga się osobno w ELI, także wtedy, gdy stoi
już w tej mapie — zapis F-141 („NIE domykać propagacją z map lokalnych")
obowiązuje w obie strony. Propagacja przenosi *rozstrzygnięcie*, nie zastępuje
go: wpisanie do modułu numeru przepisanego z tej mapy bez odczytu u źródła jest
tym samym błędem, co przepisanie w przeciwnym kierunku.

⚠️ Wyjątek: gdy błąd wykryto **w module** (jak przy F-148a — dwie podmiany
aktu), rozstrzygnięcie zaczyna się tam, gdzie go znaleziono, a wyrównanie idzie
w obie strony w tej samej sesji.

---

## ORKA-BAS — Leksykon Definicji Ministerialnych (GLOBAL)

*Źródło: interpelacje poselskie VII–X kadencji + metareguły ORKA-REG + audyt praktyki*
*Pliki: shared/ORKA-BAS-LEKSYKON.md (104 rekordy) + shared/ORKA-BAS-VIII-X-KADENCJA.md (25 rekordów)*
*Każdy DR-skill ma teraz własną sekcję "ORKA-BAS — Definicje wspomagające" w SKILL.md*
*z listą rekordów dedykowanych tej dziedzinie — router NIE musi przeszukiwać całości.*

| DR-skill | Liczba dedykowanych BAS | Najważniejsze hasła |
|---|---|---|
| DR-01 (ustrój) | 1 (pomocniczy) | właściwość sądu (W31) |
| DR-02 (cywilne/rodzinne) | 15 | zasiedzenie, hipoteka, BW, szkoda/lucrum cessans, terminy, kara umowna, odsetki, nakaz zapłaty |
| DR-03 (karne/wykroczenia) | 13 | recydywa, warunkowe umorzenie, zatarcie, czyn ciągły, mienie znacznej wartości, niewidomy/głuchy w KPK |
| DR-04 (praca/ZUS) | 14 | ⚠️rynek pracy (zmiana 2025), praca zdalna, mobbing, choroba zawodowa, niepełnosprawność/PFRON |
| DR-05 (administracyjne) | 7 | cel publiczny, dwuinstancyjność, informacja przetworzona, pełnomocnik z urzędu |
| DR-06 (podatki/finanse) | 21+ | VAT/PIT, ⚠️reforma upol 2025, CRU JSFP 2026, cały katalog finansów JST |
| DR-07 (PZP) | 1 | rażąco niska cena |
| DR-08 (samorząd) | 4 | mienie komunalne, pas drogowy, strefa zamieszkania, droga wewnętrzna |
| DR-09 (budownictwo) | 11 | samowola budowlana, obiekt liniowy, OZE, odbiorca wrażliwy, **PPWR / opakowania UE**, **EUDR / wylesianie / due diligence** |
| DR-10 (zdrowie) | 4 | świadczenie zdrowotne, gospodarstwo rolne, gołąb=drób |
| DR-11 (RODO/cyber) | 2 | definicje RODO art.4, uzasadniony interes (LIA) |
| DR-12 (sądownictwo/zawody) | 1 | pełnomocnik/obrońca z urzędu |
| DR-13 (służby/niejawne) | 2 | żołnierz, degradacja wojskowa |
| DR-14 (UE/prawa człowieka) | 2 | gender, Konwencja ONZ art.13 |
| DR-15 (compliance) | 2 | sygnalista, uzasadniony interes RODO |
| DR-16 (pisma/dowody) | 7 | uprawdopodobnienie, szkoda, terminy, nadużycie prawa, dowody, kara umowna |

⚠️ ALERTY WYMAGAJĄCE SZCZEGÓLNEJ UWAGI ROUTERA:
  → DR-04: ✅ ustawa o promocji zatrudnienia (uchylona 01.06.2025) — definicje
    BAS-001-003/014/075 ZWERYFIKOWANE i przeniesione do Dz.U. 2025 poz. 620;
    nowość: rolnicy >2ha + "osoby bierne zawodowo"
  → DR-06: reforma upol od 01.01.2025 (nowe def. budynku/budowli, Dz.U. 2024 poz. 1757)
  → DR-06: CRU JSFP ✅ weszło w życie 01.07.2026 (brak progu kwotowego!) VER 2026-07-13: obowiązek publikacji umów w rejestrumow.gov.pl aktywny
  → DR-06: ✅ NOWY — podatek katastralny: projekt poselski Lewicy w Sejmie
    od 20.03.2026 (BAS-W08) — status VER 2026-07-13: po konsultacjach
    publicznych (zakończone ok. 22.04.2026), premier Tusk zastrzegł że to
    NIE jest projekt rządowy; brak potwierdzonego I czytania na sali plenarnej
  → DR-06: ✅ NOWY — Ordynacja podatkowa: zniesienie "wiecznego przedawnienia"
    + ugoda podatkowa od 01.10.2026 (BAS-W32 — reżim odrębny od KC!)
  → DR-06: ustawa z 27.02.2026 o zmianie UFP — wpływa na katalog BAS-022..098
  → DR-02/DR-03/DR-04: projekt likwidacji ubezwłasnowolnienia (UD80,
    instrumenty wspieranego podejmowania decyzji) — VER 2026-07-13: I czytanie
    odbyło się 17.06.2026 (60. posiedzenie Sejmu), skierowano do Komisji
    Polityki Społecznej i Rodziny oraz Komisji Sprawiedliwości i Praw
    Człowieka; nadal na etapie prac komisyjnych, nie uchwalony
  → DR-03: BAS-W23 (mienie znacznej/wielkiej wartości, art. 115 §5-6 KK)
    POTWIERDZONE zamrożone od 2010 (prawo.pl 26.08.2025) — bez nowelizacji
  → DR-04/DR-11: ⚠️⚠️ NAJWYŻSZY PRIORYTET — BAS-W36, AI Act art. 6 + Annex III
    "system wysokiego ryzyka" — TERMIN nominalnie 02.08.2026 (rekrutacja,
    ocena pracowników, decyzje o awansie/zwolnieniu przez AI). Rozporządzenie
    UE stosowane bezpośrednio, niezależnie od polskiej ustawy wdrożeniowej.
    ⚠️ VER 2026-07-13 — ZMIANA NA POZIOMIE UE (niepotwierdzona ostatecznie):
    w ramach "Digital Omnibus" Parlament Europejski zatwierdził 16.06.2026
    przesunięcie obowiązku dla samodzielnych systemów z Annex III z 02.08.2026
    na 02.12.2027 — wymaga jeszcze formalnego przyjęcia przez Radę UE, NIE
    traktować jako pewne do czasu publikacji w Dz.Urz. UE. Polska ustawa
    wdrożeniowa: przyjęta przez Radę Ministrów 31.03.2026, skierowana do
    Sejmu, I czytanie ok. końca kwietnia 2026 — dalszy status niepewny wg
    źródeł wtórnych, wymaga potwierdzenia w toku prac sejmowych

ORKA-REG-01–07 + ORKA-META-01–02: metareguły wykładni — stosuj przy KAŻDEJ
  analizie definicji sektorowej (priorytet definicji legalnej, zakaz przenoszenia
  definicji między ustawami, ocena ad casum).

---

# ROUTING-MAP — Centralna Mapa Aktów Prawnych → DR-skills
# prawo-polskie-v2 v8.8 (aktualizacja 2026-07-21p — DR-03: NOWY
# mod-czynny-zal-KK-KKS-samooskarzenie (KK art. 15, KKS art. 16-16a —
# KLUCZOWE: czynny żal to NIE tylko samo-donos; korekta terminologiczna
# "samooskarżenie" nie jest odrębną instytucją) + NOWY mod-dobrowolne-
# poddanie-sie-karze-KPK (art. 335 i 387, dwa odrębne tryby). 54 moduły
# łącznie w DR-03 (było 52).)
#
# Format: Akt prawny | Dz.U. | DR-skill | Moduł | Status
# Status: ✅ OK = moduł ZAREJESTROWANY / trasa istnieje; NIE oznacza kompletności całego aktu.\n#         Pokrycie treściowe ustala wyłącznie odpowiedni DR/MAPA-POKRYCIA.md.\n#         🔗 odesłanie = w innym DR | ☐ BRAK = brak jednostki do zbudowania
#
# BRAMKA SEMANTYCZNA STATUSU (2026-08-27):\n#   MAPA-AKTOW / ROUTING odpowiadają „gdzie jest akt?”, a MAPA-POKRYCIA „ile aktu naprawdę opracowano?”.\n#   Zakaz wnioskowania: ✅ OK w tej mapie -> pełne pokrycie.\n#\n# Zasada: jeden akt prawny = jeden wpis w tej tabeli = jeden moduł
# Wyjątek: rozdziały tego samego aktu mogą mieć osobne moduły (oznaczone w kolumnie Moduł)
#
# ═══════════════════════════════════════════════════════════════════════════════
# PROTOKÓŁ INTEGRACJI — jak dane przepływają w systemie
# ═══════════════════════════════════════════════════════════════════════════════
#
# PULL (DR → prawo-polskie → audyt):
#   Krok 1. Każdy DR-skill utrzymuje lokalną MAPA-AKTOW.md z Dz.U. i statusami.
#   Krok 2. Ta tabela jest WTÓRNA wobec DR-MAPA-AKTOW — aktualizuj ją przez
#            pull z DR-MAPA-AKTOW po każdej zmianie w DR-skill.
#   Krok 3. audyt-systemu-v4 w FAZA 3 porównuje tę tabelę z mapa_dzu_*.md
#            i flaguje rozbieżności jako WARN lub CRIT.
#
# MONITORING (nowe akty oczekujące):
#   Każdy akt z flagą ⏳ lub ⚡ w kolumnie Status pojawia się też w sekcji
#   MONITORING na końcu tego pliku ORAZ w mapa_dzu_*.md (tabela MONITORING).
#   Przy audycie DZU — sprawdź czy akt wszedł w życie i przenieś do tabeli głównej.
#
# ═══════════════════════════════════════════════════════════════════════════════

## TABELA STATUSU — SKRÓCONA WEDŁUG DR

> Historyczny snapshot liczników; nie stanowi pomiaru bieżącego pokrycia.
> Nowych modułów nie dopisuj arytmetycznie do nieprzeliczonej sumy.
> F-108/46 zarejestrowano poniżej 2026-08-27; zakres: MAPA-POKRYCIA DR-02.

| DR | Dziedzina | ✅ OK | 🔗 odesłanie | ☐ BRAK | ⏳/⚡ MON | Łącznie |
|---|---|:---:|:---:|:---:|:---:|:---:|
| DR-01 | Ustrój Konstytucyjny | 14 | 1 | 0 | 0 | 15 |
| DR-02 | Prawo Cywilne/Rodzinne/Gosp. | 19 | 1 | 0 | 0 | 20 |
| DR-03 | Prawo Karne/Wykroczenia | 16 | 0 | 0 | 2 | 18 |
| DR-04 | Prawo Pracy/ZUS/Świadczenia | 18 | 0 | 0 | 0 | 18 |
| DR-05 | Prawo Administracyjne | 13 | 2 | 0 | 0 | 15 |
| DR-06 | Podatki/Finanse/AML | 40 | 0 | 0 | 4 | 44 — ⚠️ LICZNIK NAPRAWIONY 2026-08-11v: deklarowano 21 przy rzeczywistych 32 wierszach JESZCZE PRZED tą sesją — dryf licznika istniał wcześniej i nie został wykryty przez T2 (test sprawdza liczniki modułów w SKILL.md, NIE liczniki wierszy w TABELI STATUSU ROUTING-MAP). Po dopisaniu 12 aktów rachunkowo-księgowych: 44 wierszy |
| DR-07 | Zamówienia Publiczne/Fundusze | 12 | 2 | 0 | 0 | 14 |
| DR-08 | Samorząd Terytorialny | 23 | 0 | 0 | 0 | 23 |
| DR-09 | Budownictwo/Środowisko/Energia | 29 | 0 | 0 | 2 | 31 |
| DR-10 | Zdrowie/Farmacja/Żywność | 27 | 0 | 0 | 0 | 27 |
| DR-11 | Cyfrowe/AI/Dane/IP | 20 | 0 | 0 | 0 | 20 |
| DR-12 | Sądownictwo/Zawody | 11 | 1 | 0 | 0 | 12 |
| DR-13 | Służby/Bezpieczeństwo | 16 | 1 | 0 | 0 | 17 |
| DR-14 | Prawo UE/Międzynarodowe | 18 | 0 | 0 | 0 | 18 |
| DR-15 | Compliance/ISO | 9 | 0 | 0 | 0 | 9 |
| DR-16 | Pisma/Narzędzia | 11 | 0 | 0 | 0 | 11 |
| **SUMA** | | **271** | **9** | **0** | **4** | **284** |

---

## DR-01 — Ustrój Konstytucyjny i Źródła Prawa

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Konstytucja RP + Ustawa o TK | Dz.U. 1997 nr 78 poz. 483 + Dz.U. 2019 poz. 2393 t.j. ✅ VER 2026-07-04: nadal aktualne (próba zastąpienia ustawą z 13.09.2024 zawetowana przez Prezydenta RP) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-Konstytucja-TK-skarga-konstytucyjna.md | ✅ OK |
| PUSP + SN (ustrój sądów) | Dz.U. 2024 poz. 334 ze zm. (zm.: 2025.526, 2025.1609) + Dz.U. 2024 poz. 622 ✅ VER 2026-07-04 | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-USP-ustroj-sadow-powszechnych.md | ✅ OK |
| Ustawa o Sądzie Najwyższym | Dz.U. 2024 poz. 622 t.j.; zmiany po t.j. kontrolowane temporalnie, w tym prospektywna Dz.U. 2026 poz. 1123 od 1.01.2028 | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ustawa-SN-sad-najwyzszy.md | ✅ F-108/50 P2 — dedykowany moduł B |
| Prawo o ustroju sądów administracyjnych (PUSA) | Dz.U. 2024 poz. 1267 t.j. — potwierdzone ELI 2026-08-26; poprzednie `1297` było błędne | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-USP-ustroj-sadow-powszechnych.md | ✅ SKORYGOWANE |
| Ustawa o skardze na przewlekłość postępowania | Dz.U. 2023 poz. 1725 t.j. ✅ dodano 2026-07-04 (audyt — brakowało w mapie centralnej) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-przewleklosc-current-state-COV.md | ✅ NOWY — wskaźnik poprawiony (T5 2026-09-16: mod-USP nie zawierał treści; ✅ RZĄD 1 ELI — akt obowiązujący) |
| Ustawa o KRS + ustrój władzy | Dz.U. 2024 poz. 1186 t.j. ✅ VER 2026-07-04 (POPRAWKA — było błędnie "2011 poz. 714") | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ustawa-KRS-i-ustroj-wladzy.md | ✅ OK |
| Ustawa o wykonywaniu mandatu posła i senatora | Dz.U. 2026 poz. 1282 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) (poprzedni t.j. 2024/907, VER 2026-06-14) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ustawa-KRS-i-ustroj-wladzy.md | ✅ OK |
| Ustawa o partiach politycznych + referendum ogólnokrajowe | Dz.U. 2023 poz. 1215 | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ustawa-partie-polityczne-referendum.md | ✅ OK |
| Ustawa o referendum ogólnokrajowym | Dz.U. 2025 poz. 300 t.j. ✅ VER: 2026-06-14 (TRYB DZU — był 2020/851) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ustawa-partie-polityczne-referendum.md | ✅ OK |
| Ustawa o Radzie Ministrów + Prezydent RP | Dz.U. 2025 poz. 780 t.j. ✅ VER 2026-07-04 (POPRAWKA — było błędnie "2022 poz. 2032", numer nieistniejący dla tej ustawy) | → dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ustawa-KRS-i-ustroj-wladzy.md | 🔗 odesłanie |
| Rozporządzenie ws. „Zasad techniki prawodawczej" (ZTP) | ✅ **SKORYGOWANE 2026-08-18 (F-89):** t.j. **Dz.U. 2026 poz. 300** (konsolidacja nowelizacji 26.01.2026, poprzedni t.j. 2016.283 NIEAKTUALNY od lutego 2026) — metryka przestarzała ("2016 poz. 283 ze zm. 2026 poz. 100") zsynchronizowana z lokalną mapą dr-01, zweryfikowaną 2026-08-14 (F-77, portaloswiatowy.pl, rcl.gov.pl) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-ZTP-przepisy-przejsciowe-doktryna.md | ✅ ZSYNCHRONIZOWANE 2026-08-18 |
| ZTP Rozdział 4a (przepisy epizodyczne, §29a-29c) + doktryna specustaw/lex specialis (ten sam akt co wyżej, inny dział) | jak wyżej — **Dz.U. 2026 poz. 300** t.j. (SKORYGOWANE 2026-08-18, F-89) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-specustawy-lex-specialis-graf-zaleznosci.md | ✅ ZSYNCHRONIZOWANE 2026-08-18 |
| Ustawa z 18.04.2002 o stanie klęski żywiołowej | Dz.U. 2025 poz. 112 t.j. ✅ VER 2026-07-17 (isap) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md | ✅ NOWY (2026-07-17) |
| Ustawa z 21.06.2002 o stanie wyjątkowym | ⚠️ VER częściowa 2026-07-17 (poprzedni t.j. Dz.U. 2017 poz. 1928, nowelizowany od tego czasu — zweryfikuj aktualny t.j. na ISAP przed powołaniem) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md | ✅ NOWY (2026-07-17) |
| Ustawa z 29.08.2002 o stanie wojennym oraz o kompetencjach Naczelnego Dowódcy SZ | ✅ **SKORYGOWANE 2026-08-18 (F-89):** t.j. **Dz.U. 2025 poz. 504** (był największą luką — poprzednio brak numeru w ROUTING-MAP; zsynchronizowany z lokalną mapą dr-01, zweryfikowaną 2026-08-14, F-77) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md | ✅ ZSYNCHRONIZOWANE 2026-08-18 |
| Ustawa z 26.04.2007 o zarządzaniu kryzysowym | ✅ **SKORYGOWANE 2026-08-18 (F-89):** t.j. **Dz.U. 2026 poz. 574** + nowelizacja Dz.U. 2026 poz. 815 (numer wcześniej niepotwierdzony w ROUTING-MAP, zsynchronizowany z lokalną mapą dr-01, zweryfikowaną 2026-08-14, F-77) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md | ✅ ZSYNCHRONIZOWANE 2026-08-18 — ✅ [VER] RZĄD 1 2026-09-10f — Dz.U. 2026 poz. 574 potwierdzony jako najnowszy tekst jednolity. ⛔ KROK 2C (ELI 2026-10-09): nowelizacje po tekście jednolitym — Dz.U. 2026 poz. 815 (ustawa z 29.05.2026, w mocy 4.07.2026) oraz Dz.U. 2026 poz. 1206 art. 15 (załącznik — sektor bankowy, od 11.01.2027). |
| Ustawa z 5.12.2024 o ochronie ludności i obronie cywilnej | Dz.U. 2024 poz. 1907 (brak t.j.; zm. (ELI 2026-10-12): 2025/1705, 2026/646, 2026/815 w mocy 4.07.2026) ✅ VER 2026-07-17 (isap, gofin) — w życie 1.01.2025, NIE zastępuje ustaw o stanie klęski żywiołowej/zarządzaniu kryzysowym, współistnieje (art. 5 ust. 1) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md | ✅ NOWY (2026-07-17) |
| Ustawa z 5.12.2008 o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych u ludzi (art. 46/46a/46b) | ⚠️ VER częściowa 2026-07-17 — zweryfikuj aktualny t.j. na ISAP przed powołaniem (nowelizowana wielokrotnie od 2020) | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md | ✅ NOWY (2026-07-17) |
| Rejestracja current-state: organizacja i postępowanie przed TK | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-TK-organizacja-postepowanie-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: PUSA | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-PUSA-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: KRS | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-KRS-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: Rada Ministrów | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-Rada-Ministrow-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: mandat posła i senatora | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-mandat-posla-senatora-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: partie polityczne | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-partie-polityczne-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: przewlekłość postępowania | bieżący stan ELI/ISAP | dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-przewleklosc-current-state-COV.md | ✅ current-state COV |

---

## DR-02 — Prawo Cywilne, Rodzinne i Gospodarcze

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Ustawa o przeciwdziałaniu nadmiernym opóźnieniom w transakcjach handlowych | Dz.U. 2023 poz. 1790 t.j. ✅ [VER] RZĄD 1 2026-09-10f — obwieszczenie Marszałka Sejmu z 14.07.2023, status obowiązujący, **ZERO nowelizacji po tekście jednolitym** (odczyt `/references`). Wcześniejsze zastrzeżenie „pełna historia zmian niepotwierdzona" zdjęte — historia zmian jest domknięta po stronie ELI | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-transakcje-handlowe-opoznienia.md | B — rdzeń cywilny; administracja i historia częściowe (F-108/46) |
| Kodeks cywilny — zobowiązania, roszczenia | Dz.U. 2026 poz. 795 t.j. ze zm.; ⏳ 2026/507 art. 2 (dodany art. 860 § 3–4 — umowa spółki cywilnej i inne czynności na wzorach w systemie CEIDG) od 1.11.2028 — brzmienie zawarte już w t.j. 2026/795; do tej daty NIE stosować (✅ [VER] RZĄD 1 2026-10-15, ELI) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md | ✅ OK |
| Kodeks cywilny — konsumenckie | Dz.U. 2026 poz. 795 t.j. ze zm. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-konsumenckie.md | ✅ OK |
| Kodeks cywilny — Księga IV Spadki (art. 922-1088, w tym zapis windykacyjny, wykonawca testamentu, wydziedziczenie, odpowiedzialność za długi spadkowe, dziedziczenie przez gminę/Skarb Państwa art. 935) + Rozporządzenie UE 650/2012 (spadki transgraniczne, ⚠️ punkt startowy) | Dz.U. 2026 poz. 795 t.j. ze zm. + Rozp. UE 650/2012 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-spadki.md (v2.0) | ✅ ROZBUDOWANE 2026-07-19 (sync z DR-02/MAPA-AKTOW) |
| KC Księga IV — zachowek, dział spadku, zapis i polecenie, wykonawca testamentu, wydziedziczenie, niegodność | ten sam akt | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-spadki-zachowek-dzial-rozrzadzenia.md | ⭐ WYDZIELONY 2026-08-21 (ZASADA 13 / F-105) |
| KC Księga IV — długi spadkowe, umowy o spadek, gmina/Skarb Państwa, spadki transgraniczne (EPS), gospodarstwa rolne, spis inwentarza | ten sam akt | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-spadki-dlugi-umowy-transgraniczne.md | ⭐ WYDZIELONY 2026-08-21 (ZASADA 13 / F-105) |
| Kodeks cywilny — ubezpieczenia (art. 805–834 KC) | Dz.U. 2026 poz. 795 t.j. — RZĄD 1, obwieszczenie 27.05.2026 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-ubezpieczenia.md | ✅ ZSYNCHRONIZOWANE 2026-08-27 — Dz.U. 2026 poz. 783 usunięto z KC jako numer odrębnej ustawy |
| Ustawa o ubezpieczeniach obowiązkowych, UFG i PBUK | Dz.U. 2026 poz. 783 t.j. — RZĄD 1 ELI, stan prawny 27.05.2026 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-ubezpieczenia-obowiazkowe-UFG-PBUK.md | ✅ NOWY F-108/41, poziom B |
| Kodeks rodzinny i opiekuńczy — ROZBUDOWANE 2026-07-19: separacja, ustrój majątkowy/intercyza, ustalenie ojcostwa, eksmisja małżonka (art. 58 §2-4), obowiązek alimentacyjny szerszego kręgu, surogacja, konkubinat | Dz.U. 2026 poz. 236 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KRO-rodzinne.md | ✅ OK |
| KRO — zawarcie małżeństwa, przeszkody, bigamia (art. 1-22) + KK art. 206 + PPM (małżeństwo zagraniczne) + TSUE C-713/23/NSA 20.03.2026 (małżeństwo jednopłciowe) | Dz.U. 2026 poz. 236 t.j. + KK 2025.383 t.j. + PPM ⚠️ zweryfikuj t.j. + orzecznictwo | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KRO-zawarcie-malzenstwa-bigamia-transgraniczne.md | ✅ NOWY 2026-07-19, temat ŻYWY politycznie — re-weryfikuj status TK |
| KRO — przysposobienie krajowe (art. 114-127) + Konwencja haska 1993 (przysposobienie międzynarodowe) | Dz.U. 2026 poz. 236 t.j. + Konwencja haska Dz.U. 2000 nr 39 poz. 448 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KRO-przysposobienie-adopcja-miedzynarodowa.md | ✅ NADROBIONA ZALEGŁOŚĆ 2026-07-19 |
| Ustawa o wspieraniu rodziny i systemie pieczy zastępczej (9.06.2011) | Dz.U. 2026 poz. 980 t.j. ✅ VER 2026-08-31 (sip.lex.pl „Dz.U.2026.980 t.j.” + przepisy.gofin.pl — łańcuch wersji czasowych kończący się na 2026/980, bezpośrednio po 2025/49; dwa niezależne źródła RZĄD 2B, K-2 spełnione). ✅ [VER] RZĄD 1 2026-09-10c (F-141): odczyt bezpośredni `api.sejm.gov.pl/eli/acts/DU/2026/980` — obwieszczenie z 16.07.2026, akt bazowy 2011/887, **najnowszy z 12 t.j. tego aktu**, zero nowelizacji po t.j. ⛔ Uwaga metodyczna: zapytania ogólne o „tekst jednolity” tej ustawy zwracają 2025/49 i starsze — to właśnie dało fałszywy negatyw przy pierwszej próbie 2026-08-31. Rozstrzyga **odczyt po adresie** (`/eli/acts/DU/{rok}/{poz}`) i lista `Inf. o tekście jednolitym` aktu bazowego, nie wyszukiwarka | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-piecza-zastepcza-rodzina-zastepcza.md | ✅ NOWY 2026-07-19 |
| KC art. 13/16 (ubezwłasnowolnienie) + KRO art. 145-184 (opieka/kuratela) | Dz.U. 2026 poz. 795 t.j. + Dz.U. 2026 poz. 236 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ubezwlasnowolnienie-opieka-kuratela.md | ✅ NOWY 2026-07-19 |
| KPC — egzekucja i windykacja | Dz.U. 2026 poz. 468 ze zm. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KPC-egzekucja-windykacja.md | ✅ OK |
| KPC — art. 162, zastrzeżenie do protokołu (prekluzja zarzutów procesowych, ⛔ nie mylić z art. 162 KK) | Dz.U. 2026 poz. 468 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KPC-art162-zastrzezenie-protokol.md | ✅ NOWY 2026-08-22 — naprawa poz. #14 mapy pokrycia KPC, luka bliźniacza do art. 105 PPSA (dr-05) — SYNC REGUŁA 3 |
| KPC — uzupełnienie krytycznych luk audytu (205¹–205¹², 316, 350–352, 399/401/401¹/403, 458¹–458¹⁶, 477⁹ i n., 829/833, 1041–1059, 1081–1088, 617–626¹³, 669–689, jurysdykcja) | Dz.U. 2026 poz. 468 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KPC-uzupelnienie-pokrycia-2026.md | 🟡 B+ — operacyjne uzupełnienie luk krytycznych |
| Kodeks spółek handlowych | Dz.U. 2024 poz. 18 ze zm. (zm.: 2025.1085) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KSH-spolki-handlowe.md | ✅ OK |
| KSH — uzupełnienie pozostałego pokrycia (Tytuł I, partnerska/S.K.A., pozostałe rozdziały sp. z o.o., PSA, S.A., operacje transgraniczne, Tytuł V) | Dz.U. 2024 poz. 18 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KSH-uzupelnienie-pokrycia-2026.md | 🟡 B — pokrycie operacyjne, nie certyfikat kompletności |
| Ustawa o licencji doradcy restrukturyzacyjnego (zawód regulowany, BEZ samorządu — syndyk/nadzorca/zarządca) | Dz.U. 2022 poz. 1007 t.j. (VER ELI 2026-10-07: najnowszy t.j. dla DU/2007/850, brak późniejszych zmian) + Pr. restrukturyzacyjne 2026/533 + Pr. upadłościowe 2025/614 + nowelizacja Dz.U. 2025 poz. 1085 (w życie 23.08.2025) ✅ VER: 2026-06-15 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-doradca-restrukturyzacyjny-zawod.md | ✅ NOWY |
| Prawo przedsiębiorców | Dz.U. 2025 poz. 1480 t.j.; późniejsze zmiany urzędowe m.in. 2025/1795, 2025/1826, 2026/507 (art. 7, w życie 14.10.2026) — VER RZĄD 1 ELI 2026-08-27, 2026-10-15 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-prawo-przedsiebiorcow.md | ✅ F-108/51 P2 — dedykowany moduł B |
| Ustawa o CEIDG i Punkcie Informacji dla Przedsiębiorcy | Dz.U. 2026 poz. 30 t.j.; zm. po t.j.: 2026/734 (od 20.06.2026), 2026/507 — etapami: 21.04.2026, 14.10.2026 (zasadnicza część), 1.11.2026, ⏳ 1.11.2028 (m.in. publikacja informacji o spółce cywilnej) — VER RZĄD 1 ELI 2026-10-15 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-prawo-przedsiebiorcow.md (routing CEIDG) | ✅ NOWY 2026-10-15 |
| Prawo wekslowe (28.04.1936) + Prawo czekowe (28.04.1936) | Dz.U. 2022 poz. 282 t.j. + Dz.U. 2016 poz. 462 t.j. ⚠️ zweryfikuj aktualne t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-prawo-wekslowe-czekowe.md | ✅ NOWY 2026-07-19 |
| Ustawa o prawach konsumenta | Dz.U. 2026 poz. 1244 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane); poprzedni t.j. 2024 poz. 1796 (VER 2026-08-31 (arslege.pl „Dz.U.2024.0.1796 t.j.” + przepisy.gofin.pl; poprzedni t.j. 2023 poz. 2759) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-prawa-konsumenta.md | ✅ OK |
| Ustawa o cudzoziemcach | Dz.U. 2025 poz. 1079 ze zm. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-cudzoziemcy.md | ✅ OK |
| Ustawa o ochronie konkurencji i konsumentów (UOKiK) | ⚠️ zweryfikuj t.j. na ISAP (ustawa z 16.02.2007) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-UOKIK-antymonopolowe.md | ✅ NOWY 2026-07-18 — KOREKTA: poprzedni wpis wskazywał na plik "mod-ustawa-ochrona-konkurencji-konsumentow-UOKiK", który NIGDY NIE ISTNIAŁ w DR-02 (fantom); teraz wskazuje na rzeczywisty moduł |
| Ustawa o KRS — rejestr sądowy | Dz.U. 2025 poz. 869 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-KRS-rejestr-sadowy.md | ✅ OK |
| Ustawa o kredycie konsumenckim (SKD — sankcja kredytu darmowego, art. 45) | Dz.U. 2025 poz. 1362 t.j. ✅ POTWIERDZONE 2026-08-04 (ISAP, obwieszczenie z 26.09.2025, obowiązuje od 2025-10-10) — ⚠️ temat wyjątkowo dynamiczny, re-zweryfikuj przy każdym użyciu czy nie doszło do nowej nowelizacji | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-kredyt-konsumencki-SKD.md | ✅ NOWY 2026-08-04 — KOREKTA: poprzedni wpis wskazywał błędnie na "mod-ustawa-deweloperska" (phantom mapping — inny akt prawny, ustawa deweloperska 2024/695 dot. ochrony nabywcy lokalu, nie kredytu konsumenckiego); wykryte i naprawione w toku dostawy Reguły 7 — ✅ [VER] RZĄD 1 2026-09-10f — Dz.U. 2025 poz. 1362 potwierdzony: obwieszczenie z 26.09.2025, akt bazowy 2011/715, najnowszy tekst jednolity, ZERO nowelizacji po nim. ⚠️ Wzmianka o 2024/695 w tym wierszu dotyczy ustawy deweloperskiej i jest historyczna — jej aktualny tekst jednolity to Dz.U. 2026 poz. 880. |
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa o opiniodawczych zespołach sądowych specjalistów (OZSS) | t.j. Dz.U. 2018 poz. 708 — nadal aktualne (potwierdzone niezależnie: regulacja wykonawcza MS z 2024 i ustawa o zawodzie psychologa z 2026 nadal cytują ten sam numer, brak nowszego t.j.) — całkowicie nieobecna w ROUTING-MAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/kro-rodzinne/czesc-06-rodzice-dzieci-wladza-ozss.md (indeks: mod-KRO-rodzinne.md; wskaźnik doprecyzowany T5 2026-09-16) | ✅ DODANE 2026-08-19 |
| Ustawa deweloperska — ochrona nabywcy | Dz.U. 2026 poz. 880 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-deweloperska.md | ✅ OK |
| Ustawa o własności lokali | Dz.U. 2026 poz. 232 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-spoldzielnie-wlasnosc-lokali.md | ✅ OK |
| Prawo spółdzielcze | Dz.U. 2026 poz. 521 t.j. — RZĄD 1 ELI | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-prawo-spoldzielcze.md | ✅ F-108/13 P3 — dedykowany moduł B |
| Ustawa o spółdzielniach mieszkaniowych | Dz.U. 2026 poz. 889 t.j. — RZĄD 1 ELI | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-spoldzielnie-mieszkaniowe.md | ✅ F-108/34 P3 — dedykowany moduł B+ |
| Ustawa o fundacjach i Prawo o stowarzyszeniach | fundacje: Dz.U. 2023 poz. 166 t.j. + zm. Dz.U. 2026 poz. 316; stowarzyszenia: Dz.U. 2020 poz. 2261 t.j. + zm. Dz.U. 2026 poz. 316; opubl. Dz.U. 2026 poz. 346 (⛔ w życie 30.09.2028 — do tej daty NIE stosować) wchodzi 30.09.2028 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-fundacje-stowarzyszenia.md | ✅ B+/COV; temporal gate dla 2026/346 |
| Ustawa o fundacji rodzinnej | Dz.U. 2023 poz. 326 ze zm. Dz.U. 2023 poz. 825 — RZĄD 1 ELI | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-fundacja-rodzinna.md | ✅ NOWY F-108/52, poziom B |
| Ustawa UZNK — nieuczciwa konkurencja | Dz.U. 2026 poz. 85 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-UZNK-nieuczciwa-konkurencja.md | ✅ OK |
| Ustawa o timeshare + zastaw rejestrowy | Dz.U. 2011 Nr 230, poz. 1370 (timeshare, brak konsolidacji) + Dz.U. 2018 poz. 2017 t.j. (zastaw rejestrowy) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-timeshare-zastaw-rejestrowy.md | ✅ NAPRAWIONE 2026-08-22 (F-82) — SYNC REGUŁA 3, ta sama korekta co dr-02/MAPA-AKTOW.md |
| KC — służebności, zasiedzenie, prawo rzeczowe (art. 145, 172, 222, 305¹ KC) | Dz.U. 2026 poz. 795 t.j. ze zm. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md → ANEKS D | ✅ OK |
| KC — dział spadku, nabycie spadku, zachowek (art. 991, 1015, 1037 KC) | Dz.U. 2026 poz. 795 t.j. ze zm. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md → ANEKS E | ✅ OK |
| Kredyty frankowe — abuzywność klauzul (art. 385¹ KC + dyr. 93/13/EWG + TSUE) | Dz.U. 2026 poz. 795 t.j. + Dz.Urz. UE L 95/29 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md → ANEKS F | ✅ OK |
| Ustawa o pomocy obywatelom Ukrainy | ✅ **SKORYGOWANE 2026-08-19 (F-89):** akt pierwotny Dz.U. 2022 poz. 583 (t.j. Dz.U. 2026 poz. 1293, ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane)) — w ISTOTNYM ZAKRESIE **WYGASZONA z dniem 5.03.2026** ustawą z 23.01.2026 (Dz.U. 2026 poz. 203). Skutki: legalizacja pobytu przeniesiona do ustawy o udzielaniu ochrony cudzoziemcom (t.j. Dz.U. 2026 poz. 862), powierzanie pracy przeniesione do ustawy o warunkach dopuszczalności powierzania pracy cudzoziemcom (Dz.U. 2025 poz. 621); ochrona czasowa dla obecnych beneficjentów trwa do 4.03.2027 w nowym reżimie. Zsynchronizowane z lokalną mapą dr-05 (F-30, 2026-08-13) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-cudzoziemcy.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| Monopole państwowe (art. 216 ust. 3 Konstytucji) — gry hazardowe, operator wyznaczony (Poczta Polska), PWPW | Konstytucja + ustawa o grach hazardowych (2009) + Prawo pocztowe (2012) — ⚠️ zweryfikuj t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-monopole-panstwowe.md | ✅ NOWY 2026-07-18 |
| KSH — wrogie przejęcie, techniki obrony (biały rycerz, zatruta pigułka) | Dz.U. 2024 poz. 18 ze zm. (ta sama pozycja co KSH, inny aspekt) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KSH-wrogie-przejecie-obrona-bialy-rycerz.md | ✅ NOWY 2026-07-18 |
| Ustawa o rzeczach znalezionych (2015) + KC art. 172-176 (zasiedzenie) | Dz.U. 2023 poz. 501 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) (zm. po t.j. (ELI 2026-10-12): Dz.U. 2026 poz. 184, w mocy od 19.05.2026 — art. 5, 6, 7, 13, 15, 19, 25a; do rzeczy znalezionych przed 19.05.2026 przepisy dotychczasowe, art. 3) + KC Dz.U. 2026 poz. 795 t.j. (art. 187 § 1–2 w brzmieniu z 2026/184: 6 miesięcy / rok) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-rzeczy-znalezione-zasiedzenie.md | ✅ NOWY 2026-07-18 |
| Ustawa o ochronie praw lokatorów art. 6, 19a (kaucja przy najmie) | ✅ **SKORYGOWANE 2026-08-19 (F-89):** t.j. Dz.U. 2023 poz. 725 — zsynchronizowane z lokalną mapą dr-02 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-kaucja-najem-lokalu.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| Kodeks cywilny art. 385¹ (klauzule abuzywne — kredyty frankowe) | ⚠️ ta sama pozycja co główny mod-KC — zweryfikuj t.j. KC na ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-kredyty-frankowe.md | ✅ WYDZIELONY 2026-06-14 z mod-KC-cywilne-zobowiazania-odpowiedzialnosc (NOTA-4, moduł >400 linii) — DOPISANE do mapy 2026-07-30 (sync) |
| Ustawa o przeciwdziałaniu nieuczciwym praktykom rynkowym (UPNPR) + Ustawa o radiofonii i telewizji art. 16b/18/53 (reklama wobec nieletnich) | UPNPR t.j. Dz.U. 2023 poz. 845 ✅ VER 2026-08-31 (obwieszczenie z 7.04.2023; RZĄD 1 ISAP WDU20230000845, RZĄD 2B infor.pl + lexlege.pl) + ustawa o radiofonii i telewizji t.j. Dz.U. 2022 poz. 1722 ✅ VER 2026-08-31 (obwieszczenie z 5.08.2022; RZĄD 1 eli.gov.pl wprost wskazuje ten t.j. dla Dz.U. 1993 nr 7 poz. 34) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-reklama-wobec-nieletnich.md | ✅ NOWY 2026-07-18 — DOPISANE do mapy 2026-07-30 (sync) |
| art. 431 KC (odpowiedzialność za zwierzę) + art. 362 KC (przyczynienie się) + PRD (C-13/C-16) — pies na drodze rowerowej | ⚠️ zweryfikuj t.j. KC na ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-pies-droga-rowerowa-odpowiedzialnosc.md | ✅ NOWY 2026-08-04 — DOPISANE 2026-08-05 (sync) |
| Parabanki/chwilówki/lombardy/lichwa (art. 304 KK, art. 388 KC, art. 36a ukk, ⚡ projekt ustawy lombardowej, ustawa antylichwiarska) | ⛔ **BŁĄD SKORYGOWANY 2026-09-10f:** wiersz podawał „ustawa antylichwiarska: 2023/1028" — `2023/1028` to **wygasły tekst jednolity ustawy o KREDYCIE KONSUMENCKIM** (obwieszczenie z 12.04.2023, akt bazowy 2011/715; aktualny t.j. tej ustawy to Dz.U. 2025 poz. 1362). Poprawnie ustawa antylichwiarska: **Dz.U. 2022 poz. 2339** ✅ [VER] RZĄD 1 2026-09-10f — ustawa z 6.10.2022 o zmianie ustaw w celu przeciwdziałania lichwie, status obowiązujący. Klasa F-149(3) — podmiana aktu; ustawa o konsumenckiej pożyczce lombardowej (14.04.2023, akt pierwotny Dz.U. 2023 poz. 1285): t.j. Dz.U. 2024 poz. 1111 ✅ VER 2026-08-31 — obwieszczenie z 17.07.2024 (RZĄD 1: eli.gov.pl/eli/DU/2024/1111/ogl; RZĄD 2B: KNF, infor.pl, prawo.pl) — UCHWALONA, nie projekt — ✅ [VER] RZĄD 1 2026-09-10f: wszystkie trzy numery tego wiersza rozstrzygnięte w API ELI — antylichwiarska 2022/2339 (obowiązująca), lombardowa t.j. 2024/1111 (najnowszy), akt pierwotny lombardowej 2023/1285. ⛔ Po t.j. (✅ [VER] RZĄD 1 2026-10-09 (ELI, daty z przepisów o wejściu w życie)): ⏳ lombardowa — Dz.U. 2026 poz. 875 art. 16 (od 1.01.2027) i Dz.U. 2026 poz. 1206 art. 38 (od 11.01.2027; metadane ELI podają 29.09.2026 — to data głównej części ustawy, art. 38 objęty wyjątkiem art. 57); kredyt konsumencki t.j. 2025/1362 — ⏳ Dz.U. 2026 poz. 1206 art. 21 (od 11.01.2027) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-parabanki-chwilowki-lombardy-lichwa.md | ✅ NOWY 2026-08-05 |
| Liczba pełnomocników procesowych (KPC bez limitu, KPK max 3 obrońców) + strona samodzielna (reforma 2005, art. 117 KPC) | ⚠️ zweryfikuj t.j. KPC na ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-liczba-pelnomocnikow-strona-samodzielna.md | ✅ NOWY 2026-08-05 |
| Skład sądu — pełne zestawienie (KPC art. 47/367¹, KPK art. 28-30, w tym JEDYNY skład 5 sędziów: apelacja/kasacja od dożywocia) | ✅ Dz.U. 2026 poz. 468 KPC t.j., Dz.U. 2026 poz. 490 KPK t.j. (VER 2026-08-07) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-sklad-sadu-liczba-sedziow.md | ✅ NOWY 2026-08-07 |
| ⚡⚡ Ustawa frankowa z 29.05.2026 — sprawy CHF w toku, posiedzenia niejawne | ✅ Dz.U. 2026 poz. 985 (VER 2026-08-07, weszła w życie tego dnia) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-frankowa-2026-procedura.md | ✅ NOWY 2026-08-07 |
| Prawo wekslowe (1936) + Prawo czekowe (1936) + Prawo przedsiębiorców Rozdz. 3-5 (kontrola przedsiębiorcy, koncesje) | Dz.U. 2022 poz. 282 t.j. (wekslowe) + Dz.U. 2016 poz. 462 t.j. (czekowe) + Dz.U. 2025 poz. 1480 t.j. (Prawo przedsiębiorców) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-wekslowe-kontrola-przedsiebiorcy-koncesje.md | ✅ NOWY 2026-07-19 — DOPISANE do mapy 2026-07-30 (sync) |
| Ustawa o ochronie praw lokatorów, mieszkaniowym zasobie gminy — najem zwykły/okazjonalny/instytucjonalny, kaucje (3 różne progi), art. 16 okres ochronny, art. 1046 §5¹ KPC, art. 678 KC | Dz.U. 2023 poz. 725 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-ochrona-praw-lokatorow-najem-eksmisja.md | ✅ NOWY 2026-08-13 — DOPISANE 2026-08-14 (sync) — naprawa luki strukturalnej (dotąd tylko fragment "dziki lokator" gdzie indziej) |
| Ustawa z 16.07.2020 o udzielaniu pomocy publicznej w celu ratowania lub restrukturyzacji przedsiębiorców (art. 1-53): pomoc na ratowanie, tymczasowe wsparcie restrukturyzacyjne [MŚP], pomoc na restrukturyzację [debt-to-equity, limit wynagrodzeń 400%]; art. 50 uchyla dawny art. 139a PrRestr | Dz.U. 2026 poz. 113 t.j. ✅ VER 2026-08-31 — obwieszczenie Marszałka Sejmu z 26.01.2026 (RZĄD 1: eli.gov.pl/ISAP PDF D20260113; RZĄD 2B: rp.pl wykaz Dz.U., infor.pl, przepisy.gofin.pl); akt pierwotny Dz.U. 2020 poz. 1298 | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-pomoc-ratowanie-restrukturyzacja-przedsiebiorcow.md | ✅ NOWY 2026-08-20 — DOPISANE 2026-08-20 (sync) — naprawa F-98; ✅ [VER] RZĄD 1 2026-09-10c (F-141): api.sejm.gov.pl/eli/acts/DU/2026/113 — Obwieszczenie Marszałka Sejmu z 26.01.2026, typ Obwieszczenie, status obowiązujący; znacznik braku weryfikacji w RZĘDZIE 1 zdjęty |
| KSH — Tytuł III, Dział I, Rozdz. 3, organy sp. z o.o. (art. 201-254): zarząd [art. 204 §2 — zakaz ograniczenia reprezentacji wobec osób trzecich], zgromadzenie wspólników [art. 228 — absolutorium, art. 235 §2 — zastępcze zwołanie] | Dz.U. 2024 poz. 18 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KSH-organy-spolki-zoo.md | ✅ NOWY 2026-08-14 — DOPISANE 2026-08-14 (sync) — naprawa F-68, najwyższy priorytet z raportu KSH |
| KSH — Tytuł II, spółki osobowe (art. 22-124) i rada nadzorcza sp. z o.o. (art. 212-226): odpowiedzialność solidarno-subsydiarna, prowadzenie spraw vs reprezentacja, suma komandytowa, próg obligatoryjności rady nadzorczej | Dz.U. 2024 poz. 18 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KSH-spolki-osobowe-rada-nadzorcza.md | ✅ NOWY 2026-08-20 — DOPISANE 2026-08-20 (sync) — naprawa F-68 W CAŁOŚCI; ✅ [VER] RZĄD 1 2026-09-10c (F-135): Dz.U. 2024 poz. 18 — obwieszczenie z 7.12.2023, akt bazowy 2000/1037, najnowszy t.j. ⛔ KROK 2C (✅ [VER] RZĄD 1 2026-10-09 (ELI, daty z przepisów o wejściu w życie)): po t.j. w mocy — wyrok TK z 18.01.2024, K 29/23 (Dz.U. 2024 poz. 96) i Dz.U. 2026 poz. 644 art. 6 (ESAP, od 29.05.2026); ⏳ Dz.U. 2026 poz. 176 art. 1 (od 18.02.2027), Dz.U. 2026 poz. 187 art. 138 (od 19.05.2028); t.j. NIE oddaje stanu bieżącego |
| KPC — prawomocność orzeczeń (363-366, powaga rzeczy osądzonej) i granice apelacji (378, 380-386, zakaz reformationis in peius art. 384) | Dz.U. 2026 poz. 468 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KPC-prawomocnosc-granice-apelacji.md | ✅ NOWY 2026-08-14 — DOPISANE 2026-08-14 (sync) — naprawa F-65, dawało podstawę merytoryczną dla engine appellate-v8 |
| KPC — KSIĘGA II, postępowanie NIEPROCESOWE, część ogólna (506-525): wszczęcie, właściwość (⛔ MIEJSCOWA WYŁĄCZNA wg WNIOSKODAWCY, odwrotnie niż w procesie), zainteresowany vs uczestnik (510), wniosek (511), apelacja vs zażalenie (518) | Dz.U. 2026 poz. 468 t.j. | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KPC-nieproces-czesc-ogolna.md | NOWY 2026-08-14d (F-65 cz. II) — pierwszy moduł Księgi II w systemie; SYNC REGUŁA 3 |
| KRO — opieka i kuratela | Dz.U. — patrz wiersz macierzysty KRO | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KRO-opieka-i-kuratela.md | SYNC REGUŁA 3, 2026-08-14e (F-77 rozszerzona) |
| Księgi wieczyste i hipoteka — zakup nieruchomości | ✅ **SKORYGOWANE 2026-08-19 (F-89):** t.j. Dz.U. 2026 poz. 1066 (obwieszczenie 6.03.2025) ze zm. Dz.U. 2025 poz. 1669, 1792, 1793 oraz Dz.U. 2026 poz. 119 — zsynchronizowane z lokalną mapą dr-02 (F-77, 2026-08-14, 4 zgodne źródła) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KW-ksiega-wieczysta-zakup-nieruchomosci.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| Rejestracja current-state: Kodeks cywilny | bieżący stan ELI/ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: Kodeks postępowania cywilnego | bieżący stan ELI/ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KPC-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: Prawo przedsiębiorców | bieżący stan ELI/ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-Prawo-przedsiebiorcow-current-state-COV.md | ✅ current-state COV |
| Zastaw rejestrowy — moduł dedykowany | bieżący stan ELI/ISAP | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-zastaw-rejestrowy.md | ✅ aktywny |
| KP art. 94³ — moduł przekrojowy zarejestrowany fizycznie w DR-02 | aktualne brzmienie na dzień sprawy | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KP-art943-mobbing-dyskryminacja.md | ✅ routing przekrojowy |

---

### Prawo upadłościowe i restrukturyzacyjne — źródła i procedury

| Zakres | Źródło | Moduł | Status |
|---|---|---|---|
| Nadzorca i zarządca — kompetencje, kontrola i wynagrodzenie | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-dzial-III-nadzorca-zarzadca.md | źródło pełne / procedura; fresh i temporal gate |
| Restrukturyzacja — uczestnicy, spis, zgromadzenie i rada | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-dzial-IV-uczestnicy-wierzyciele.md | źródło pełne / procedura; fresh i temporal gate |
| Restrukturyzacja — pomoc publiczna i test prywatnego wierzyciela | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-dzial-V-pomoc-publiczna.md | źródło pełne / procedura; fresh i temporal gate |
| Układ — zakres, propozycje, głosowanie, zatwierdzenie i wykonanie | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-dzial-VI-uklad.md | źródło pełne / procedura; fresh i temporal gate |
| Układ częściowy — wybór wierzycieli, ochrona i głosowanie | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-dzial-VII-uklad-czesciowy.md | źródło pełne / procedura; fresh i temporal gate |
| Restrukturyzacja — transgraniczne, odrębne, karne i przejściowe | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-odrebne-miedzynarodowe.md | źródło pełne / procedura; fresh i temporal gate |
| Przyspieszone postępowanie układowe i postępowanie układowe | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-ppu-pu.md | źródło pełne / procedura; fresh i temporal gate |
| Restrukturyzacja — procedura wspólna, zakończenie i upadłość | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-procedura-zakonczenie.md | źródło pełne / procedura; fresh i temporal gate |
| Postępowanie o zatwierdzenie układu — pełny przebieg | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-pzu.md | źródło pełne / procedura; fresh i temporal gate |
| Sanacja — zarząd, działania sanacyjne i układ | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-sanacja.md | źródło pełne / procedura; fresh i temporal gate |
| Restrukturyzacja — kwalifikacja sprawy, plan i test zaspokojenia | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-wejscie-plan-test.md | źródło pełne / procedura; fresh i temporal gate |
| Prawo restrukturyzacyjne — pełny korpus i sposób użycia | Dz.U. 2026 poz. 533; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrRestr-zrodla-i-wersje.md | źródło pełne / procedura; fresh i temporal gate |
| Prawo upadłościowe i restrukturyzacyjne — uzupełnienie pokrycia | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUp-PrRestr-uzupelnienie-pokrycia-2026.md | źródło pełne / procedura; fresh i temporal gate |
| PrUp — upadłość konsumencka w pracy syndyka | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-konsument-workflow.md | źródło pełne / procedura; fresh i temporal gate |
| Prawo upadłościowe — dalsza likwidacja, postępowanie międzynarodowe i odrębne | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-likwidacja-miedzynarodowe-szczegolne.md | źródło pełne / procedura; fresh i temporal gate |
| Upadłość — organy, wierzyciele i wspólna procedura | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-organy-procedura.md | źródło pełne / procedura; fresh i temporal gate |
| PrUp — fundusze masy, kategorie i plan podziału | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-podzial-335-360.md | źródło pełne / procedura; fresh i temporal gate |
| Prawo upadłościowe — postępowania odrębne od art. 426 do art. 491^38 | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-postepowania-odrebne-426-491-38.md | źródło pełne / procedura; fresh i temporal gate |
| Upadłość — masa, umowy, bezskuteczność i procesy | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-skutki-masa-bezskutecznosc.md | źródło pełne / procedura; fresh i temporal gate |
| PrUp — czynności syndyka, sprawozdawczość i likwidacja | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-syndyk-likwidacja.md | źródło pełne / procedura; fresh i temporal gate |
| Układ w upadłości i powiązanie z likwidacją | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-uklad-likwidacja-zakonczenie.md | źródło pełne / procedura; fresh i temporal gate |
| Upadłość i restrukturyzacja — kwalifikacja i nawigacja | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-upadlosc-restrukturyzacja.md | źródło pełne / procedura; fresh i temporal gate |
| PrUp — zgłoszenia, sprawdzanie i lista wierzytelności | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-wierzytelnosci-235-266.md | źródło pełne / procedura; fresh i temporal gate |
| Upadłość — przesłanki, wniosek, zabezpieczenie i pre-pack | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-wniosek-ogloszenie.md | źródło pełne / procedura; fresh i temporal gate |
| Upadłość — zakończenie, oddłużenie przedsiębiorcy, zakaz i przepisy końcowe | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-zakonczenie-zakaz-karne.md | źródło pełne / procedura; fresh i temporal gate |
| Prawo upadłościowe — pełny tekst, wersje i nawigacja | Dz.U. 2026 poz. 913; wersje i nowelizacje w references/insolvency | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-zrodla-i-wersje.md | źródło pełne / procedura; fresh i temporal gate |
| Prawo upadłościowe i restrukturyzacyjne — zmiany po t.j., jeszcze nie w życiu | Dz.U. 2026 poz. 1206 (od 11.01.2027: PrUp art. 452 ust. 1, 456 ust. 1; PrRestr art. 4 ust. 2 pkt 4) + Dz.U. 2026 poz. 176 (od 18.02.2027: PrRestr art. 156 ust. 5 pkt 4 uchylony) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-PrUpad-zrodla-i-wersje.md | ⏳ temporal gate; ELI 2026-10-07 |

## DR-03 — Prawo Karne, Wykroczenia, Egzekucja

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| KPK Dział VI Rozdz. 28 — środki zapobiegawcze i tymczasowe aresztowanie (art. 249-263: przesłanki ogólne/szczególne/negatywne, tryb, zażalenie 7 dni, maksymalne okresy 3/12/24 mies.) | Dz.U. 2026 poz. 490 t.j. ⚠️ metryka pomija 2 nowelizacje (2026.421, 2026.638) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-srodki-zapobiegawcze-tymczasowe-aresztowanie.md | ✅ NOWY 2026-08-13 — DOPISANE 2026-08-14 (sync) — naprawa F-23/F-66, jeden z najczęściej używanych tematów praktyki karnej, potwierdzona niezależnie dwoma metodami |
| Kodeks karny (KK) | Dz.U. 2025 poz. 383 ze zm. (zm.: 2025.1818, 2026.638) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kodeks-karny.md | ✅ OK |
| KK art. 15/17/23 (czynny żal) + KKS art. 16-16a (czynny żal skarbowy) — korekta terminologiczna "samooskarżenie" | Dz.U. 2025 poz. 383 t.j. + Dz.U. 2025 poz. 633 t.j. (KKS) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-czynny-zal-KK-KKS-samooskarzenie.md | ✅ NOWY 2026-07-21 |
| KPK art. 335 i 387 (dobrowolne poddanie się karze) | Dz.U. 2026 poz. 490 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-dobrowolne-poddanie-sie-karze-KPK.md | ✅ NOWY 2026-07-21 |
| KK — kwalifikator karnomaterialny | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md | ✅ OK |
| KK art. 190a — stalking | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art190a-stalking.md | ✅ OK |
| KK art. 207 + ustawa antyprzemocowa | Dz.U. 2025 poz. 383 + ustawa o przeciwdziałaniu przemocy domowej Dz.U. 2024 poz. 1673 t.j. (✅ [VER] RZĄD 1 2026-09-16e; było `2021/1249` — wygasły) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art207-przemoc-domowa.md | ✅ OK |
| KK art. 267–269c — cyberprzestępstwa | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art267-269c-cyberprzestepstwa.md | ✅ OK |
| KK art. 291–293 (paserstwo) i art. 299 — pranie pieniędzy | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art291-pranie-pieniedzy.md; paserstwo w ujęciu całego rozdz. XXXV — modules/mod-KK-art278-295-przestepstwa-przeciwko-mieniu.md | ✅ ZAKRES SKORYGOWANY 2026-10-04i (było „art. 291 — pranie pieniędzy”; moduł obejmuje art. 291–293 i art. 299, nie cały rozdział) |
| KK art. 278–295 — przestępstwa przeciwko mieniu (rozdz. XXXV: kradzież, kradzież z włamaniem, rozbój, przywłaszczenie, **oszustwo art. 286**, oszustwo komputerowe art. 287, zniszczenie mienia, zabór pojazdu, paserstwo; art. 294 kwalifikacje wartościowe, art. 295 naprawienie szkody) | **Dz.U. 2025 poz. 383 t.j.** ✅ [VER: ELI DU/2025/383, RZĄD 1, 2026-10-04i] — ⛔ KROK 2C: 4 nowelizacje po t.j. (Dz.U. 2025 poz. 1818, 1872; 2026 poz. 902, 988) — **żadna nie zmienia art. 278–295**; kontrola krzyżowa z polem „Akty zmieniające” aktu pierwotnego ELI DU/1997/553 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art278-295-przestepstwa-przeciwko-mieniu.md | ✅ NOWY 2026-10-04i (AUDYT-2026-10-04i — zamknięcie luki pokrycia z AUDYT-2026-10-04g) |
| KK art. 286 — oszustwo | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art278-295-przestepstwa-przeciwko-mieniu.md (DRZEWO B); schemat zamiaru — modules/kwalifikator-karnomaterialny/part-03-oszustwa-gospodarcze.md | ✅ PRZEKIEROWANY 2026-10-04i (było: `mod-KK-KPK-framework-karne.md → ANEKS przestępstwa gospod.` — aneks nie jest opracowaniem art. 286) |
| KK art. 296 — nadużycie zaufania (menedżerskie) | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md → ANEKS przestępstwa gospod. | ✅ OK |
| KK art. 209 — niealimentacja | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md → ANEKS alimenty | ✅ OK |
| Kodeks postępowania karnego (KPK) | Dz.U. 2026 poz. 490 t.j. ze zm. (zm.: ⚡ 2026.638) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md | ✅ OK |
| KPK — tryby ścigania | Dz.U. 2026 poz. 490 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-tryby-scigania.md | ✅ OK |
| Kodeks karny wykonawczy (KKW) — warunkowe zwolnienie (159-163, w tym art. 161 §3-4 karencja: ⛔ POPRAWIONE 2026-08-22 — próg 5 lat/terminy 6 mies. lub rok, NIE 3/6 mies. jak wcześniej błędnie w module i tym wierszu), odroczenie/przerwa kary (150-158a), dozór elektroniczny (43a-43zf), prawa i obowiązki skazanego (101-120, kontrola osobista + skarga 7-dniowa), kary dyscyplinarne (142-149, katalog + przedawnienie 14/30 dni), **postępowanie wykonawcze (9-31, dodane 2026-08-22)** | Dz.U. 2026 poz. 1307 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) (obejmuje 2025/1423; poprzedni t.j. 2025/911) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KKW-kodeks-karny-wykonawczy.md | ✅ F-75 ZAMKNIĘTA W CAŁOŚCI 2026-08-20 — ⛔ ZSYNCHRONIZOWANE 2026-08-22 (F-83 kontynuacja): naprawiono błędny stan prawny art. 161 §3-4 przeniesiony tu z wcześniej błędnego stanu modułu, dodano sekcję postępowania wykonawczego; ✅ [VER] RZĄD 1 2026-09-10c (F-135): t.j. 2025/911 — obwieszczenie z 11.06.2025, akt bazowy 1997/557, najnowszy t.j. ⛔ KROK 2C: JEDNA nowelizacja po t.j. — ustawa z 26.09.2025 o zmianie KP oraz niektórych innych ustaw (Dz.U. 2025 poz. 1423). ⚠️ Weryfikacja dotyczy NUMERU t.j.; treść merytoryczna pozycji 0.4 i 0.5 pozostaje niesprawdzona |
| KKW — uzupełnienie pozostałych części (ogólna, penitencjarna, ograniczenie wolności, pozbawienie wolności poza sekcjami szczegółowymi, zwolnienie, środki, tymczasowe aresztowanie, część wojskowa) | Dz.U. 2026 poz. 1307 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KKW-uzupelnienie-pokrycia-2026.md | 🟡 B — usuwa dotychczasowe moduły-widma na poziomie operacyjnym |
| Ustawa o opłatach w sprawach karnych z 23.06.1973 r. | Dz.U. 2023 poz. 123 t.j. (obejmuje zmiany do Dz.U. 2022 poz. 2600; brak aktów zmieniających po t.j.) — RZĄD 1 ELI, status obowiązujący, odczyt 2026-10-04 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-ustawa-oplaty-w-sprawach-karnych.md | ✅ NOWY F-108/8, poziom B+ |
| Kodeks wykroczeń (KW) — current-state | Dz.U. 2025 poz. 734 t.j. ze zm.; fresh/temporal gate | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-current-state-COV.md + mod-KW-kodeks-wykroczen.md | 🟢 B+/COV — F-108/7 |
| KW Część ogólna (art. 1–48) — zasady odpowiedzialności, kary i środki karne, przedawnienie/zatarcie | Dz.U. 2025 poz. 734 t.j. ze zm. Dz.U. 2025 poz. 1676, 1814 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art1-48-czesc-ogolna.md | ✅ NOWY 2026-08-14 — F-67 (pierwszy systematyczny moduł części ogólnej, dotąd całkowicie nieobecny mimo bycia podstawą kwalifikacji każdej sprawy wykroczeniowej) |
| KPW — Kodeks postępowania w sprawach o wykroczenia | Dz.U. 2026 poz. 1336 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-KPW-framework-szczegolowy.md | ✅ OK |
| KKS + Ustawa AML | Dz.U. 2025 poz. 633 t.j. + Dz.U. 2025 poz. 644 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KKS-karny-skarbowy-i-AML.md | ✅ OK |
| Rozporządzenie MS w sprawie Funduszu Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej – Funduszu Sprawiedliwości | Dz.U. 2025 poz. 1298 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-ustawa-fundusz-pomocy-pokrzywdzonym.md (wskaźnik poprawiony T5 2026-09-16: mod-KK nie zawierał treści) | ✅ VER ELI 2026-08-26; usunięto błędne Dz.U. 2022 poz. 2256 (rozporządzenie rolne) |
| Ustawa z 7.07.2005 o państwowej kompensacie przysługującej ofiarom niektórych przestępstw | Dz.U. 2016 poz. 325 t.j. (brak aktów zmieniających po t.j.) ✅ [VER] RZĄD 1 2026-10-04 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-ustawa-fundusz-pomocy-pokrzywdzonym.md | ✅ OK |
| Ustawa o przeciwdziałaniu narkomanii — ROZBUDOWANE 2026-07-20: marihuana lecznicza (art. 33a), leczenie substytucyjne (art. 28-28b), prekursory (rozp. UE 273/2004, 111/2005) | Dz.U. 2023 poz. 1939 t.j. ✅ VER: 2026-06-14 (TRYB DZU). ✅ NOWELIZACJA ZIDENTYFIKOWANA 2026-08-15z (F-24 ZAMKNIĘTA): ustawa z **3.07.2026** — **Dz.U. 2026 poz. 1004**, ogłoszona 27.07.2026, w życie 27.08.2026 (30 dni od ogłoszenia, data wyliczona). ⚠️ Dawna „nowelizacja z 11.06.2026" to wersja sejmowa sprzed poprawek Senatu — nie powoływać tej daty | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-ustawa-narkomania.md | ✅ OK |
| Ustawa o odpowiedzialności podmiotów zbiorowych | Dz.U. 2024 poz. 1822 t.j. ✅ VER: 2026-06-14 (TRYB DZU — uwaga: nowelizacja 2025/1440 wchodzi 01.03.2026, nowy art. 9a) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-ustawa-odpowiedzialnosc-podmiotow-zbiorowych.md | ✅ OK |
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym i ochronie małoletnich (Rejestr Sprawców, "Ustawa Kamilka") | Dz.U. 2026 poz. 110 t.j. (obwieszczenie 21.01.2026) — całkowicie nieobecna w ROUTING-MAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md (BLOK J) | ✅ DODANE 2026-08-19 |
| KPK — oczekująca nowelizacja 2026.638 | Dz.U. 2026 poz. 638 (ustawa z 27.03.2026, publ. 13.05.2026, zmienia art. 25 §1 pkt 2 KPK) ✅ KOREKTA 2026-09-22 (F-195): W MOCY od 28.05.2026 — art. 3, 14 dni od ogłoszenia; ✅ [VER: api.sejm.gov.pl/eli, DU/2026/638, 2026-09-22]. Zapis historyczny: VER 2026-07-13: prawdopodobnie już w mocy (standardowe 14-dniowe vacatio od publikacji → ok. 27.05.2026), wymaga jednoznacznego potwierdzenia terminu w ISAP przed zamknięciem wpisu. ✅ ROZSTRZYGNIĘTE T5 2026-09-16, RZĄD 1 ELI: **w życie 28.05.2026**; zmienia art. 25 § 1 pkt 2 KPK (katalog spraw okręgowych) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md (⚠️ moduł nie powołuje tej zmiany — powołują ją mod-KW-kodeks-wykroczen i mod-KK-art190a-stalking) | ✅ W MOCY od 28.05.2026 |
| KPK — zmiana 2025.1390 | ⚠️ NUMER BŁĘDNY — VER 2026-07-13: Dz.U. 2025 poz. 1390 to rozporządzenie MF ws. wyłączenia poboru zryczałtowanego CIT (isap WDU20250001390), NIE dotyczy KPK. Wpis pierwotny wskazywał niewłaściwy numer — właściwy Dz.U. dla zamierzonej zmiany KPK wymaga ponownego ustalenia | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-tryby-scigania.md | ❌ NUMER BŁĘDNY |
| **Prawo o ruchu drogowym (PRD)** | Dz.U. 2024 poz. 1251 t.j. ze zm. (po t.j., w mocy do 2026-10-06: Dz.U. 2025 poz. 1676, 1734, 1843; Dz.U. 2026 poz. 180, 982; zapowiedź: Dz.U. 2026 poz. 875 od 01.01.2027) ✅ [VER] 2026-10-06 ELI | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-PRD-prawo-jazdy-punkty-karne.md | ✅ OK |
| **Grzywna/mandat/kara adm./grzywna przymuszenia** | KW Dz.U. 2025 poz. 734 + KPSW Dz.U. 2026 poz. 1336 + KPA Dz.U. 2025 poz. 1691 Dz. IVa + UPEA ✅ **SKORYGOWANE 2026-10-12: Dz.U. 2026 poz. 1311** t.j. (ogł. 9.10.2026; obejmuje zm. 2026/516, 739 i 1003; art. 17 § 1a w dwóch brzmieniach — dotychczasowym do 27.10.2026 i nadanym art. 116 ustawy 2026/1003 od 28.10.2026 (odnośniki 13–14 t.j.); brak zmian po t.j. (ELI 2026-10-12, obwieszczenie odczytane); poprzedni t.j. 2026/268 wraz ze zm. 2026/516 i 2026/739 zastąpiony) — wcześniej F-89 (2026-08-19): poprzedni numer "2023 poz. 2505" był NIEAKTUALNY o dwa pełne cykle tekstu jednolitego (2023.2505→2025.132→2026.268), lokalna mapa dr-03 już to poprawiła 2026-07-02, teraz zsynchronizowane | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-grzywny-mandaty-szczegolowe.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| Rozp. PRM z 24.11.2003 w sprawie wysokości grzywien nakładanych w drodze mandatów karnych za wybrane rodzaje wykroczeń (taryfikator) | Dz.U. 2013 poz. 1624 t.j. ze zm. (tabela B w brzmieniu Dz.U. 2021 poz. 2484; ostatnia zmiana Dz.U. 2023 poz. 1256) ✅ [VER] RZĄD 1 2026-10-04 ⛔ NIE Dz.U. 2026 poz. 724 (punkty karne) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-grzywny-mandaty-szczegolowe.md | ✅ OK — kwoty z odczytu ELI |
| **Ustawa o kierujących pojazdami (u.k.p.)** | Dz.U. 2025 poz. 1226 t.j. ze zm. Dz.U. 2025 poz. 1676 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-PRD-prawo-jazdy-punkty-karne.md | ✅ OK |
| **Ustawa BRD I** — pj od 17 lat, cofnięcie, cyfrowe pj | Dz.U. 2025 poz. 1676 (w życie od 01.2026 etapami — weryfikuj) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-PRD-prawo-jazdy-punkty-karne.md (cofnięcie, okres próbny) + mod-PRD-nowe-przestepstwa-drogowe-BRD (pj od 17 lat) | ✅ OK |
| **Ustawa BRD II** — nielegalne wyścigi, drift, brawurowa jazda, przepadek | Dz.U. 2025 poz. 1872 (w życie 29.01.2026, 30.03.2026, 03.06.2026) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-PRD-nowe-przestepstwa-drogowe-BRD.md + mod-KW-KPW-framework-szczegolowy | ✅ OK — 2026-07-20: wypełniono placeholdery (dożywotni zakaz art. 42 §3, nowy obowiązkowy zakaz art. 42 §1a, podwyższone dolne granice kar) |
| Ustawa z 7.11.2025 — zmiana KW/KPW (art. 82 — usunięcie kary nagany, mandat do 5000 zł) | Dz.U. 2025 poz. 1814 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art49-64-porzadek-publiczny.md (art. 82 punkt startowy) + mod-KW-kodeks-wykroczen | ✅ NOWY 2026-07-20, odpowiedź na polecenie sprawdzenia aktualizacji prawa karnego |
| Ustawa z 7.11.2025 — zmiana KK/KW/KPW (art. 217a KK — ochrona interweniujących cywilnie; art. 51 KW — minimum 1000 zł) | Dz.U. 2025 poz. 1818 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art222-226-ochrona-funkcjonariusza.md (nowa sekcja) + mod-KW-art49-64-porzadek-publiczny | ✅ NOWY 2026-07-20 |
| **Rozp. MSWiA — ewidencja kierujących** (taryfikator punktów, kody, szkolenia) | Dz.U. 2026 poz. 724 (w życie 03.06.2026) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-PRD-prawo-jazdy-punkty-karne.md | ✅ OK |
| KK art. 18-22 — formy popełnienia (sprawstwo, podżeganie, pomocnictwo) | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art18-22-formy-popelnienia.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 10 — odpowiedzialność nieletnich | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art10-odpowiedzialnosc-nieletnich.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 64 — recydywa | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art64-recydywa.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 69-84 — warunkowe zawieszenie/zwolnienie | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art69-84-warunkowe-zawieszenie-zwolnienie.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 101-105 — przedawnienie karalności | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art101-105-przedawnienie-karalnosci.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 148-162 — przeciwko życiu i zdrowiu | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art148-162-przeciwko-zyciu-zdrowiu.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 212-216 — przeciwko czci | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art212-216-przeciwko-czci.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 222-226 — ochrona funkcjonariusza | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art222-226-ochrona-funkcjonariusza.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 228-231 — korupcja urzędnicza | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art228-231-korupcja-urzednicza.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 233-244b — przeciwko wymiarowi sprawiedliwości (poplecznictwo, świadek koronny) + NOWY art. 240 KK (niezawiadomienie) + NOWY KPK art. 278-280 (list gończy krajowy) — ROZBUDOWANE 2026-07-21 | Dz.U. 2025 poz. 383 ze zm. + Dz.U. 2026 poz. 490 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art233-244b-przeciwko-wymiarowi-sprawiedliwosci.md | ✅ OK |
| KK art. 250a — korupcja wyborcza | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art250a-korupcja-wyborcza.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 255b — patostreaming | KK: Dz.U. 2025 poz. 383 t.j. ze zm.; art. 255b dodany Dz.U. 2026 poz. 988, obowiązuje od 23.08.2026 r. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art255b-patostreaming.md | ✅ WERYFIKACJA URZĘDOWA 2026-08-26 — data wejścia zgodna z art. 2 ustawy i metadanymi ELI |
| KK art. 263 — nielegalny wyrób/handel/posiadanie broni palnej i amunicji | Dz.U. 2025 poz. 383 ze zm. + ustawa o broni i amunicji (1999) ⚠️ zweryfikuj t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art263-bron-nielegalna.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) — ✅ [VER] RZĄD 1 2026-09-10f — Dz.U. 2025 poz. 383 potwierdzony jako najnowszy tekst jednolity KK. ⛔ KROK 2C: CZTERY nowelizacje po nim — Dz.U. 2025 poz. 1818, 2025 poz. 1872, 2026 poz. 902, 2026 poz. 988. Brzmienie każdego artykułu KK czytać u źródła, tekst jednolity NIE oddaje stanu bieżącego. |
| KK art. 270-277d, 310 — fałszerstwa dokumentów, pieniędzy i papierów wartościowych | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art270-310-falszerstwa-dokumentow.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 296 — nadużycie zaufania (menedżerskie), opracowanie szczegółowe | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art296-naduzycie-zaufania.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 296a — korupcja w sektorze prywatnym | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art296a-korupcja-sektor-prywatny.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 305 — zmowa przetargowa (karna) | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art305-zmowa-przetargowa-karna.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 127-139 — przeciwko RP (szpiegostwo, zdrada, dezinformacja wywiadowcza) | Dz.U. 2025 poz. 383 ze zm. ⚠️ art. 130 zmieniony reformą 17.08.2023, re-weryfikuj | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art127-139-przeciwko-RP.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) — ✅ [VER] RZĄD 1 2026-09-10f — KK jw.: cztery nowelizacje po tekście jednolitym (2025/1818, 2025/1872, 2026/902, 2026/988). ⛔ KROK 2C obowiązkowy. |
| KK art. 163-172 — bezpieczeństwo powszechne (w tym infrastruktura krytyczna, art. 165 §1 pkt 3-4) | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art163-172-bezpieczenstwo-powszechne.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK art. 181-188a — przeciwko środowisku | Dz.U. 2025 poz. 383 ze zm. ze zm. Dz.U. 2022 poz. 1726 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art181-188a-przeciwko-srodowisku.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| Słupy (KK art. 18/286/297/296) + KSH + KC — fikcyjna reprezentacja spółki | wielość aktów, patrz DR-03/MAPA-AKTOW | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-slupy-fikcyjna-reprezentacja-spolki.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK — cyberprzestępstwa, opracowanie szczegółowe | Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-cyberprzestepstwa-szczegolowy.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KK — przemoc domowa, opracowanie szczegółowe | Dz.U. 2025 poz. 383 ze zm. + Dz.U. 2024 poz. 1673 t.j. (✅ [VER] RZĄD 1 2026-09-16e; było `2021/1249` — wygasły) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-przemoc-domowa-szczegolowy.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KPK — framework szczegółowy | Dz.U. 2026 poz. 490 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-szczegolowy.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KPK — mediacja i sprawiedliwość naprawcza (art. 23a, art. 320 i n.) | Dz.U. 2026 poz. 490 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-mediacja-sprawiedliwosc-naprawcza.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KPK — współpraca międzynarodowa karna | Dz.U. 2026 poz. 490 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-wspolpraca-miedzynarodowa-karna.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KW art. 119-131 — przeciwko mieniu | Dz.U. 2025 poz. 734 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art119-131-przeciwko-mieniu.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KW art. 49-64 — porządek publiczny | Dz.U. 2025 poz. 734 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art49-64-porzadek-publiczny.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KW art. 65-69 — instytucje państwowe, samorządowe i społeczne | Dz.U. 2025 poz. 734 t.j. ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art65-69-instytucje.md | 🟢 B+/COV zakresu — domknięcie luki F-108/7 |
| KW art. 70-118 — bezpieczeństwo osoby/zdrowie (Rozdz. X, XII, XIII) | Dz.U. 2025 poz. 734 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art70-118-bezpieczenstwo-osoba-zdrowie.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| KW art. 132-166 — pozostałe rozdziały (konsumenci, obyczajność, urządzenia publiczne, ewidencja, szkodnictwo leśne) | Dz.U. 2025 poz. 734 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-art132-166-pozostale-rozdzialy.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| Przymusowe leczenie odwykowe (alkohol/narkotyki) | ⚠️ zweryfikuj akt właściwy na ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-przymusowe-leczenie-odwykowe.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| Świadek koronny (duży, ustawa 1997) i mały świadek koronny (KK art. 60 §3-4) | ⚠️ zweryfikuj t.j. ustawy na ISAP + Dz.U. 2025 poz. 383 ze zm. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-swiadek-koronny-duzy-maly.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) — ✅ [VER] RZĄD 1 2026-09-10f — KK jw.: cztery nowelizacje po tekście jednolitym. ⛔ KROK 2C obowiązkowy. |
| Tajemnica zawodowa i poufność (adwokacka/radcowska/inne) | ⚠️ zweryfikuj akty właściwe na ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-tajemnica-zawodowa-poufnosc.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — pull z DR-03/MAPA-AKTOW) |
| Fundusz Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej (Fundusz Sprawiedliwości) — podstawa ustawowa: art. 43 KKW (Dz.U. 2026 poz. 1307 t.j.); organizację Funduszu określa ROZPORZĄDZENIE Ministra Sprawiedliwości | ✅ SKORYGOWANE 2026-08-21 (F-89, T11): t.j. **Dz.U. 2025 poz. 1298** (obwieszczenie 19.09.2025), poprzedni t.j. 2024.1605 (obwieszczenie 23.10.2024). Numer "2022.2256" cytowany wcześniej BŁĘDNY, nie odpowiadał żadnemu potwierdzonemu dokumentowi (poprawka lokalnie w dr-03/MAPA-AKTOW z 2026-07-04, teraz zsynchronizowana z ROUTING-MAP) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-ustawa-fundusz-pomocy-pokrzywdzonym.md | ✅ ZSYNCHRONIZOWANE 2026-08-21 |
| Lincz/bójka-pobicie (art. 158-159 KK), statusy więźniów N/chroniony (KKW), zmowa milczenia (art. 233 KK), łowcy pedofili | ⚠️ zweryfikuj t.j. KK/KKW na ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-lincz-ochrona-swiadkow-lowcy-pedofili.md | ✅ NOWY 2026-08-04 — DOPISANE 2026-08-05 (sync) |
| Ustawa o ochronie i pomocy dla pokrzywdzonego i świadka | Dz.U. 2026 poz. 1306 t.j. (stan prawny 30.09.2026; obejmuje 2024/1228; brak zmian po t.j.) ✅ VER 2026-10-17 RZĄD 1 | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-lincz-ochrona-swiadkow-lowcy-pedofili.md | ✅ OK |
| Przeróbki pojazdów: hulajnogi (⚡ projekt, F-14), przyciemnianie szyb, pojazdy "SAM", motocykle A2, tachografy | ⚠️ WIELE aktów, część PROJEKTAMI | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-przerobki-modyfikacje-pojazdow.md | ✅ NOWY 2026-08-04, ROZBUDOWANY 2026-08-05 — DOPISANE 2026-08-05 (sync) |
| Podmiana części przez warsztat naprawczy (art. 286/284 KK) | ⚠️ zweryfikuj t.j. KK na ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-podmiana-czesci-naprawa-oszustwo.md | ✅ NOWY 2026-08-04 — DOPISANE 2026-08-05 (sync) |
| Nielegalny pobór mediów (prąd art. 278§5 KK, woda Dz.U. 2024 poz. 757, WiFi art. 267 KK) | ✅ ustawa o zbiorowym zaopatrzeniu w wodę: Dz.U. 2024 poz. 757 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-nielegalny-pobor-mediow.md | ✅ NOWY 2026-08-05 — DOPISANE 2026-08-05 (sync) |
| KPK art. 266-269 — poręczenie majątkowe (kaucja karna) | Dz.U. 2026 poz. 490 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-poreczenie-majatkowe-kaucja-karna.md | ✅ NOWY 2026-07-19 — ⚠️ PRZENIESIONY 2026-08-14e z sekcji DR-08 do DR-03 (orphan-row wykryty KROKIEM D REGUŁY 3: moduł należy do dr-03, a wiersz stał pod DR-08 od 2026-07-19) |
| KPK art. 17 + art. 156 (dostęp do akt) + art. 193-206 (biegli) + art. 313 + art. 425-440 (CAŁY Rozdz. 48 — przepisy ogólne postępowania odwoławczego, w tym pełny 437) + art. 485-499 (oskarżenie prywatne) + art. 568a-577 (wyrok łączny) | Dz.U. 2026 poz. 490 t.j. — ⚠️ metryka pomija Dz.U. 2026 poz. 421/2026.638; ⚠️ art. 575§1, 156§5, 437§1 — TRZY rozbieżności wersji czasowych nierozstrzygnięte (patrz moduł) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-podstawy-odwolawcze-przeslanki-zarzuty-biegli.md | ✅ NOWY + ROZSZERZONE 2026-08-15 (7 sesji), naprawa CZĘŚCIOWA F-66 |
| Rejestracja current-state: Kodeks karny | bieżący stan ELI/ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: Kodeks postępowania karnego | bieżący stan ELI/ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPK-current-state-COV.md | ✅ current-state COV |
| Rejestracja current-state: Kodeks karny wykonawczy | bieżący stan ELI/ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KKW-current-state-COV.md | ✅ current-state COV |
| KPW — indeks current-state | bieżący stan ELI/ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KPW-kodeks-postepowania-w-sprawach-o-wykroczenia.md | ✅ current-state COV |
| Narkomania — indeks current-state | bieżący stan ELI/ISAP | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-narkomania-current-state-COV.md | ✅ current-state COV |

---

## DR-04 — Prawo Pracy, ZUS, Świadczenia Społeczne

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| KPA (odesłanie — moduł fizycznie w DR-05, PRZENIESIONY 2026-07-19) | Dz.U. 2025 poz. 1691 ze zm. | → DR-05/mod-KPA-postepowanie-administracyjne | 🔗 odesłanie |
| PPSA (odesłanie — moduły fizycznie w DR-05) | Dz.U. 2026 poz. 143 ze zm. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-terminy-kasacja-prawo-pomocy.md + dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-posiedzenia-sadowe-rozdzial-7.md + dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-orzeczenia-sadowe-rozdzial-10.md | 🔗 odesłanie do rzeczywistych modułów PPSA |
| Ustawa o ochronie konkurencji i konsumentów (UOKiK) — konsumenci / praktyki rynkowe; platformy cyfrowe wymagają równolegle DSA | Dz.U. 2025 poz. 1714 t.j. ✅ [VER] RZĄD 1 2026-09-16d (⛔ PODMIANA AKTU usunięta: poprzedni zapis `2024 poz. 1221` to Prawo komunikacji elektronicznej) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-UOKIK-antymonopolowe.md + dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-prawa-konsumenta.md; dla platform: dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-DSA-digital-services-act.md | ✅ ROUTING SEMANTYCZNY; nie używaj misplaced kopii DR-04 jako PRIMARY |

---

## DR-05 — Prawo Administracyjne i Sądownictwo Administracyjne

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| KPA — postępowanie administracyjne (kanoniczny, PRZENIESIONY 2026-07-19 z DR-04) | Dz.U. 2025 poz. 1691 ze zm. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md | ✅ OK — rozbudowany 2026-07-19 (ugoda, milczące załatwienie, zaświadczenia, skargi/wnioski) |
| PPSA — sądownictwo administracyjne (kanoniczne moduły DR-05) | Dz.U. 2026 poz. 143 ze zm. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-terminy-kasacja-prawo-pomocy.md + dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-posiedzenia-sadowe-rozdzial-7.md + dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-orzeczenia-sadowe-rozdzial-10.md | ✅ OK — routing do modułów PPSA, nie KPA |
| PPSA — uzupełnienie pozostałych działów (właściwość/skład/wyłączenie, strony, pełnomocnicy, pisma, doręczenia, terminy, mediacja/uproszczone, zawieszenie, prawomocność, zażalenie, uchwały NSA, środek z 285a–285l, wykonanie) | Dz.U. 2026 poz. 143 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-uzupelnienie-pokrycia-2026.md | 🟡 B+ — operacyjne zamknięcie luk zerowych |
| Ordynacja podatkowa | Dz.U. 2026 poz. 622 t.j. ⚠️ ZE ZM. (sync 2026-08-15z): **Dz.U. 2026 poz. 825** (w życie 24.09.2026 — interpretacje indywidualne JST w systemie EUREKA) i **Dz.U. 2026 poz. 846** (w życie 1.10.2026 — omnibus 16 obszarów, m.in. MDR; flaga F-88). (obwieszczenie 22.04.2026, publ. 11.05.2026, stan prawny 21.04.2026) ⚡ część przepisów nowelizujących OP ma odroczone wejście (część ok. IX.2026, część do 16 mies. od ogłoszenia zmieniającej ustawy) ✅ VER 2026-07-13: 622 to sam TEKST JEDNOLITY, nie nowelizacja — data ~IX.2026 dotyczy przepisów zmieniających wcześniej wprowadzonych, nie samego t.j. + 2026-08-11: uzupełniono luki fundamentalne (decyzja, nadpłata, kontrola podatkowa, tajemnica skarbowa, pełnomocnictwo) — mapa pokrycia 🟢 4→9/18 | → DR-06/mod-OP-ordynacja-podatkowa (v1.1.0) | 🔗 odesłanie |
| UDIP — dostęp do informacji publicznej | Dz.U. 2022 poz. 902 ze zm. — weryfikuj t.j. w ISAP | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-UDIP-dostep-informacji-publicznej.md | ✅ OK — ✅ [VER] RZĄD 1 2026-09-10f — Dz.U. 2022 poz. 902 potwierdzony jako najnowszy tekst jednolity UDIP. ⛔ KROK 2C: jedna nowelizacja po nim — Dz.U. 2025 poz. 1844. |
| Ustawa o otwartych danych i re-use | Dz.U. 2023 poz. 1524 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-UDIP-dostep-informacji-publicznej.md | ✅ OK |
| Ustawa o skargach na przewlekłość | Dz.U. 2023 poz. 1725 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-skargi-przewleklosc-dostep-sadu.md | ✅ OK |
| UPEA — egzekucja administracyjna | Dz.U. 2026 poz. 1311 t.j. (obwieszczenie z 1.09.2026, ogł. 9.10.2026; obejmuje zm. 2026/516, 739 i 1003; art. 17 § 1a w dwóch brzmieniach — dotychczasowym do 27.10.2026 i nadanym art. 116 ustawy 2026/1003 od 28.10.2026 (odnośniki 13–14 t.j.); brak zmian po t.j. (ELI 2026-10-12, obwieszczenie odczytane); zastąpił t.j. 2026/268 ze zm. 2026/516, 2026/739) (⛔ KOREKTA: usunięto „+ Dz.U. 2026 poz. 532 t.j.” — to t.j. ustawy „Aktywny rodzic”) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-UPEA-egzekucja-administracyjna.md | ✅ OK |
| Ustawa o cudzoziemcach (framework) | Dz.U. 2025 poz. 1079 t.j. ze zm. (zm.: 2025.619 Niebieska Karta; 2025.1794; 2026.203) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-cudzoziemcy.md | ✅ OK |
| Ustawa o warunkach dopuszczalności powierzania pracy cudzoziemcom | ✅ **SKORYGOWANE 2026-08-19 (F-89):** Dz.U. 2025 poz. 621 (w życie 01.06.2025), ze zm. 2025.1794, 2026.203, 2026.473, 2026.734, Dz.U. 2026 poz. 1072 (rozp. wykonawcze MRPiPS z 31.07.2026 ws. wykazu państw wyłączonych z pracy w ruchu bezwizowym — Wenezuela, Gruzja, Kolumbia, w życie 22.08.2026) — łańcuch nowelizacji zsynchronizowany z lokalną mapą dr-05 — ⭐ SYNC 2026-08-22: dopisane DWA powiązane, ale ODRĘBNE rozporządzenia MSZ z 10.08.2026 (Dz.U. 2026 poz. 1085 i 1086) — obowiązek wizowy przy WJEŹDZIE dla tych samych 3 państw, w mocy od 12-16.08.2026, inny minister/inna podstawa (rozp. UE 2018/1806), nie mylić z rozp. MRPiPS o pracy | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-cudzoziemcy-zatrudnianie.md | ✅ ZSYNCHRONIZOWANE 2026-08-22 (treść modułu w pełni opracowana, sekcja 0) |
| Ustawa o udzielaniu ochrony cudzoziemcom | Dz.U. 2026 poz. 862 t.j. ✅ VER 2026-07-04 (POPRAWKA — było 2024.1546) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-cudzoziemcy.md | ✅ OK |
| Ustawa o Rzeczniku Praw Obywatelskich | Dz.U. 2024 poz. 1264 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-RPO.md | ✅ OK |
| Ustawa o Rzeczniku Praw Dziecka | Dz.U. 2023 poz. 292 t.j. — dodane 2026-07-27, na żądanie użytkownika | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-RPD.md | ✅ NOWY 2026-07-27 |
| Ustawa o samorządowych kolegiach odwoławczych (SKO) | Dz.U. 2018 poz. 570 t.j. ✅ VER 2026-07-04 (POPRAWKA — było błędnie 2023.825) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-SKO.md | ✅ OK |
| Ustawa o kontroli w administracji rządowej | Dz.U. 2026 poz. 158 t.j. (sync 2026-07-02 z dr-05) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-kontrola-administracji.md | ✅ OK |
| Ustawa o petycjach | Dz.U. 2018 poz. 870 — weryfikuj t.j. w ELI (RZĄD 1) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-petycje.md | ✅ OK |
| Ustawa o sygnalistach | Dz.U. 2024 poz. 928 ze zm. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-sygnalisci.md | ✅ OK |
| Zaskarzanie decyzji / reprywatyzacja | Dz.U. 2025 poz. 1691 (KPA art. 156) + Dz.U. 2021 poz. 795 | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-zaskarzanie-decyzji-wlasnosci.md | ✅ OK |
| Ustawa o dostępności — osoby ze szczególnymi potrzebami | Dz.U. 2024 poz. 1411 t.j. (sync 2026-07-02 z dr-05/dr-10) | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-dostepnosc-niepelnosprawni.md | ✅ OK |
| PPSA — uchybienie/przywrócenie terminu (85-89), skarga kasacyjna do NSA (173-193, przymus adwokacko-radcowski), koszty postępowania/wpis/opłata kancelaryjna (199-242), prawo pomocy (245-259, referendarz jako organ I instancji) | Dz.U. 2026 poz. 143 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-terminy-kasacja-prawo-pomocy.md | ✅ NOWY 2026-08-14 — DOPISANE 2026-08-14 (sync) — naprawa F-64, PIERWSZY dedykowany moduł PPSA w całym systemie (dotąd ustawa istniała wyłącznie jako rozproszone cytaty). ROZSZERZONY 2026-08-22 — naprawa poz. #9 mapy pokrycia, koszty/wpis/opłata kancelaryjna — SYNC REGUŁA 3 |
| PPSA — Dział III Rozdz. 7, posiedzenia sądowe (90-114): kierowanie sprawy na rozprawę mimo trybu niejawnego (90 §2), zawiadomienie 7/3 dni (91 §2), drzwi zamknięte (96-97), przebieg rozprawy i ⭐ JEDYNE okno dowodowe — dowód uzupełniający WYŁĄCZNIE z dokumentów (106 §3), odroczenie obligatoryjne (109), ⭐⭐⭐ zastrzeżenie do protokołu — brak = utrata zarzutu w NSA (105), protokół i załącznik (100-104), grzywna dla organu (112), zamknięcie rozprawy (113-114) | Dz.U. 2026 poz. 143 t.j. ze zm. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-posiedzenia-sadowe-rozdzial-7.md | ✅ NOWY 2026-08-22, SYNC 2026-08-22 (REGUŁA 3, przy F-83 priorytet #6) — drugi dedykowany moduł PPSA |
| PPSA — Dział III Rozdz. 10, orzeczenia sądowe (132-167a): granice orzekania i zakaz reformationis in peius (134), ⭐⭐⭐ uwzględnienie skargi na decyzję/postanowienie — trzy rodzaje rozstrzygnięć, dotąd nieobecne mimo najczęstszej kategorii spraw (145), skargi na interpretacje podatkowe (146), oddalenie skargi (151), bezczynność/przewlekłość z sankcjami do 89 035,60 zł (149), ⭐⭐⭐ związanie oceną prawną sądu (153), umorzenie postępowania (161) | Dz.U. 2026 poz. 143 t.j. ze zm. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-orzeczenia-sadowe-rozdzial-10.md | ✅ NOWY 2026-08-22, SYNC REGUŁA 3 — naprawa poz. #8 mapy pokrycia, ostatnia z oryginalnej ósemki, trzeci dedykowany moduł PPSA |
| KPA — decyzja administracyjna i odwołanie (elementy, procedura, postanowienia, zażalenia) | Dz.U. 2025 poz. 1691 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-decyzja-i-odwolanie.md | RODZINA KPA (NOTA-4); SYNC REGUŁA 3, 2026-08-14e (F-77 rozszerzona) |
| KPA — mechanizmy w toku sprawy (zawieszenie, dowody, rozprawa) | Dz.U. 2025 poz. 1691 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-mechanizmy-w-toku-sprawy.md | RODZINA KPA (NOTA-4); SYNC REGUŁA 3, 2026-08-14e (F-77 rozszerzona) |
| KPA — tryby nadzwyczajne, bezczynność, kary, skarga do WSA, strategia | Dz.U. 2025 poz. 1691 t.j. | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-tryby-nadzwyczajne-i-strategia.md | RODZINA KPA (NOTA-4); SYNC REGUŁA 3, 2026-08-14e (F-77 rozszerzona) |
| Rejestracja current-state: KPA | bieżący stan ELI/ISAP | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-current-state-COV.md | ✅ current-state COV |
| Wojewoda i administracja rządowa — moduł lokalny DR-05 | bieżący stan ELI/ISAP | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-wojewoda-administracja-rzadowa.md | ✅ aktywny |

---

## DR-06 — Podatki, Finanse Publiczne, AML

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| KKS — kodeks karny skarbowy | Dz.U. 2025 poz. 633 t.j. | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KKS-karny-skarbowy-i-AML.md | ✅ KANONICZNY DR-03; KAS proceduralnie pozostaje w DR-06 |

---

## DR-07 — Zamówienia Publiczne, Fundusze UE, Pomoc Publiczna

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| PZP — zamówienia obronne i bezpieczeństwa | Dz.U. 2026 poz. 793 t.j. (sync 2026-07-02) | → DR-15/mod-PZP-zamowienia-obronne-bezpieczenstwa | 🔗 odesłanie |
| Ustawa o finansach publicznych | → DR-06/mod-UFP-finanse-publiczne-NIK-RIO | → DR-06 | 🔗 odesłanie |

---

## DR-08 — Samorząd Terytorialny i Prawo Lokalne

*Źródło: dr-08/MAPA-AKTOW.md | Weryfikacja: 2026-06-08*

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa z 1.07.2011 o samorządzie pielęgniarek i położnych — Rozdz. 6 "Odpowiedzialność zawodowa" (art. 36-88), sądy pielęgniarek i położnych (I/II instancja) | Dz.U. 2025 poz. 1760 t.j. (obwieszczenie 24.11.2025) — była CAŁKOWICIE nieobecna w ROUTING-MAP mimo że w obu lokalnych mapach dr-10 i dr-12 (naprawiono F-53, 2026-08-13, wykryte przez DR-12) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-pielegniarka-polozna.md (sekcja "Odpowiedzialność dyscyplinarna") + dr-12/MAPA-AKTOW.md (sądownictwo dyscyplinarne) | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| Ustawa o Wojewodzie i administracji rządowej w województwie | Dz.U. 2025 poz. 428 t.j. — RZĄD 1 ELI | dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-wojewoda-administracja-rzadowa.md | ✅ F-108/45 P3 — dedykowany moduł B+; DR-08 zachowuje wtórny kontekst nadzoru JST |

---

## DR-09 — Budownictwo, Środowisko, Energia, Transport

*Źródło: dr-09/MAPA-AKTOW.md | Weryfikacja: 2026-06-05; PPWR i EUDR dopisane 2026-09-13*

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Prawo łowieckie — kontrola pokrycia całej ustawy (Rozdz. 1-11) | t.j. Dz.U. 2025 poz. 539 | dr-09/modules/ (poza pluginem) — 11 modułów łowieckich | ✅ **POKRYCIE KOMPLETNE 12/12 rozdziałów (2026-08-17d)** — wiersz katalogowy zaktualizowany: poprzednia treść („Rozdz. 6a — BRAK modułu") była NIEAKTUALNA od 2026-08-16e, gdy powstał mod-lowieckie-odpowiedzialnosc-dyscyplinarna-PZL; flaga F-91 ZAMKNIĘTA |
| ⛔ **EUDR — rozporządzenie (UE) 2023/1115** (produkty niepowodujące wylesiania) | **CELEX `32023R1115`**, wersja skonsolidowana `02023R1115-20251226` ✅ VER RZĄD 1 2026-09-13. ⛔⛔ Data stosowania **przesuwana dwukrotnie**: art. 38 ust. 2 — **30.12.2026**; ust. 3 — **30.06.2027** dla osób fizycznych oraz mikro- i małych przedsiębiorstw ustanowionych do 31.12.2024 | jw. | ✅ NOWY 2026-09-13 — ⛔ powtarzane daty 30.12.2025 / 30.06.2026 są NIEAKTUALNE. ⚠️ ZWERYFIKOWANE 2026-09-13b: przeszukanie ELI po tytule (`wylesianie`, `wylesianiem`, `niepowodujących wylesiania`) — **zero polskich aktów**; wynik negatywny **wyłącznie w zakresie tytułu**. Termin stosowania 30.12.2026 — monitorować bliżej daty |
| Ustawa o delegowaniu kierowców w transporcie drogowym (28.07.2023) | **Dz.U. 2025 poz. 797 t.j.** ✅ [VER] RZĄD 1 2026-09-10i — obwieszczenie Marszałka Sejmu z 11.06.2025, zero nowelizacji po tekście jednolitym. Akt bazowy: Dz.U. 2023 poz. 1523 (w życie 19.08.2023), status „akt posiada tekst jednolity". ⛔ **ADNOTACJA SKORYGOWANA:** wiersz twierdził „(brak t.j.)" i wymieniał `2025.797` jako **nowelizację** — 2025/797 jest tekstem jednolitym tej ustawy, nie zmianą. Podwójny błąd: nieprawdziwe „brak t.j." plus zła kwalifikacja typu aktu — implementacja dyr. 2020/1057 (pakiet mobilności) | — BRAK modułu dedykowanego (temat reaktywny; przy sprawie transportowo-pracowniczej → dr-04 (poza pluginem)) | ⚠️ WIERSZ KATALOGOWY, dodany 2026-08-15z (F-82 pkt 3): numer 1523 był historycznie mylony z Kodeksem morskim we WSZYSTKICH trzech rejestrach — własny wiersz eliminuje ryzyko powrotu tej pomyłki |

---

## DR-10 — Zdrowie, Farmacja, Żywność, Rolnictwo

*Źródło: dr-10/MAPA-AKTOW.md | Weryfikacja: 2026-06-05*

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Prawo farmaceutyczne | Dz.U. 2026 poz. 612 t.j. (zm.: 2025.1537 ✅ w pełni w mocy od 01.07.2026 — art. 1 pkt 2 lit. c, pkt 3-4 dot. art. 23f, VER 2026-07-13; sprawdzić czy treść modułu odzwierciedla wymogi ws. danych osoby wystawiającej receptę — patrz WARN-OTWARTE) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-PrFarm-prawo-farmaceutyczne.md | ✅ OK |
| Plan dla Chorób Rzadkich + Rozp. WE 141/2000 (leki sieroce) | ⚠️ Plan to dokument programowy — zweryfikuj edycję na chorobyrzadkie.gov.pl | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-rzadkie-choroby-genetyczne-plan-leki-sieroce.md | ✅ NOWY 2026-07-20 |
| GIF/GIS/WIF — nadzór farmaceutyczny | Dz.U. 2026 poz. 612 (GIF) + Dz.U. 2024 poz. 416 t.j. (GIS, sync 2026-07-02 — było błędnie 2023.394) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-GIF-GIS-nadzor-farmaceutyczny-sanitarny.md | ✅ OK |
| Rozp. REACH + CLP — chemikalia | Rozp. (WE) 1907/2006 + 1272/2008 | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-REACH-CLP-chemikalia.md | ✅ OK |
| Ustawa o działalności leczniczej | Dz.U. 2026 poz. 156 t.j. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-dzialalnosc-lecznicza-pacjent.md | ✅ OK |
| Ustawa o świadczeniach zdrowotnych — NFZ | Dz.U. 2025 poz. 1461 t.j. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-NFZ-swiadczenia.md | ✅ OK |
| Ustawa o jakości w opiece zdrowotnej | Dz.U. 2023 poz. 1692 ze zm. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-jakosc-opieka-zdrowotna.md | ✅ OK |
| Ustawa o zawodach lekarza i lekarza dentysty | Dz.U. 2026 poz. 37 t.j. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-zawod-lekarza.md (wskaźnik poprawiony T5 2026-09-16) | ✅ OK |
| Ustawa o zawodach pielęgniarki i położnej | Dz.U. 2026 poz. 15 t.j. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-pielegniarka-polozna.md | ✅ OK |
| Ustawa o medycynie laboratoryjnej (15.09.2022) — dawniej „ustawa o diagnostyce laboratoryjnej”|**Dz.U. 2025 poz. 1295 t.j.** ✅ [VER] RZĄD 1 2026-09-10j — obwieszczenie Marszałka Sejmu z 15.09.2025, akt bazowy **Dz.U. 2022 poz. 2280**, najnowszy z 2 t.j. (poprzedni 2023/2125 — wygaśnięcie aktu), zero nowelizacji po tekście jednolitym. ⛔ **NAZWA SKORYGOWANA:** akt nazywa się dziś *ustawą o medycynie laboratoryjnej*; nazwa „o diagnostyce laboratoryjnej” dotyczy ustawy z 27.07.2001 (2001/1083 — Dz.U. 2001 nr 100, **uchylona**, ostatni t.j. 2022/2162). ⛔ Łańcuch w poprzednim zapisie był zbudowany na dwóch podmianach aktu — patrz mapa centralna, wiersze 2022/2162 i 2023/1517|Dz.U. 2025 poz. 1295 t.j. (sync 2026-07-02 — łańcuch 2022.2162[błąd]→2022.2280→2023.2125)| dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-diagnostyka-laboratoryjna.md — ✅ ROZSTRZYGNIĘTE 2026-09-10j |
| Ustawa o wyrobach medycznych | Dz.U. 2024 poz. 1620 t.j. (akt pierwotny: Dz.U. 2022 poz. 974) ✅ [VER: api.sejm.gov.pl/eli, 2026-09-01] | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-GIF-GIS-nadzor-farmaceutyczny-sanitarny.md | ✅ OK |
| Ustawa o produktach biobójczych | Dz.U. 2021 poz. 24 ze zm. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-produkty-biobojcze.md | ✅ OK |
| Ustawa Prawo oświatowe + szkolnictwo wyższe | **Dz.U. 2026 poz. 820 t.j.** (oświatowe — SYNC 2026-08-22, REGUŁA 3; ✅ VER RZĄD 1: api.sejm.gov.pl, eli.gov.pl; obwieszczenie 12.06.2026, publ. 22.06.2026; ⬆ zastąpiło 2025.1043, wcześniej sync 2026-07-02 z korektą błędnego 2024.737) + Dz.U. 2024 poz. 1571 t.j. (szkolnictwo wyższe) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-oswiata-szkolnictwo-wyzsze.md | ✅ OK |
| Ustawa o sporcie | Dz.U. 2026 poz. 95 t.j. ✅ VER 2026-07-04 (sync z dr-10; rozdzielona od imprez masowych) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-sport-turystyka-imprezy-masowe.md | ✅ OK |
| Ustawa o bezpieczeństwie imprez masowych | Dz.U. 2023 poz. 616 t.j. ✅ VER 2026-07-04 (sync z dr-10; nowy wiersz, wydzielony z dawnego zbiorczego wpisu sport+imprezy masowe; poprzedni t.j. Dz.U. 2022 poz. 1466) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-sport-turystyka-imprezy-masowe.md | ✅ NOWY |
| Ustawa o bezpieczeństwie żywności ⭐ + KLASTER 15+ dodatkowych aktów (Rozp. UE 1169/2011, Dyrektywa 2012/12/UE, Rozp. UE 1333/2008, Dyrektywa 2000/36/WE, Rozp. UE 2017/625, Rozp. UE 2016/2031, Rozp. UE 1151/2012, ⚡ ustawa o zakazie ferm futerkowych 12/2025, ⚡ NOWA ustawa o zdrowiu zwierząt 21.11.2025/Dz.U. 2025 poz. 1795, CITES — pełna lista w dr-10/MAPA-AKTOW.md) — moduł ROZBUDOWANY OŚMIOKROTNIE 2026-07-30 na żądanie użytkownika, z 37 linii do 35 sekcji tematycznych | Dz.U. 2023 poz. 1448 ze zm. (akt bazowy) — ⚠️ SPRAWDŹ dr-10/MAPA-AKTOW.md dla PEŁNEJ, precyzyjnej listy wszystkich powiązanych aktów i ich aktualnych Dz.U. — TEN wiersz centralny NIE odzwierciedla już pełnej złożoności, sync 2026-07-30 | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-bezpieczenstwo-zywnosci.md | ✅ ROZBUDOWANY 2026-07-30 — patrz dr-10/MAPA-AKTOW.md dla szczegółów |
| Ustawa o Inspekcji Weterynaryjnej | Dz.U. 2024 poz. 12 t.j. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-inspekcja-weterynaryjna.md | ✅ OK |
| Ustawa o izbach aptekarskich (zawód zaufania publicznego) | Dz.U. 2025 poz. 1693 t.j. ✅ VER: 2026-06-14 | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-aptekarz-zawod.md | ✅ NOWY |
| Ustawa o zawodzie lekarza weterynarii i izbach lekarsko-weterynaryjnych (zawód zaufania publicznego) | Dz.U. 2026 poz. 125 t.j. ✅ VER: 2026-06-14 | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-lekarz-weterynarii-zawod.md | ✅ NOWY |
| Ustawa o zawodzie psychologa oraz samorządzie zawodowym psychologów (⚠️ stan przejściowy 2026-2028) | Dz.U. 2026 poz. 187 (nowa, w życie 19.05.2028) + Dz.U. 2019 poz. 1026 (obecnie faktycznie obowiązująca) ✅ VER: 2026-06-14 | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-psycholog-zawod.md | ✅ NOWY |
| Ustawa refundacyjna | Dz.U. 2026 poz. 253 t.j. ✅ [VER] RZĄD 1 2026-09-10h — obwieszczenie z 20.02.2026, najnowszy tekst jednolity. ⛔ KROK 2C: nowelizacja po tekście jednolitym — Dz.U. 2026 poz. 791 (ustawa z 15.05.2026 o rozwoju usług e-zdrowia). ⛔ **WYKAZ leków refundowanych NIE jest aktem Dz.U.**: obwieszczenie MZ na podstawie art. 37 ust. 1 ustawy refundacyjnej, ogłaszane w Dzienniku Urzędowym Ministra Zdrowia (`dziennikmz.mz.gov.pl` — RZĄD 1, ⛔ aplikacja jednostronicowa, treść nie wychodzi prostym pobraniem); przetwarzalne załączniki XLSX na `gov.pl/web/zdrowie/obwieszczenia-ministra-zdrowia-lista-lekow-refundowanych` (RZĄD 2A). ⛔ `api.nfz.gov.pl` zwraca STATYSTYKĘ wykonanej refundacji, nie wykaz — inna kategoria źródła | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-PrFarm-prawo-farmaceutyczne.md | ✅ OK |
| Ustawa o ochronie zdrowia psychicznego | Dz.U. 2024 poz. 917 ze zm. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-zdrowie-psychiczne.md (wskaźnik poprawiony T5 2026-09-16) | ✅ OK |
| Ustawa o prawach pacjenta i Rzeczniku Praw Pacjenta | Dz.U. 2024 poz. 581 t.j. ✅ VER: 2026-06-14 (TRYB DZU; uwaga: nowelizacja 2026/26 art.23) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-prawa-pacjenta-framework.md | ✅ OK |
| Ustawa o prawach pacjenta i RPP — Rozdział 12 (kompetencje Rzecznika Praw Pacjenta) | Dz.U. 2024 poz. 581 t.j. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-rzecznik-praw-pacjenta-RPP.md | ✅ NOWY 2026-07-21 |
| Ustawa o działalności leczniczej | Dz.U. 2026 poz. 156 t.j. ✅ VER: 2026-06-14 (TRYB DZU — był 2024/799) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-dzialalnosc-lecznicza-pacjent.md + mod-ustawa-medyczne-szczegolowy.md (numer t.j. dopisany do obu 2026-09-16, F-190) | ✅ OK |
| Ustawa o substancjach chemicznych (REACH) | Dz.U. 2022 poz. 1816 ze zm. | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-REACH-CLP-chemikalia.md | ✅ OK |
| Prawo o adwokaturze | Dz.U. 2024 poz. 1564 t.j.; zmiany po t.j.: 2025 poz. 1172, 2026 poz. 370, 846, 1290 ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI); ✅ RZĄD 1 ELI T5 2026-09-16 (⛔ wiersz łączył adwokaturę z zawodami medycznymi i wskazywał moduł o pielęgniarkach); ⛔ nowelizacja Dz.U. 2026 poz. 1290 (ustawa z 4.09.2026, ogł. 2.10.2026) — w życie 17.10.2026, art. 1 pkt 16, 41, 42 od 1.01.2027: m.in. art. 7 ust. 3 — ochrona przysługująca funkcjonariuszowi publicznemu ✅ [VER] RZĄD 1 2026-10-09 (ELI DU/2026/1290 + text.pdf) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-adwokatura.md | ✅ OK |
| Ustawa o ubezpieczeniach obowiązkowych, UFG i PBUK (obejmuje też OC obowiązkowe z innych ustaw, np. podmiotu leczniczego) | Dz.U. 2026 poz. 783 t.j. ✅ RZĄD 1 ELI T5 2026-09-16 (⛔ tytuł „ubezpieczeniach obowiązkowych lekarzy" nie istnieje) | dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-ustawa-ubezpieczenia-obowiazkowe-UFG-PBUK.md (wskaźnik poprawiony T5 2026-09-16) | ✅ OK |
| Ustawa o zapewnianiu dostępności osobom ze szczególnymi potrzebami (⛔ nazwa poprawiona 2026-09-16d — było „Ustawa o medycynie — edukacja specjalna") | Dz.U. 2024 poz. 1411 t.j. ✅ [VER] RZĄD 1 2026-09-16d (sync 2026-07-02 — było błędnie 2022.2240) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-edukacja-specjalna-dostepnosc.md | ✅ OK |
| Ustawa o rolnictwie ekologicznym i produkcji ekologicznej + weterynaria | Dz.U. 2023 poz. 1235 t.j. ✅ [VER] RZĄD 1 2026-09-16d (⛔ PODMIANA AKTU usunięta: `2024 poz. 1284` to rozporządzenie MKiŚ; weterynaria — ustawa o zdrowiu zwierząt Dz.U. 2025 poz. 1795, ustawa o Inspekcji Weterynaryjnej Dz.U. 2024 poz. 12 t.j.) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-rolne-zywnosc-weterynaria.md | ✅ OK |
| Prawo farmaceutyczne — refundacja, nadzór, sankcje (opracowanie szczegółowe) | Prawo farmaceutyczne: **Dz.U. 2026 poz. 612 t.j.** (obwieszczenie z 17.04.2026) ✅ [VER: ELI DU/2026/612, RZĄD 1, 2026-10-04] — ⛔ KROK 2C: 3 nowelizacje po tekście jednolitym — Dz.U. 2026 poz. 791, 1004, 1079. Ustawa refundacyjna: **Dz.U. 2026 poz. 253 t.j.** (obwieszczenie z 20.02.2026) ✅ [VER: ELI DU/2026/253, RZĄD 1, 2026-10-04] — ⛔ KROK 2C: 1 nowelizacja po tekście jednolitym — Dz.U. 2026 poz. 791 (wiersz „Ustawa refundacyjna” wyżej). ⛔ WYKAZ leków refundowanych NIE jest aktem Dz.U. (obwieszczenie MZ z art. 37 ust. 1 ustawy refundacyjnej — kanały i pułapki w wierszu ustawy refundacyjnej oraz w module) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-PrFarm-refundacja-nadzor-sankcje.md | ✅ NOWY 2026-07-18 (synchronizacja z DR-MAPA-AKTOW); ✅ [VER] numery t.j. 2026-10-04 (AUDYT-2026-10-04h) |
| Prawo farmaceutyczne — opracowanie szczegółowe | ⚠️ zweryfikuj t.j. na ISAP | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-PrFarm-szczegolowy.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| Ustawa o zawodzie lekarza i lekarza dentysty | ⚠️ zweryfikuj t.j. na ISAP | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-zawod-lekarza.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| Ustawy o zawodach prawniczych pokrewnych (kontekst zdrowia — np. biegli sądowi medyczni) | ⚠️ zweryfikuj akty właściwe na ISAP | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-zawody-prawnicze-pokrewne.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| Ustawa o ochronie zdrowia psychicznego | ⚠️ zweryfikuj t.j. na ISAP | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-zdrowie-psychiczne.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| Ustawa o wyrobach medycznych | Dz.U. 2024 poz. 1620 t.j. ✅ [VER: api.sejm.gov.pl/eli, 2026-09-01] | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-wyroby-medyczne.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| Prawo oświatowe — prawa ucznia (zakaz skreślenia w obowiązku szkolnym, doręczenia) | **Dz.U. 2026 poz. 820 t.j.** (SYNC 2026-08-22, REGUŁA 3 — ⬆ zastąpiło 2025.1043) + Konstytucja RP art. 53 | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-prawa-ucznia.md | ✅ DOPISANE do mapy 2026-07-30 (sync) |
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa o izbach lekarskich — samorząd zawodowy, odpowiedzialność zawodowa OSL/NSL, rozdz. 5 art. 53-112 | Dz.U. 2021 poz. 1342 t.j. (obwieszczenie 25.06.2021) — całkowicie nieobecna w ROUTING-MAP mimo pełnego pokrycia w dr-10 (F-3 zamknięta 2026-07-15) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-zawod-lekarza.md | ✅ DODANE 2026-08-19 |
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa o imprezach turystycznych i powiązanych usługach turystycznych | Dz.U. 2026 poz. 925 t.j. (ustawa bazowa 24.11.2017, pierwotnie Dz.U. 2017 poz. 2361) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-sport-turystyka-imprezy-masowe.md | ✅ KANONICZNY MODUŁ TURYSTYKI |
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa o rolnictwie, żywności i weterynarii (mod-AH) — jakość handlowa/IJHARS + ARiMR + WPR/PROW, po rozbiciu zbiorczego wiersza F-1 | Jakość handlowa: Dz.U. 2023 poz. 1980 t.j.; ARiMR: **Dz.U. 2026 poz. 942 t.j.** ✅ [VER] RZĄD 1 2026-09-10o — ARiMR (poprzednio 2025 poz. 1363 — wygaśnięcie aktu) t.j.; WPR/PROW: Dz.U. 2024 poz. 1741 t.j. ze zm. 2025.321 — całkowicie nieobecna w ROUTING-MAP mimo pełnego pokrycia lokalnego | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-rolne-zywnosc-weterynaria.md | ✅ DODANE 2026-08-19 |
| Hodowla i zdrowie zwierząt (weterynaria) — w tym „ustawa łańcuchowa" Dz.U. 2026 poz. 1005 | ✅ **UZUPEŁNIONE 2026-08-19 (F-89):** Dz.U. 2026 poz. 755 + Dz.U. 2025 poz. 1696 (składowe klastra) — poprzedni zapis "patrz MAPA-AKTOW DR-10" generował fałszywe alarmy w teście T11, bo nie zawierał żadnego numeru do dopasowania | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-hodowla-zdrowie-zwierzat.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| Hodowla zwierząt — zezwolenia i gatunki (pseudohodowla) | ✅ **UZUPEŁNIONE 2026-08-19 (F-89):** patrz MAPA-AKTOW DR-10 dla pełnego łańcucha numerów; numery klastra 755/1696 współdzielone z wierszem wyżej — ten sam wzorzec naprawy (dodanie liczb dla wykrywalności przez T11) | dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-hodowla-zezwolenia-gatunki.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |

---

## DR-11 — Cyfrowe, Cyberbezpieczeństwo, AI, Dane, IP

*Źródło: dr-11/MAPA-AKTOW.md | Weryfikacja: 2026-06-05*

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| RODO — Rozp. UE 2016/679 | Dz.Urz. UE L 119/1 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-RODO-GDPR-2016-679.md | ✅ OK |
| Ustawa UODO — implementacja RODO — ROZBUDOWANE 2026-07-21 (sekcja 9: skarga do Prezesa UODO, korekta GIODO→UODO) | Dz.U. 2019 poz. 1781 t.j. ze zm.; po t.j.: Dz.U. 2026 poz. 252 art. 16 (od 3.04.2026) i 2026 poz. 548 art. 38 (ustawa o zarządzaniu danymi, od 23.07.2026) — ELI 2026-10-09 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-UODO-postepowanie-ochrona-danych.md | ✅ OK |
| Ustawa o krajowym systemie certyfikacji cyberbezpieczeństwa | Dz.U. 2025 poz. 1017 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-certyfikacja-cyberbezpieczenstwa.md | ✅ OK |
| Ustawa o KSC + NIS2 (2022/2555) | Dz.U. 2026 poz. 20 t.j.; po t.j. (ELI 2026-10-12): 2026/252, 2026/815 (w mocy 4.07.2026), 2026/1003, 2026/1206 — POPRAWKA 2026-07-26 (audyt pełnego systemu, T3): usunięto zduplikowany, sprzeczny wiersz "KSC — krajowy system cyberbezpieczeństwa" który miał ten sam moduł z inną wersją numeru (2024.1226, nieaktualny) — scalono w jeden poprawny wpis | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-KSC-NIS2-cyberbezpieczenstwo-telekom.md | ✅ OK |
| DORA (Rozp. UE 2022/2554) + eIDAS 2.0 | Rozp. UE 2022/2554 + 2024/1183 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-DORA-eIDAS-cyfrowe-finanse.md | ✅ OK |
| Prawo komunikacji elektronicznej + UKE | Dz.U. 2024 poz. 1221 (brak t.j.; zm. (ELI 2026-10-12): 2025/637, 2025/820, 2026/252, 2026/815 w mocy 4.07.2026, 2026/1296) (sync 2026-07-02 — było błędnie 1220) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-PrTelekom-poczta-UKE.md | ✅ OK |
| Ustawa o prawie autorskim i prawach pokrewnych | Dz.U. 2025 poz. 24 t.j. | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-PrAut-wlasnosc-intelektualna-IP.md | ✅ OK |
| AI Act — Rozp. UE 2024/1689 + ⚡ Ustawa krajowa z 3.07.2026 o systemach sztucznej inteligencji (KRiBSI) — PODPISANA przez Prezydenta 24.07.2026 | Dz.Urz. UE L 2024/1689 — ustawa krajowa: **Dz.U. 2026 poz. 1003** ✅ UZUPEŁNIONE 2026-08-15z (sync z dr-11/MAPA-AKTOW.md, gdzie numer był od 2026-08-14b; ogłoszenie 27.07.2026, akt PIERWOTNY — NIE t.j.) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-AI-Act-framework.md | ✅ ZAKTUALIZOWANY 2026-07-30 |
| DMA — Digital Markets Act (Rozp. UE 2022/1925) | Dz.Urz. UE L 265/1 z 12.10.2022 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-DMA-digital-markets-act.md | ✅ OK |
| DSA — Digital Services Act (Rozp. UE 2022/2065) | Dz.Urz. UE L 277/1 z 27.10.2022 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-DSA-digital-services-act.md | ✅ OK |
| CRA, EUCS, DA, DGA — akty cyfrowe UE | Dz.Urz. UE L 2024/2847 + inne | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-EUCS-CRA-akty-regulacyjne-UE.md | ✅ OK |
| MiCA — kryptoaktywa (Rozp. UE 2023/1114) | Dz.Urz. UE L 2023/1114 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-MiCA-kryptoaktywa.md | ✅ OK |
| Ustawa o informatyzacji podmiotów publicznych + KSeF | Dz.U. 2026 poz. 1241 t.j. (sync 2026-07-02 z dr-11) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-informatyzacja-podmiotow-publicznych.md | ✅ OK |
| Ustawa o otwartych danych | Dz.U. 2023 poz. 1524 t.j. | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-otwarte-dane.md | ✅ OK |
| Ustawa o podpisie elektronicznym i eIDAS | Rozp. UE 910/2014 + Dz.U. 2024 poz. 1725 t.j. (sync 2026-07-02 — było błędnie 2016.147) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-podpis-elektroniczny.md | ✅ OK |
| Prawo własności przemysłowej | Dz.U. 2023 poz. 1170 t.j. | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-prawo-wlasnosci-przemyslowej.md | ✅ OK |
| Ustawa o usługach świadczonych drogą elektroniczną | ✅ SKORYGOWANE 2026-08-21 (F-89): t.j. **Dz.U. 2024 poz. 1513** (obwieszczenie 10.10.2024, isap WDU20240001513), poprzedni t.j. 2020.344 — nowelizacja z 18.12.2025 (implementacja DSA) zmienia treść tego t.j. bez tworzenia nowego, cytować jako "2024.1513 ze zm." (poprawka lokalnie w dr-11/MAPA-AKTOW z 2026-07-04, teraz zsynchronizowana z ROUTING-MAP) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-uslugi-elektroniczne.md | ✅ ZSYNCHRONIZOWANE 2026-08-21 |
| Ustawa z 10.05.2018 o ochronie danych osobowych — akt pierwotny (⛔ KOREKTA 2026-10-09: wiersz nazywał ją „starą, ref historyczną” — to ustawa OBOWIĄZUJĄCA; t.j. Dz.U. 2019 poz. 1781, wiersz wyżej) | Dz.U. 2018 poz. 1000 (akt pierwotny; stosuj t.j. 2019/1781 ze zm.) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-UODO-postepowanie-ochrona-danych.md | ✅ OK |
| KSeF — ustawa o e-Fakturze | ustawa z 29.10.2021 o zmianie ustawy o VAT — Dz.U. 2021 poz. 2076; KSeF w ustawie o VAT (t.j. Dz.U. 2026 poz. 1263) (ELI 2026-10-09) (⛔ KOREKTA: było „Dz.U. 2021 poz. 1237” — nowelizacja ustawy o systemie oświaty) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-informatyzacja-podmiotow-publicznych.md | ✅ OK |
| Ustawa o usługach zaufania (krajowa) | Dz.U. 2024 poz. 1725 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) (zm. po t.j.: Dz.U. 2026 poz. 252) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-ustawa-podpis-elektroniczny.md | ✅ OK |
| Prawo autorskie — media/internet/dobra osobiste (opracowanie szczegółowe) | ⚠️ zweryfikuj t.j. ustawy o prawie autorskim na ISAP | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-PrAut-media-internet-dobra-osobiste.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| RODO — DPIA (ocena skutków dla ochrony danych) | Rozporządzenie UE 2016/679 (RODO), art. 35 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-RODO-DPIA-ocena-skutkow.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| RODO — DSAR (żądania osób, których dane dotyczą) | Rozporządzenie UE 2016/679 (RODO), art. 15-22 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-RODO-DSAR-zadania-osob.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| RODO — RCP/DPA (rejestr czynności przetwarzania, powierzenie przetwarzania) | Rozporządzenie UE 2016/679 (RODO), art. 28, 30 | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-RODO-RCP-DPA-rejestr-powierzenie.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| RODO — opracowanie szczegółowe (uzupełnienie kanonicznego mod-RODO-GDPR-2016-679) | Rozporządzenie UE 2016/679 (RODO) | dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-RODO-szczegolowy.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |

---

## DR-12 — Sądownictwo, Prokuratura, Zawody Prawnicze

*Źródło: dr-12/MAPA-AKTOW.md | Weryfikacja: 2026-06-05*

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| PUSP (ustrój sądów powszechnych) | Dz.U. 2024 poz. 334 ze zm. (zm.: 2025.526) | → DR-01/mod-USP-ustroj-sadow-powszechnych | 🔗 odesłanie |
| Ustawa Prawo o prokuraturze | Dz.U. 2026 poz. 810 t.j. ze zm. | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-PrProkuratura-organy-ochrony-prawa.md | ✅ B+/COV; fresh gate |
| KPC — arbitraż i mediacja | Dz.U. 2026 poz. 468 ze zm. | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-KPC-arbitraz-mediacja-ADR.md | ✅ OK |
| KPC — biegli sądowi i opinie | Dz.U. 2026 poz. 468 ze zm. | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-KPC-biegli-sadowi-opinie.md | ✅ OK |
| KSCU — koszty sądowe | Dz.U. 2025 poz. 1228 t.j.; zmiany po t.j.: 2026 poz. 473 (8.07.2026), 1003 (28.10.2026), 346 (30.09.2028) ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-KSCU-koszty-sadowe-i-pomoc-prawna.md | ✅ OK |
| Ustawa o regulatorach (UOKiK, URE, UKE, KNF) | UOKiK: Dz.U. 2025 poz. 1714 t.j. + URE: Prawo energetyczne Dz.U. 2026 poz. 43 t.j. + UKE: Prawo komunikacji elektronicznej Dz.U. 2024 poz. 1221 ze zm. (m.in. 2026/815) + ustawa o wspieraniu rozwoju usług i sieci telekom. Dz.U. 2026 poz. 562 t.j. (po t.j. (ELI 2026-10-12): 2026/815, w mocy 4.07.2026) + KNF: ustawy sektorowe (sprawdzać każdorazowo) ✅ VER: 2026-06-14 (TRYB DZU — moduł ma własną tabelę aktów, rozwinięto wiersz dla zgodności) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-regulatorzy-UOKiK-URE-UKE-KNF.md | ✅ OK |
| Prawo o ustroju sądów powszechnych (sędziowie, referendarze) + ustawa o kuratorach sądowych | PUSP: Dz.U. 2024 poz. 334 t.j.; kuratorzy: Dz.U. 2026 poz. 200 t.j. ✅ [VER] RZĄD 1 2026-09-16d (⛔ nazwa poprawiona — kuratorów reguluje odrębna ustawa) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-sedziowie-referendarze-kuratorzy.md | ✅ OK |
| Ustawa o odpowiedzialności dyscyplinarnej zawodów | Ustawy korporacyjne | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-odpowiedzialnosc-dyscyplinarna-zawodow.md | ✅ OK |
| Ustawa Prawo o adwokaturze | Dz.U. 2024 poz. 1564 t.j.; zmiany po t.j.: 2025 poz. 1172, 2026 poz. 370, 846, 1290 (w życie 17.10.2026) ✅ [VER] RZĄD 1 2026-10-11 | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-adwokatura.md | ✅ OK |
| Ustawa o radcach prawnych | Dz.U. 2024 poz. 499 t.j. + zm. Dz.U. 2025 poz. 1172, Dz.U. 2026 poz. 370, Dz.U. 2026 poz. 731 i Dz.U. 2026 poz. 846 (1.10.2026; dopisana 2026-10-11, RZĄD 1 ELI `/references`) ✅ VER 2026-08-31 — ustawa z 15.05.2026 o zmianie ustawy o radcach prawnych, w życie 18.06.2026 (RZĄD 1: eli.gov.pl/eli/DU/2026/731/ogl + ISAP PDF D20260731; RZĄD 2B: prawo.pl, infor.pl) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-radcowie-prawni.md | ✅ OK |
| Ochrona przysługująca funkcjonariuszowi publicznemu — adwokat i radca prawny (napaść, znieważenie, naruszenie nietykalności przy czynnościach zawodowych) | Prawo o adwokaturze art. 7 ust. 3 w brzmieniu Dz.U. 2026 poz. 1290 (od 17.10.2026; wcześniej art. 7 ust. 1: ochrona prawna „podobnie jak sędzia i prokurator”); ustawa o radcach prawnych art. 12 ust. 1 w brzmieniu Dz.U. 2026 poz. 731 (od 18.06.2026); KK t.j. Dz.U. 2025 poz. 383 (art. 222–226) ✅ [VER] RZĄD 1 2026-10-09 (ELI DU/2026/1290 + text.pdf) | dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art222-226-ochrona-funkcjonariusza.md + dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-adwokatura.md + dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-radcowie-prawni.md | ✅ NOWY 2026-10-09 |
| Ustawa Prawo o notariacie (zawód) | Dz.U. 2026 poz. 614 t.j. | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-notariat.md | ✅ OK |
| Ustawa o komornikach sądowych | Dz.U. 2026 poz. 881 t.j. ✅ VER: 2026-06-14 (TRYB DZU — potwierdzono aktualny, KOREKTA: 2026/26 to inny akt - Ustawa SUS, błąd wcześniejszego wyszukiwania) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-komornicy-sadowi-zawod.md | ✅ OK |
| Ustawa o rzecznikach patentowych (zawód, zawód zaufania publicznego) | Dz.U. 2026 poz. 778 t.j. ✅ VER 2026-07-04 (sync z dr-12; poprzedni wpis "2025.591" był błędny — to rozporządzenie wykonawcze, nie t.j. ustawy; poprzedni prawidłowy t.j. Dz.U. 2024 poz. 749) + Dz.U. 2025 poz. 1679 (nowelizacja, w życie 3.02.2026) | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-rzecznicy-patentowi-zawod.md | ✅ OK |
| Techniki mediacyjne i negocjacyjne (DR-12, uzupełnienie do mod-KPC-arbitraz-mediacja-ADR) | ⚠️ w dużej mierze wiedza fachowa/doktryna, nie sam akt prawny | dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-techniki-mediacyjne-negocjacyjne.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |

---

## DR-13 — Służby, Bezpieczeństwo, Informacje Niejawne

*Źródło: dr-13/MAPA-AKTOW.md | Weryfikacja: 2026-06-05*
*⚠️ Służby mundurowe — bardzo liczne nowelizacje 2024–2026. Przed cytowaniem weryfikuj ISAP.*

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Ustawa o Służbie Kontrwywiadu Wojskowego oraz Służbie Wywiadu Wojskowego — utworzenie/cele (art. 1-2), ustrój/nadzór (art. 3/5/13/18, wieloetapowe powoływanie Szefów) | Dz.U. 2026 poz. 157 t.j. | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-SKW-SWW.md | ✅ NOWY 2026-08-13 — DOPISANE 2026-08-14 (sync) — naprawa F-59, wojskowe odpowiedniki ABW/AW dotąd bez pokrycia w domenie noszącej nazwę "Służby" |
| Ustawa o Policji | Dz.U. 2025 poz. 636 t.j. z późn. zm. (po t.j. (ELI 2026-10-12) 12 zmian: 2025/718, 2025/1366, 2026/187, 2026/421, 2026/646, 2026/760, 2026/815 w mocy 4.07.2026, 2026/821, 2026/864, 2026/1004, 2026/1123, 2026/1281) (sync 2026-07-02 z dr-13) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-policja.md | ✅ OK |
| Ustawa o Straży Granicznej — ROZBUDOWANE 2026-07-21 (kontrola legalności zatrudnienia/pobytu cudzoziemców, sprzeciw wobec kontroli, obowiązki zgłoszeniowe pracodawcy) | Dz.U. 2026 poz. 367 t.j.; po t.j. (ELI 2026-10-12): 2026/646, 2026/815 (w mocy 4.07.2026), 2026/821, 2026/864, 2026/1123, 2026/1281 (sync 2026-07-02 z dr-13) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-straz-graniczna.md | ✅ OK |
| Ustawa o Żandarmerii Wojskowej | Dz.U. 2026 poz. 159 t.j.; po t.j. (ELI 2026-10-12): 2026/815 (w mocy 4.07.2026), 2026/1281 (sync 2026-07-02 z dr-13) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-zandarmeria-wojskowa.md | ✅ OK |
| Ustawa o ABW i AW | Dz.U. 2026 poz. 937 t.j. (WARN-28 zamknięty, sync 2026-07-02 — było błędnie 2024.1183; to nowy t.j. tej samej ustawy z 2002 r., nie nowa reforma) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-ABW-AW-CBA-sluzby-specjalne.md | ✅ OK |
| Ustawa o CBA | Dz.U. 2025 poz. 712 t.j. (sync 2026-07-02 z dr-13) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-ABW-AW-CBA-sluzby-specjalne.md | ✅ OK |
| Ustawa o SOP | ✅ **SKORYGOWANE 2026-08-18 (F-89):** t.j. **Dz.U. 2025 poz. 34** z późn. zm. (po t.j. (ELI 2026-10-12): 2025/179, 2025/718, 2025/1366, 2025/1823, 2026/646, 2026/815 w mocy 4.07.2026, 2026/821, 2026/1123, 2026/1281) — poprzedni numer "2024 poz. 1672" był BŁĘDNY, nie odpowiadał żadnemu potwierdzonemu dokumentowi tej ustawy (poprawka lokalnie w dr-13 z 2026-07-04, teraz zsynchronizowana z ROUTING-MAP) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-ABW-AW-CBA-sluzby-specjalne.md | ✅ ZSYNCHRONIZOWANE 2026-08-18 |
| Ustawa o ochronie informacji niejawnych | Dz.U. 2025 poz. 1209 t.j. | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-informacje-niejawne.md | ✅ OK |
| Ustawa o obronie Ojczyzny | Dz.U. 2025 poz. 825 t.j.; po t.j. (ELI 2026-10-12): 2025/1014, 2025/1080, 2026/26, 2026/426, 2026/635, 2026/815 (w mocy 4.07.2026), 2026/1123 (sync 2026-07-02 — nowy t.j.) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-obrona-ojczyzny-mobilizacja.md | ✅ OK |
| Ustawa o ochronie ludności i obronie cywilnej | Dz.U. 2024 poz. 1907 (brak t.j.); zm. (ELI 2026-10-12): 2025/1705, 2026/646 (w życie 29.05.2026), 2026/815 (w mocy 4.07.2026) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-zarzadzanie-kryzysowe-obrona-cywilna.md | ✅ OK |
| Ustawa o działaniach antyterrorystycznych (10.06.2016) | **Dz.U. 2025 poz. 194 t.j.** ✅ [VER] RZĄD 1 2026-09-10c (F-148a) — obwieszczenie Marszałka Sejmu z 5.02.2025, akt bazowy Dz.U. 2016 poz. 904, najnowszy t.j. tego aktu. ⛔ KROK 2C: JEDNA nowelizacja po tekście jednolitym — ustawa z 29.05.2026 o zmianie ustawy o zarządzaniu kryzysowym oraz niektórych innych ustaw, Dz.U. 2026 poz. 815 (akt zmieniający); tekst jednolity NIE oddaje stanu bieżącego. ⛔ **BŁĄD SKORYGOWANY:** wiersz podawał `Dz.U. 2024 poz. 1474`, co jest obwieszczeniem **Ministra Sprawiedliwości** o t.j. **rozporządzenia** MS — inny akt, inny organ, inna ranga. Klasa F-149(3) (podmiana aktu); numer istniał, był obwieszczeniem i miał status obowiązujący, więc przechodził każdą dotychczasową kontrolę. Wykryte przez T15 po rozszerzeniu porównania tytułów na nazwy „Ustawa o…” (F-148a) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-ABW-AW-CBA-sluzby-specjalne.md | ⛔ SKORYGOWANE 2026-09-10c |
| Ustawa — szczególne środki zabezpieczające | Dz.U. 2022 poz. 1689 t.j. (sync 2026-07-02 z dr-13, KOZZiD) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-szczegolne-srodki-zabezpieczajace.md | ✅ OK |
| Ustawa o środkach przymusu bezpośredniego | Dz.U. 2026 poz. 244 t.j.; po t.j. (ELI 2026-10-12): 2026/737, 2026/815 (w mocy 4.07.2026) (sync 2026-07-02 z dr-13) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-policja.md | ✅ OK |
| Ustawa o udzielaniu ochrony cudzoziemcom | Dz.U. 2026 poz. 862 t.j. ✅ VER 2026-07-04 (POPRAWKA — było 2024.1546, sync z dr-05) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-straz-graniczna.md | ✅ OK |
| Prawo komunikacji elektronicznej (retencja danych) | Dz.U. 2024 poz. 1221 (brak t.j.; zm. (ELI 2026-10-12): 2025/637, 2025/820, 2026/252, 2026/815 w mocy 4.07.2026, 2026/1296) (sync 2026-07-02 — było błędnie 1220) | → DR-11/mod-PrTelekom-poczta-UKE | 🔗 odesłanie |
| Ustawa o Państwowej Straży Pożarnej | Dz.U. 2025 poz. 1312 t.j. (sync 2026-07-07 z dr-13 — WARN-29 zamknięty) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-PSP-OSP-ochrona-przeciwpozarowa.md | ✅ OK |
| Ustawa o ochronie przeciwpożarowej | Dz.U. 2025 poz. 188 t.j.; po t.j. (ELI 2026-10-12): 2026/815 (w mocy 4.07.2026) (sync 2026-07-07 z dr-13) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-PSP-OSP-ochrona-przeciwpozarowa.md | ✅ OK |
| **Ustawa z 21.05.1999 o broni i amunicji** — pozwolenia na broń CYWILNĄ, cofanie, rejestracja, badania lekarskie/psychologiczne, egzamin, strzelnice, przepisy karne ustawy (art. 50-51) | **Dz.U. 2024 poz. 485 t.j.** ⛔ ISAP blokuje web_fetch — potwierdź ręcznie brak nowszego t.j. ⚠️ NIE MYLIĆ z ustawą o środkach przymusu bezpośredniego i broni palnej (2026.244) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-BronAmunU-pozwolenia-cofniecie-strzelnice.md | ✅ NOWY 2026-08-16 (naprawa F-92 — akt bez modułu w całym systemie; ryzyko routingu pytania ADMINISTRACYJNEGO na moduł KARNY dr-03/art. 263 KK) |
| Ustawa o ochotniczych strażach pożarnych (OSP) | Dz.U. 2025 poz. 244 t.j. (akt pierwotny 2021.2490) (sync 2026-07-07 z dr-13 — WARN-29 zamknięty) | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-PSP-OSP-ochrona-przeciwpozarowa.md | ✅ OK |
| Ustawa o Policji art. 19a-20b (czynności operacyjno-rozpoznawcze, działania pod przykryciem) + analogiczne przepisy ABW/AW/SG/CBA/ŻW | ⚠️ zweryfikuj t.j. ustawy o Policji na ISAP | dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-sluzby-operacyjne-retencja-danych.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — nowa sekcja "działania pod przykryciem" dodana 2026-07-18) |

---

## DR-14 — Prawo UE, Międzynarodowe, Prawa Człowieka

*Źródło: dr-14/MAPA-AKTOW.md | Weryfikacja: 2026-06-07*

| Akt prawny | Dz.U. / Dz.Urz. UE | Moduł | Status |
|---|---|---|---|
| TUE + TFUE — prawo pierwotne UE | Dz.Urz. UE C 326 z 26.10.2012 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-TFUE-TUE-prawo-pierwotne-UE.md | ✅ OK |
| Art. 267 TFUE — pytanie prejudycjalne do TSUE | Dz.Urz. UE C 326 z 26.10.2012 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-TFUE-TUE-prawo-pierwotne-UE.md → ANEKS prejudycjalne | ✅ OK |
| Karta Praw Podstawowych UE (KPP) | Dz.Urz. UE C 326/391 (od 01.12.2009) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-KPP-karta-praw-podstawowych-UE.md | ✅ OK |
| EKPC + ETPC — prawa człowieka | Dz.U. 1993 nr 61 poz. 284 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-EKPC-ETPC-prawa-czlowieka.md | ✅ OK |
| Rozp. Bruksela Ia 1215/2012 | Dz.Urz. UE L 351/1 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-KPC-egzekucja-transgraniczna-UE.md | ✅ OK |
| KPC — egzekucja transgraniczna | Dz.U. 2026 poz. 468 t.j. | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-KPC-egzekucja-transgraniczna-UE.md | ✅ OK |
| Rzym I 593/2008 + Rzym II 864/2007 | EUR-Lex — weryfikuj | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-PMPP-prawo-prywatne-miedzynarodowe.md | ✅ OK |
| Prawo prywatne międzynarodowe (krajowe) | Dz.U. 2023 poz. 503 t.j. | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-PMPP-prawo-prywatne-miedzynarodowe.md | ✅ OK |
| Rozp. spadkowe 650/2012 | EUR-Lex — weryfikuj | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-PMPP-prawo-prywatne-miedzynarodowe.md | ✅ OK |
| Bruksela IIb 2019/1111 | EUR-Lex (od 01.08.2022) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-PMPP-prawo-prywatne-miedzynarodowe.md | ✅ OK |
| Haga 1980 — uprowadzenie dziecka | hcch.net | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-PMPP-prawo-prywatne-miedzynarodowe.md | ✅ OK |
| Haga 2007 — alimenty transgraniczne | hcch.net | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-PMPP-prawo-prywatne-miedzynarodowe.md | ✅ OK |
| MPPOiP (ONZ) | Dz.U. 1977 nr 38 poz. 167 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-ONZ-pakty-prawa-czlowieka.md | ✅ OK |
| MPPGSiK (ONZ) | Dz.U. 1977 nr 38 poz. 169 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-ONZ-pakty-prawa-czlowieka.md | ✅ OK |
| CRPD — Konwencja ONZ o prawach osób z niepełnosprawnościami | Dz.U. 2012 poz. 1169 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-ONZ-pakty-prawa-czlowieka.md | ✅ OK |
| Traktat Waszyngtoński (NATO) | Dz.U. 2000 poz. 970 ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) (było błędnie „1999 nr 87 poz. 970” — w ELI to rozp. MF o procedurze uszlachetniania czynnego) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-NATO-umowy-miedzynarodowe.md | ✅ OK |
| SOFA NATO | Dz.U. 2000 nr 21 poz. 257 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-NATO-umowy-miedzynarodowe.md | ✅ OK |
| Ustawa o zasadach pobytu wojsk obcych na terytorium RP, ich przemieszczania i pomocy wojskom sojuszniczym | Dz.U. 2024 poz. 1770 t.j. | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-NATO-umowy-miedzynarodowe.md | ✅ VER ELI 2026-08-26; usunięto błędne Dz.U. 2020 poz. 1287 (rozporządzenie weterynaryjne) |
| Rejestr źródeł prawa i lifecycle | — (moduł metodyczny) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-rejestr-zrodla-prawa-lifecycle.md | ✅ OK |
| Kontrola inwestycji zagranicznych (FDI screening) + ochrona traktatowa inwestycji (BIT/ISDS) | ✅ **SKORYGOWANE 2026-08-19 (F-89):** Ustawa o kontroli niektórych inwestycji (24.07.2015) — t.j. **Dz.U. 2026 poz. 47** (obwieszczenie 9.01.2026; uwzględnia zm. 2025/973 — mechanizm art. 12a-12k bezterminowy od 24.07.2025); po t.j. (ELI 2026-10-12): 2026/815 (w mocy 4.07.2026) + traktaty BIT — zsynchronizowane z lokalną mapą dr-14 | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-inwestycje-transgraniczne-FDI-BIT.md | ✅ ZSYNCHRONIZOWANE 2026-08-19 |
| ✅ **DODANE 2026-08-19 (F-89):** Ustawa o zasadach pobytu wojsk obcych na terytorium RP oraz zasadach ich przemieszczania się przez to terytorium | Dz.U. 2024 poz. 1770 t.j. | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-NATO-umowy-miedzynarodowe.md | ✅ KANONICZNY MODUŁ — status/pobyt wojsk obcych |
| ✅ **DODANE 2026-08-19 (F-89):** Umowa o małym ruchu granicznym PL-Rosja/obwód kaliningradzki (Moskwa 14.12.2011) | Dz.U. 2012 poz. 814 ✅ [VER: ELI DU/2012/814, RZĄD 1, 2026-10-04j — treść art. 1–5 odczytana; art. 4 ust. 1: pobyt każdorazowo do 30 dni, łącznie 90 dni w okresie 6 miesięcy] — w mocy od 27.07.2012, **ZAWIESZONA od 4.07.2016**; ⚠️ status zawieszenia wymaga potwierdzenia aktualności przy każdej sprawie | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-maly-ruch-graniczny.md | ✅ KANONICZNY MODUŁ MAŁEGO RUCHU GRANICZNEGO |
| Mały ruch graniczny (umowy dwustronne) | ⚠️ zweryfikuj aktualny status umów o małym ruchu granicznym (część zawieszona/wygasła po Schengen) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-maly-ruch-graniczny.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy — synchronizacja z DR-MAPA-AKTOW) |
| Konwencje wiedeńskie o stosunkach dyplomatycznych (1961) i konsularnych (1963) — immunitety, nietykalność osobista, prawo do kontaktu konsularnego przy zatrzymaniu cudzoziemca | Dz.U. 1965 nr 37 poz. 232 (dyplomatyczna) + Dz.U. 1982 nr 13 poz. 98 (konsularna) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-konwencje-wiedenskie-dyplomatyczne-konsularne.md | ✅ NOWY 2026-08-20 — DOPISANE 2026-08-20 (sync) — naprawa F-60, temat miał ZERO wzmianek; ✅ [VER] RZĄD 1 2026-09-10c (F-135): Dz.U. 1965 nr 37 poz. 232 (typ Konwencja, obowiązujący) + Dz.U. 1982 nr 13 poz. 98 (typ Konwencja, obowiązujący) — oba potwierdzone w API ELI |
| Konwencja genewska o statusie uchodźców (1951) + Protokół nowojorski (1967) — definicja uchodźcy, zasada non-refoulement, niekaranie za nielegalny wjazd | Dz.U. 1991 nr 119 poz. 515 (Konwencja) + Protokół nowojorski 1967: **Dz.U. 1991 nr 119 poz. 517** ✅ [VER] RZĄD 1 2026-09-10c (F-135) — typ Protokół, status obowiązujący; oświadczenia rządowe o przystąpieniu: poz. 516 (Konwencja) i poz. 518 (Protokół) | dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-konwencja-genewska-uchodzcy-1951-protokol-1967.md | ✅ NOWY 2026-08-20 — DOPISANE 2026-08-20 (sync) — naprawa F-61, warstwa traktatowa dotąd nieobecna; ✅ [VER] RZĄD 1 2026-09-10c (F-135): Konwencja Dz.U. 1991 nr 119 poz. 515 (typ Konwencja, obowiązujący); numer Protokołu ustalony — 1991/517 |

---

## DR-15 — Compliance, ISO, Governance, Audyt

| Akt prawny / norma | Źródło | Moduł | Status |
|---|---|---|---|

---

## DR-16 — Pisma, Strategia, Dowody, Orzecznictwo

*Źródło: dr-16/MAPA-AKTOW.md | Weryfikacja: 2026-06-05*

| Narzędzie / akt | Podstawa | Moduł | Status |
|---|---|---|---|
| KPC — przesłuchanie świadków (art. 258–305) | Dz.U. 2026 poz. 468 ze zm. | shared/PRZESLUCHANIE-SWIADKOW-KPC.md (przeniesiony 2026-07-12) | ✅ OK |
| KPC — e-doręczenia i portal sądowy | Dz.U. 2026 poz. 468 ze zm. | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-KPC-e-doreczenia-portal-sadowy.md | ✅ OK |
| KPC — procedury UE (TSUE, ETPCz) | KPC + Rozp. UE | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-KPC-procedury-UE-TSUE-ETPC.md | ✅ OK |
| KPC — arbitraż sportowy i dyscyplinarny | Dz.U. 2026 poz. 468 cz. V | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-KPC-arbitraz-sportowy-dyscyplinarny.md | ✅ OK |
| KPC — wzory pism procesowych | Dz.U. 2026 poz. 468 ze zm. | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-KPC-wzory-pism-procesowych.md | ✅ OK |
| Ustawa Prawo prasowe | Dz.U. 2018 poz. 1914 ze zm. | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-ustawa-prawo-prasowe-media.md | ✅ OK |
| Konstytucja — prawa i wolności w procesie | Art. 45, 47, 51, 77 Konstytucji | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-Konstytucja-prawa-i-wolnosci-procesowe.md | ✅ OK |
| Ustawa o archiwach i dokumentacji | Dz.U. 2020 poz. 164 ze zm. | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-ustawa-archiwa-dokumentacja.md | ✅ OK |
| Ustawa o obywatelstwie polskim | Dz.U. 2025 poz. 1611 ze zm. (sync 2026-07-02 z dr-16 krok 14/16 — było błędnie 2024.80, numer należący do rozp. MEN o planach nauczania) | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-ustawa-obywatelstwo-paszporty-ewidencja.md | ✅ OK |
| Ustawa o dokumentach paszportowych | Dz.U. 2026 poz. 196 ze zm. (sync 2026-07-02 z dr-16 krok 14/16) | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-ustawa-obywatelstwo-paszporty-ewidencja.md | ✅ OK |
| Ustawa o ewidencji ludności | Dz.U. 2026 poz. 384 ze zm. (sync 2026-07-02 z dr-16 krok 14/16) | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-ustawa-obywatelstwo-paszporty-ewidencja.md | ✅ OK |
| Ustawa o emeryturach pomostowych — wykaz prac szczególnych | Dz.U. 2024 poz. 1696 t.j. ✅ VER: 2026-06-09 | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-narzedzie-kalkulatory.md | ✅ OK |
| Narzędzia procesowe — kalkulatory, kontrolery | — | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-narzedzie-kalkulatory.md | ✅ OK |
| KPC Księga IV — postępowanie w razie zaginięcia/zniszczenia akt (art. 716-729) | Dz.U. 2026 poz. 468 t.j. (ta sama pozycja co KPC ogólne, inna księga) | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-KPC-odtworzenie-akt-zaginionych-zniszczonych.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy) |
| Narzędzie: kontroler kompletności (wewnętrzny mechanizm jakości, nie akt prawny) | — (narzędzie proceduralne skilla, nie ustawa) | dr-16-pisma-strategia-dowody-orzecznictwo/modules/mod-narzedzie-kontroler-kompletnosci.md | ✅ NOWY 2026-07-18 (dopisane do głównej mapy) |

---

## SKILLE WYKONAWCZE I SHARED — akty powołane poza DR (monitoring t.j.)

> Dodano 2026-10-11 (zgł. #109, polecenie właściciela): akt, którego t.j. lub zmiany po t.j. są powołane
> w skillu wykonawczym albo w `shared` (nie tylko w DR), ma tu wiersz z miejscem powołania. Przy audycie DZU
> (FAZA 3D) zmiana t.j. albo nowa zmiana po t.j. → popraw każdy plik z kolumny „Powołany w”.
> Zapis w piśmie: `shared/FORMAT-CYTOWANIA.md`; tu metryka.

| Akt | Ostatni t.j. (ELI) | Zmiany po t.j. (wejście w życie) | Powołany w (poza DR) | DR-właściciel | Status |
|---|---|---|---|---|---|
| ustawa o kosztach sądowych w sprawach cywilnych | DU/2025/1228 | 2026 poz. 473 (8.07.2026), 1003 (28.10.2026), 346 (30.09.2028) | pisma-proste-v2/references/SPF-SPG.md, pisma-proste-v2/references/SPH-inne.md (art. 102 ust. 1), shared/oplaty/01-KSCU-cywilne-rodzinne-pracownicze.md, shared/FORMAT-CYTOWANIA.md (skrót u.k.s.c.) | DR-12 | ⚡ WCHODZI (1003) — ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI) |
| rozporządzenie ws. „Zasad techniki prawodawczej” | DU/2026/300 | brak | shared/FORMAT-CYTOWANIA.md (§ 57, 59, 154, 158, 162), analizator-umow-v1/references/generator/kategorie-klauzul-taksonomia.md | DR-01 | ✅ OK — ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI) |
| ustawa — Prawo o adwokaturze | DU/2024/1564 | 2025 poz. 1172 (1.03.2026), 2026 poz. 370 (3.04.2026), 846 (1.10.2026), 1290 (17.10.2026) | shared/DISCLAIMER.md (art. 4 ust. 1, tytuł bez dziennika) | DR-12 | ⚡ WCHODZI (1290) — ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI) |
| ustawa o radcach prawnych | DU/2024/499 | 2025 poz. 1172 (1.03.2026), 2026 poz. 370 (3.04.2026), 731 (18.06.2026), 846 (1.10.2026) | shared/DISCLAIMER.md (art. 6 ust. 1, tytuł bez dziennika) | DR-12 | ✅ OK — ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI) |

## MONITORING — Akty opublikowane, niebędące jeszcze w pełni w życiu

> **Procedura audytu (FAZA 3D):** Przy każdym audycie DZU sprawdź każdy wpis.
> Akt, który wszedł w życie → zmień Status w tabeli DR powyżej na ✅ OK, usuń z tej tabeli.
> Akt uchylony przed wejściem → status ❌, usuń, odnotuj w AUDIT-JOURNAL.

| Akt | Dz.U. | Data wejścia w życie | Zmienia / zastępuje | DR-skill | Status |
|---|---|---|---|---|---|
| Ordynacja podatkowa — nowelizacje po t.j. | 2026 poz. 825, 846, 875, 1098, 1206 | 24.09.2026 (825) · 1.10.2026 (846; pkt 9 od 26.06.2026) · 1.01.2027 (875 art. 6; 1098 art. 35) · 11.01.2027 (1206 art. 3) — 1154 art. 2 w mocy od 16.09.2026 | OP t.j. 2026.622 | DR-06 | ⚡ WCHODZI / ⏳ OCZEKUJE — ✅ [VER: api.sejm.gov.pl/eli, art. końcowe DU/2026/825, 846, 875, 1098, 1154, 1206, 2026-09-22] |
| Prawo energetyczne — art. 9, 11, 13, 14 | 2026 poz. 516 | 16.10.2026 (art. 38 pkt 2; reszta ustawy w mocy od 30.04.2026, wybrane przepisy od 16.04.2026 — KOREKTA F-195) | PrEnergetyczne t.j. 2026/43 (ELI 2026-10-09; było „2025.459” — rozporządzenie MF) | DR-09 | ⚡ WCHODZI — ✅ [VER: api.sejm.gov.pl/eli, DU/2026/516 text.pdf, 2026-09-22] |
| ⛔ **EUDR — rozporządzenie (UE) 2023/1115**, art. 3-13, 16-24, 26, 31, 32 | CELEX `32023R1115` (skons. `02023R1115-20251226`) | **30.12.2026**; osoby fizyczne oraz mikro- i małe przedsiębiorstwa ustanowione do 31.12.2024 — **30.06.2027** | uchyla rozp. (UE) nr 995/2010 | DR-09 | ⏳ OCZEKUJE — ⛔ data przesuwana **dwukrotnie**; przed użyciem odczytać AKTUALNĄ wersję skonsolidowaną, nie ten wiersz |
| KSCU — zmiany po t.j. 2025/1228 | 2026 poz. 1003, 346 | 28.10.2026 (1003 — ustawa o systemach sztucznej inteligencji) · 30.09.2028 (346) | KSCU t.j. 2025/1228; powołany też w pisma-proste-v2 (sekcja SKILLE WYKONAWCZE) | DR-12 | ⚡ WCHODZI / ⏳ OCZEKUJE — ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`) |
| Prawo o adwokaturze — zmiana po t.j. 2024/1564 | 2026 poz. 1290 | 17.10.2026 (art. 1 pkt 16, 41, 42 od 1.01.2027) | art. 4 ust. 1, art. 7 ust. 3, dział VIIIa | DR-12 | ⚡ WCHODZI — ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`; treść: wiersz DR-12) |
| KPK — tekst jednolity i nowelizacje po nim | **Dz.U. 2026 poz. 490 t.j.** ✅ [VER] RZĄD 1 2026-09-10f — obwieszczenie Marszałka Sejmu z 27.03.2026, status obowiązujący | — (t.j.; daty nowelizacji — u źródła, ELI) | ⛔ KROK 2C: **PIĘĆ nowelizacji po tekście jednolitym** — Dz.U. 2026 poz. 421, 638, 760, 882 i 901; brzmienie artykułów KPK zawsze u źródła. ⛔ **Zamknięcie sygnału `❌ NUMER BŁĘDNY`:** `Dz.U. 2025 poz. 1390` to rozporządzenie Ministra Finansów i Gospodarki z 12.10.2025 o poborze zryczałtowanego podatku — potwierdzone w RZĘDZIE 1, że NIE ma związku z KPK. Numer usunięty z wiersza jako nienależący do tej materii; żaden akt zmieniający KPK nie został pod nim błędnie zaewidencjonowany, więc nie ma czego korygować — była to pusta referencja. | DR-03 | ✅ ROZSTRZYGNIĘTE 2026-09-10f |

### Legenda statusów MONITORING

| Status | Znaczenie |
|---|---|
| ⏳ OCZEKUJE | Opublikowany, vacatio legis w toku — nie stosuj do zdarzeń wcześniejszych |
| ⚡ WCHODZI | Data wejścia w ciągu 90 dni od daty audytu — zaktualizuj moduł przed tą datą |
| ✅ WSZEDŁ | Wszedł w życie — przesuń do tabeli DR, usuń z MONITORING |
| ❌ UCHYLONY | Uchylony przed wejściem — usuń, odnotuj w AUDIT-JOURNAL |
| ❌ NUMER BŁĘDNY | Numer Dz.U. w mapie nie odpowiada opisanemu aktowi — wymaga ustalenia właściwego numeru przed użyciem, nie usuwać do wyjaśnienia |

---

*Wersja: 5.5 | Data: 2026-07-13 (TRYB DZU cotygodniowy)*
*Łączna liczba wpisów w tabelach DR: 275 (262 ✅ + 9 🔗 + 4 ⏳/⚡; w tym 1 pozycja ❌ NUMER BŁĘDNY do wyjaśnienia — patrz DR-03 KPK 2025.1390)*
*Korekta 2026-09-22 (F-195): z MONITORING usunięto 2 wiersze, które weszły w życie — KPK 2026/638 (28.05.2026) i PrBud 2025/1847 art. 1 pkt 1 i 3 (20.09.2026); poprawiono daty 2026/516; OP oznaczona ⬛ (uzupełniona w 6.29 — sześć nowelizacji po t.j.). Licznik powyżej NIE był przeliczany. Wiersz DR-03 „KPK 2026.638" uzupełniony o stan RZĄD 1.*
*Źródła lokalne: dr-01..dr-16/MAPA-AKTOW.md | Źródło centralne: audyt-systemu-v4/references/mapa_dzu_2026-10-04.md (KOREKTA 2026-10-04: nowa generacja po Dz.U. 2026 poz. 1161; ⚠️ KOREKTA 2026-09-27p: wskazywało mapa_dzu_2026-07-15.md — generacja nieaktualna od 2026-08; bieżąca wg frontmattera audytu: 09-22, F-193) (⚠️ KOREKTA 2026-07-15: poprzedni wpis wskazywał "mapa_dzu_2026-07-13.md" — plik o tej nazwie NIGDY nie istniał w audyt-systemu-v4/references/; aktualne pliki to 06-14 → 07-02 → 07-04 → 07-15)*
*TRYB DZU 2026-06-14: WARN-8 ZAMKNIĘTY — 16/16 pozycji zweryfikowane na ISAP
i naprawione w dwóch sesjach. Sesja 1 (5 poz.): A1 notariat→2026/614, A2
PrAut→2025/24, A3 komornicy→2024/1458 potwierdzony (ROUTING był już poprawny; KOREKTA: wcześniejszy wynik '2026/26' był błędem wyszukiwania - to inny akt, Ustawa SUS), B1 mandat posła/senatora→2024/907,
B2 referendum→2025/300. Sesja 2 (11 poz.): A4 regulatorzy (rozwinięto na
4 akty per regulator, zgodnie z tabelą wewnętrzną modułu), A5 KSCU→2025/1228,
A6 informacje niejawne→2025/1209, B3 otwarte dane→2023/1524 t.j., B4
KKS+AML→2025/644, B5 PKWiU rejestracja w ROUTING + Op pointer, C2
narkomania→2023/1939 (dodany), C3 odpowiedzialność podmiotów
zbiorowych→2024/1822 (był 2024/1247, też nieaktualny!), C4 prawa
pacjenta→2024/581 (dodany), C5 działalność lecznicza→2026/156 (był 2024/799,
podwójnie nieaktualny). Pełny dziennik:
audyt-systemu-v4/references/AUDIT-JOURNAL.md, AUDYT-2026-06-14f.*
