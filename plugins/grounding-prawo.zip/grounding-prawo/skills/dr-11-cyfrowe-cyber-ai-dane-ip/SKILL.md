---
name: dr-11-cyfrowe-cyber-ai-dane-ip
description: 'Moduł wewnętrzny DR-11: RODO, dowody cyfrowe, cyberbezpieczeństwo, prawo autorskie. Wczytywany przez prawny-router-v3; nie wywołuj bezpośrednio.'
metadata:
  version: '3.28'
  dependencies: '{"requires": ["shared"]}'
---

## Pamięć sesji — przed pracą i przed odpowiedzią końcową

Przeczytaj `shared/BASIC-MEMORY.md`, `shared/ZASADY-PLUGINU.md` oraz katalog `shared/INDEKS-SKILLI.md`. Przy redakcji pisma wczytaj `shared/STYLE.md`; przy zapisie plików `shared/ARTEFAKTY-SPRAWY.md`. Na wejściu odczytaj kluczowe trwałe ustalenia z `model-memory`, ostatni recap z `main` i sprawę z `legal`; po etapach zapisuj recap sesji w `main/sesje/` i sprawdź odczytem. Do `model-memory` dodawaj wyłącznie nowe, wartościowe key takeaways; nigdy logu sesji. Nowe dokumenty i ustalenia zapisuj w `legal` po każdym zakończonym etapie. Podaj status pamięci i identyfikator notatki; nie zgłaszaj zapisu bez potwierdzenia MCP.

## Repertorium - pierwsze źródło w każdym zadaniu prawnym

Zanim powołasz, ocenisz albo pominiesz przepis, orzeczenie lub kwalifikację, wywołaj przez portal `lex` `repertorium_szukaj_repertorium` (wyszukiwanie semantyczne ustaw, orzeczeń SN, sądów powszechnych, NSA/WSA, TK i decyzji UODO): co najmniej jedno zapytanie o zagadnienie i stan faktyczny (`jurysdykcja="pl"`), osobne dla każdej tezy, zarzutu lub żądania pisma, a przy wątku unijnym (RODO, prawo UE, TSUE) także `"eu"`. Opisuj problem słowami, nie tylko numerem artykułu lub sygnaturą. Trafienia sprawdź w pełnym brzmieniu (`shared/MOD-TEKST-JEDNOLITY.md`) i w treści orzeczenia; fragment z wyniku nie jest cytatem. Zapytania i wykorzystane trafienia zapisz w śladzie przebiegu (`_PRZEBIEGI.md` albo `analiza/_dowody-i-przepisy.md`). Kontrola prawa bez zapytań do Repertorium ma wynik `NOT_CHECKED`; awaria lub brak trafień to wpis w śladzie, po którym szukasz dalej w `ustawy`, `saos`, `nsa`, `uodo`, `eu-sparql`.

> **Universal runtime:** przed wykonaniem zastosuj kanoniczny `shared/UNIVERSAL-RUNTIME-ADAPTER.md` z osobnego skilla `shared`. Lokalna sekcja adaptera poniżej jedynie go doprecyzowuje.


## ADAPTER RUNTIME — PORTABILITY (ChatGPT / Claude / inne hosty)

Ta sekcja zmienia wyłącznie wykonanie operacji technicznych. Merytoryka dziedzinowa, mapy aktów, hard gate’y, kolejność modułów i kryteria jakości tego DR-skilla pozostają bez zmian.

1. `view dr-11-cyfrowe-cyber-ai-dane-ip/<plik>` oraz `view modules/...` / `view references/...` oznaczają świeży odczyt odpowiedniego lokalnego pliku tego skilla. Literalna ścieżka `/mnt/skills/user` nie jest wymagana.
2. `view shared/<plik>` oznacza świeży odczyt z osobnego, kanonicznego skilla `shared`. NIE kopiuj `shared` do tej paczki. Brak obowiązkowego zasobu shared = fail-closed, nie substytucja pamięcią modelu.
3. `view <inny-skill>/<plik>` oznacza aktywację/odczyt wskazanego osobnego skilla. Nie vendoryzuj innych skilli do tego ZIP-a.
4. `web_search` / `web_fetch` i podobne nazwy oznaczają świeże wyszukanie/odczyt online przez równoważną funkcję hosta. Zachowaj wymagane źródła oficjalne, statusy weryfikacji i zakaz cytowania prawa z pamięci.
5. `show_widget`, `visualize:read_me`, `present_files`, `create_file`, shell/Python i podobne operacje są nazwami semantycznymi. Jeśli host nie ma literalnego narzędzia, użyj równoważnej funkcji natywnej bez omijania bramek jakości.
6. `/mnt/user-data/...` oznacza rzeczywiste załączniki użytkownika dostępne w bieżącym hoście; wymagany ponowny odczyt ma być faktycznym odczytem źródła.

**Zasada nadrzędna:** instrukcje, które są już zrozumiałe i wykonalne w bieżącym hoście, wykonuj bez konwersji. Adapter działa wyłącznie na granicy runtime.


# DR-11 — Cyfrowe, Cyberbezpieczeństwo, AI, Dane, IP

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem przepisu, etapu stosowania, sygnatury lub stawki kary:**
1. Zweryfikuj brzmienie i Dz.U. w `ELI (RZĄD 1)` (akty krajowe)
2. Zweryfikuj rozporządzenia i dyrektywy UE w `eur-lex.europa.eu`
3. **NIGDY** nie podawaj artykułu, daty wejścia w życie, etapu stosowania ani sygnatury wyłącznie z pamięci modelu.

**Prawo cyfrowe UE zmienia się dynamicznie — etapy stosowania AI Act, CRA, DORA są kroczące.**

Kluczowe daty na 2026-06-05:
- ✅ AI Act art. 5 zakazy + AI Literacy: obowiązują od 02.02.2025
- ✅ AI Act GPAI: obowiązuje od 02.08.2025
- ⏳ AI Act systemy wysokiego ryzyka (Aneks III): od 02.08.2026
- ✅ KSC nowelizacja NIS2: Dz.U. 2026 poz. 252, w życie 03.04.2026
- ✅ DORA: obowiązuje od 17.01.2025
- ✅ MiCA: w pełni od 30.12.2024
- ⏳ CRA (Cyber Resilience Act): stosowanie do 11.12.2027


> ⛔ **SELF-CHECK ANTY-FASADA — obowiązkowy przed wysłaniem odpowiedzi/pisma**
> (podłączone 2026-08-24, flaga F-115 P3 — zamknięcie zakresu 16 skilli DR):
>
> ```
> view shared/SELF-CHECK-ANTY-FASADA.md
> ```
>
> Sprawdza dwie rzeczy: (1) czy w tekście stoi „zweryfikowano", data weryfikacji
> albo URL przy przepisie, dla którego NIE wywołano narzędzia W TEJ ODPOWIEDZI;
> (2) czy znacznik statusu nie został nadany treści WYGENEROWANEJ w tej odpowiedzi
> (AF-6). Treść listy jest w module, nie tutaj — celowo, żeby nie powstało kolejne
> miejsce dryfu (7 wcześniejszych kopii rozjechało się ze źródłem przy pierwszej
> zmianie brzmienia).
>
> ⛔ Wyzwalaczem jest BRAK WYWOŁANIA NARZĘDZIA dla danego twierdzenia w danej
> odpowiedzi — nie brak narzędzi w sesji. Niedostępność ELI (oba kanały) nie zwalnia z
> oznaczenia, tylko je wymusza; niedostępność ISAP to stan normalny.

---

## Zasada architektoniczna
- Jeden moduł = jeden akt prawny (Dz.U. / Rozp. UE) lub wydzielony obszar
- Ten sam akt NIE może pokrywać dwóch różnych DR-skills

---

## ORKA-BAS — Definicje wspomagające (shared/ORKA-BAS-LEKSYKON.md)

Przy sprawach z tej dziedziny rozważ doładowanie (`view`) definicji:
- BAS-W18 Kluczowe definicje RODO art. 4 (dane osobowe, administrator, procesor,
  przetwarzanie, naruszenie ochrony danych)
- BAS-W25 Uzasadniony interes administratora (art. 6 ust. 1 lit. f RODO —
  test 3-etapowy LIA, decyzje UODO i NSA III OSK 2700/22)
- BAS-W36 ⚠️⚠️ TERMIN 02.08.2026: AI Act (rozp. UE 2024/1689) — system AI
  wysokiego ryzyka (art. 6 + Annex III). Pełny harmonogram wejścia w życie
  (02.2025/08.2025/08.2026/08.2027), obowiązki dostawcy i użytkownika,
  FRIA vs DPIA (kumulacja z RODO), status polskiej ustawy wdrożeniowej
  (Komisja Rozwoju i Bezpieczeństwa AI — projekt, brak uchwalenia 06.2026)

## DEFINICJE — shared/definicje/ (nieobecne — adnotacja audytowa 2026-06-14)

Ta dziedzina nie ma dedykowanego pliku w `shared/definicje/`. Cyfrowe, cyberbezpieczeństwo, AI, dane, IP — definicje RODO (art. 4), AI Act i KSC/NIS2 są obszerne i sektorowe; pokryte wprost w modułach mod-RODO-GDPR-2016-679, mod-AI-Act, mod-KSC-NIS2 (każdy z własną sekcją definicji ustawowych). Żaden plik shared/definicje/ nie obejmuje tej dziedziny bez duplikacji treści modułowej.
## Moduły (22 łącznie — ✓ 21 OK, ☐ 1 STUB [certyfikacja])

```
DANE OSOBOWE:
  [✓] OK    mod-ustawa-certyfikacja-cyberbezpieczenstwa
              (☐ STUB — uczciwie oznaczony, świadomie odłożony do czasu wejścia przepisów w życie; akt bazowy Dz.U. 2025 poz. 1017 potwierdzony. ZAREJESTROWANY 2026-08-14e (F-77 rozszerzona) — domyka lit. (a) flagi F-48 w warstwie REJESTRACYJNEJ; rozbudowa treści pozostaje otwarta)
  [✓] OK    mod-RODO-GDPR-2016-679
              (RODO Rozp. 2016/679 — zakres, podstawy przetwarzania, prawa podmiotów;
               scalony z: mod-RODO-framework; + sekcja UODO/trzy warstwy ochrony)
  [✓] OK    mod-RODO-szczegolowy
              (szczegółowy: 72h zgłoszenie naruszenia, DPO, DPIA, monitoring pracowników,
               wyrok TSUE C-300/21 i C-340/21, art. 82 odszkodowanie)
  [✓] OK    mod-UODO-postepowanie-ochrona-danych
              (2026-07-21: dodano sekcję 9 — merytoryczna treść skargi
               do Prezesa UODO [elementy, zasada subsydiarności, zakaz
               żądania kary, brak opłaty poza pełnomocnikiem 17 zł,
               termin 30/60 dni] + korekta terminologiczna GIODO→UODO
               [zastąpiony 25.05.2018, nie tylko zmiana nazwy]. Nowy
               wzór SPK w pisma-proste-v2. Odpowiedź na pytanie
               użytkownika o kompletność tematu GIODO/UODO)
              (postępowanie przed UODO: skarga, decyzja, SKARGA do sądu administracyjnego — postępowanie jednoinstancyjne, art. 7 ust. 2 u.o.d.o.,
               kary administracyjne; Dz.U. 2019 poz. 1781 t.j.)

DANE OSOBOWE — WARSTWA OPERACYJNA (dodano 2026-07-05, AUDYT-2026-07-05a;
wzorzec: bundle ochrona-danych / awesome-matematic-skills-pl):
  [✓] OK    mod-RODO-DPIA-ocena-skutkow
              (DPIA/OSOD art. 35–36: przesiew progu — wykaz UODO + 9 kryteriów
               EROD WP248 reguła ≥2, struktura 4 filarów art. 35 ust. 7,
               uprzednie konsultacje art. 36; relacja do FRIA z AI Act)
  [✓] OK    mod-RODO-DSAR-zadania-osob
              (żądania osób art. 12 + 15–22: klasyfikacja, deterministyczny
               zegar 1 miesiąc / +2 mies. wg rozp. 1182/71 art. 3 ust. 2 lit. c,
               bramki odmowy art. 12 ust. 5 / 17 ust. 3, draft + rejestr żądań)
  [✓] OK    mod-RODO-RCP-DPA-rejestr-powierzenie
              (RCP art. 30 ust. 1–2 pola obowiązkowe + mechaniczny checklist
               klauzul umowy powierzenia art. 28 ust. 3 lit. a–h; wynik
               deterministyczny KOMPLETNA / BRAKI)

CYBERBEZPIECZEŃSTWO I TELEKOMUNIKACJA:
  [✓] OK    mod-KSC-NIS2-cyberbezpieczenstwo-telekom
              (⚡ ALERT: nowelizacja KSC Dz.U. 2026 poz. 252, w życie 03.04.2026;
               podmioty kluczowe/ważne, samoidentyfikacja, CSIRT sektorowe,
               kary do 10 mln EUR / 7 mln EUR; termin obowiązków: 03.04.2027)
  [✓] OK    mod-PrTelekom-poczta-UKE
              (Prawo komunikacji elektronicznej Dz.U. 2024 poz. 1221 (ELI 2026-10-09; brak t.j.;
               zm.: Dz.U. 2025 poz. 637, 820, Dz.U. 2026 poz. 252, 815 (od 4.07.2026 — uchyla art. 42), 1296); UKE; poczta)
  [☐] STUB  mod-ustawa-certyfikacja-cyberbezpieczenstwa
              (nowa ustawa Dz.U. 2025 poz. 1017 z 25.06.2025 — krajowy system certyfikacji;
               STUB — wymaga rozbudowy po wejściu przepisów w pełni w życie)

AI I NOWE REGULACJE UE:
  [✓] OK    mod-AI-Act-framework
              (AI Act Rozp. 2024/1689; etapy stosowania; GPAI; zakazy od 02.02.2025;
               polska ustawa o AI — projekt zatwierdzony 01.04.2026, przed Sejmem;
               KRiBSI jako organ krajowy)
  [✓] OK    mod-DORA-eIDAS-cyfrowe-finanse
              (DORA Rozp. 2022/2554 od 17.01.2025; eIDAS 2.0 Rozp. 2024/1183; EUDIW)

AKTY CYFROWE UE (osobne moduły):
  [✓] OK    mod-DSA-digital-services-act
              (DSA Rozp. 2022/2065 — od 17.02.2024; moderacja treści, VLOP/VLOSE)
  [✓] OK    mod-DMA-digital-markets-act
              (DMA Rozp. 2022/1925 — gatekeeperzy od 06.03.2024)
  [✓] OK    mod-EUCS-CRA-akty-regulacyjne-UE
              (CRA Rozp. 2024/2847 — stosowanie do 11.12.2027; EUCS schematy certyfikacji)
  [✓] OK    mod-MiCA-kryptoaktywa
              (MiCA Rozp. 2023/1114 — w pełni od 30.12.2024; kryptoaktywa, stablecoiny)

WŁASNOŚĆ INTELEKTUALNA I IP:
  [✓] OK    mod-PrAut-wlasnosc-intelektualna-IP
              (prawo autorskie Dz.U. 2025 poz. 24 t.j. + własność przemysłowa
               Dz.U. 2023 poz. 1170 — znaki towarowe, patenty, wzory;
               scalony z: mod-PrAut-framework-IP)
  [✓] OK    mod-PrAut-media-internet-dobra-osobiste
              (media cyfrowe, internet, dobra osobiste online, DMCA, naruszenia IP w sieci)
  [✓] OK    mod-ustawa-prawo-wlasnosci-przemyslowej
              (Prawo własności przemysłowej Dz.U. 2023 poz. 1170 — patenty, znaki towarowe,
               wzory użytkowe i przemysłowe, UPRP; moduł atomowy uzupełniający mod-PrAut-IP)

USŁUGI CYFROWE I ELEKTRONICZNE:
  [✓] OK    mod-ustawa-uslugi-elektroniczne
              (usługi drogą elektroniczną Dz.U. 2024 poz. 1513 — częściowo deaktywowana przez DSA)
  [✓] OK    mod-ustawa-informatyzacja-podmiotow-publicznych
              (informatyzacja: Dz.U. 2026 poz. 1241 t.j.; e-Doręczenia; KSeF)
  [✓] OK    mod-ustawa-podpis-elektroniczny
              (podpis elektroniczny: eIDAS 1.0 Rozp. 910/2014 + UZIE Dz.U. 2016 poz. 1579)
  [✓] OK    mod-ustawa-otwarte-dane
              (otwarte dane i re-use: Dz.U. 2023 poz. 1524 t.j.)
```

---

## Jak wywołać

```
view dr-11-cyfrowe-cyber-ai-dane-ip/modules/[nazwa-modulu].md
```

## Lokalna mapa aktów prawnych

```
view dr-11-cyfrowe-cyber-ai-dane-ip/MAPA-AKTOW.md
```

## Mapa pokrycia treściowego (planowanie rozwoju skilla)

Rejestr informacyjny — NIE krok obowiązkowy przy obsłudze konkretnej sprawy.
Jedyne bieżące źródło statusu pokrycia tego DR (por. `prawny-router-v3/references/pokrycie-dziedzinowe.md`);
przy nowelizacji pokazuje, czy dotknięty fragment ma treść do zaktualizowania:

```
view dr-11-cyfrowe-cyber-ai-dane-ip/MAPA-POKRYCIA.md
```

---

## Powiązania zewnętrzne
- Wchodzi z: `prawo-polskie-v2` → `ROUTING-MAP.md` → ten skill
- Cyberprzestępstwa (KK art. 267–269b) → `dr-03`
- Prawo pracy + monitoring pracowników (RODO × KP) → `dr-04 (poza pluginem)`
- Prawo finansowe (DORA → sektor bankowy, MiCA → kryptogiełdy) → `dr-06 (poza pluginem)`
- Zamówienia publiczne IT → `dr-07 (poza pluginem)`
- AI Act / DSA / DMA — decyzja krajowa zaskarżona na podstawie Karty Praw Podstawowych UE (art. 47) lub EKPC → `dr-14` (mod-KPP-karta-praw-podstawowych-UE, mod-EKPC-ETPC-prawa-czlowieka); ten skill zachowuje analizę merytoryczną AI Act/DSA/DMA, DR-14 dostarcza podstawę praw podstawowych dla skargi
- Wychodzi do: `pisma-procesowe-v3` / `analiza-sadowa-v6` / `orzeczenia-sadowe-v2`
- Weryfikacja: ELI (RZĄD 1) | eur-lex.europa.eu | uodo.gov.pl | uprp.gov.pl | enisa.europa.eu

## ⚖️ DISCLAIMER (obowiązkowy)

Po zakończeniu analizy lub przed oddaniem odpowiedzi zawierającej ocenę prawną:

```text
view shared/DISCLAIMER.md
```

Wybierz wariant odpowiedni do trybu:
- **PRAWNIK / kancelaria** → wariant techniczny (art. 4 Prawa o adwokaturze / art. 6 u.r.p.)
- **LAIK / pro se** → wariant uproszczony (informacja ≠ porada prawna)

Disclaimer musi być **ostatnim elementem** każdej odpowiedzi zawierającej analizę prawną,
ocenę szans, kwalifikację prawną lub interpretację przepisu.

## MOST - miejsce w przepływie grounding-prawo

- **Wejście z:** `prawny-router-v3` albo `prawo-polskie-v2` (wybór domeny); materiał: `analiza/_brief.md`
- **Wynik zapisz w:** dopisek do `analiza/_dowody-i-przepisy.md` (przepisy z potwierdzeniem w ELI, nie z pamięci) (reguła: `shared/ARTEFAKTY-SPRAWY.md` - dopisuj do istniejących plików, nie twórz nowych raportów)
- **Następny krok:** `analizator-przepisow-v2`, `orzeczenia-sadowe-v2`, `pisma-procesowe-v3`
- **Nie dubluj:** domeny poza zakresem pluginu (praca, podatki, zamówienia publiczne, samorząd, budownictwo, compliance) nie mają modułów - powiedz to wprost, nie zgaduj
- **Basic Memory (`legal`):** czytaj teczkę sprawy (`build_context`) i notatki wiki po sygnaturze i nazwiskach; zapisz stan sprawy i terminy w teczce, nowe fakty z akt zgłoś do ingestu (protokół: `shared/BASIC-MEMORY.md`)
- **Mapa ścieżek:** `shared/SCIEZKI-PRACY.md` (router).
