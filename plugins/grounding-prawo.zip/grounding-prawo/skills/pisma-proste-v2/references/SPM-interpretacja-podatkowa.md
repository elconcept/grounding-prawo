# SPM — Wniosek o Interpretację Indywidualną Podatkową (KIS)

*Ładuj gdy: podatnik chce uzyskać wiążące stanowisko Dyrektora
Krajowej Informacji Skarbowej co do sposobu stosowania przepisów
podatkowych w JEGO indywidualnej sprawie (zaistniałym stanie
faktycznym LUB zdarzeniu przyszłym).*

---

## PODSTAWA PRAWNA

- **art. 14b-14p Ordynacji podatkowej** — przepis centralny
- Pełna mapa systemu interpretacji (indywidualna/ogólna/objaśnienia/
  opinia zabezpieczająca/WIS/WIA) → `dr-06/modules/mod-interpretacje- (poza pluginem)
  definicje-podatkowe.md` sekcja 1 (NIE duplikowana tutaj)

## KTO MOŻE ZŁOŻYĆ

```
□ KAŻDY podatnik, płatnik, inkasent LUB inny podmiot mający INTERES
  prawny w uzyskaniu interpretacji — NIE tylko przedsiębiorca (w
  odróżnieniu od interpretacji ZUS, SPJ, która jest zarezerwowana dla
  przedsiębiorców)
□ WE WŁASNEJ sprawie — dotyczącej JEGO zaistniałego stanu faktycznego
  LUB zdarzenia PRZYSZŁEGO
```

## ELEMENTY WNIOSKU

```
□ Dane wnioskodawcy (imię/nazwisko lub nazwa, adres, NIP/PESEL)
□ ⭐ WYCZERPUJĄCE przedstawienie ZAISTNIAŁEGO stanu faktycznego LUB
  zdarzenia PRZYSZŁEGO — organ jest ZWIĄZANY opisanym stanem, nie
  bada okoliczności POZA nim
□ WŁASNE STANOWISKO wnioskodawcy w sprawie oceny prawnej — WYMAGANE,
  nie samo pytanie
□ WSKAZANIE przepisów prawa podatkowego, KTÓRYCH dotyczy zapytanie
□ Podpis wnioskodawcy/pełnomocnika (+ pełnomocnictwo, jeśli dotyczy)
```

## OPŁATA I ZŁOŻENIE

```
□ OPŁATA: 40 zł za KAŻDY odrębny stan faktyczny/zdarzenie przyszłe
  opisane we wniosku (kilka pytań = wielokrotność 40 zł)
□ ZŁOŻENIE: przez ePUAP, portal podatki.gov.pl, lub pisemnie na adres
  Krajowej Informacji Skarbowej
```

## TERMIN I MECHANIZM MILCZĄCEJ ZGODY

```
□ TERMIN na wydanie: 3 MIESIĄCE od złożenia KOMPLETNEGO wniosku (art.
  14d Op) — jeśli organ ŻĄDA uzupełnienia, termin BIEGNIE OD DNIA
  uzupełnienia, nie od pierwotnego złożenia
□ ⭐ MILCZĄCA ZGODA: brak wydania interpretacji w terminie = UZNAJE
  SIĘ za interpretację ZGODNĄ ze stanowiskiem WNIOSKODAWCY (analogicznie
  do mechanizmu ZUS — SPJ — i milczącego załatwienia sprawy KPA)
```

## MOC OCHRONNA

```
□ Interpretacja WIĄŻE organ podatkowy WOBEC wnioskodawcy, JEŚLI:
  □ Podatnik ZASTOSOWAŁ SIĘ do niej PRZED wszczęciem kontroli/
    postępowania
  □ Interpretacja BYŁA wydana DLA TEGO wnioskodawcy (nie dla kogoś
    innego, choćby w analogicznej sprawie)
  □ NIE zmieniono przepisów ani stanu faktycznego
□ Interpretacja WYGASA przy zmianie/uchyleniu przez WSA/NSA, ALE NIE
  wygasa automatycznie przy zmianie PRZEPISÓW (chroni AŻ do wejścia w
  życie nowych przepisów)
```

## ZASKARŻENIE — TERMIN 30 DNI

```
□ Skarga do WSA — w TERMINIE 30 DNI od doręczenia interpretacji
  (art. 53 § 1 PPSA — obejmuje wprost akty z art. 3 § 2 pkt 4a; ✅ [VER] RZĄD 1 2026-09-16m,
  PPSA t.j. Dz.U. 2026 poz. 143; Ordynacja nie przewiduje terminu szczególnego)
□ Wnosi się za pośrednictwem organu, który wydał interpretację (art. 54 § 1)
⛔ KOREKTA 2026-09-16m: poprzednia wersja podawała „14 DNI (art. 53 § 3 PPSA — <!-- T28-OK: cytat opisowy — dokumentacja korekty -->
  termin krótszy niż standardowe 30 dni)". Art. 53 § 3 to 6 miesięcy dla
  prokuratora, RPO i RPD — skrócony termin nie istnieje.
```

## POWIĄZANE INSTRUMENTY (ładuj `mod-interpretacje-definicje-podatkowe.md` po szczegóły)

```
□ WIĄŻĄCA INFORMACJA STAWKOWA (WIS) — dla klasyfikacji towaru/usługi
  na potrzeby STAWKI VAT — INNY tryb niż zwykła interpretacja
□ OPINIA ZABEZPIECZAJĄCA — ochrona przed zastosowaniem GAAR, opłata
  25 000 zł, termin 6 miesięcy — dla PLANOWANYCH transakcji o dużej
  skali/złożoności
□ OBJAŚNIENIA PODATKOWE — wydawane przez MF, np. fundamentalne dla
  ulgi IP Box (objaśnienia z 15.07.2019 r.)
```

## CHECKLIST KOŃCOWY

```
□ Czy opis stanu faktycznego/zdarzenia przyszłego jest WYCZERPUJĄCY
□ Czy zaproponowano WŁASNE stanowisko (nie samo pytanie)
□ Czy uiszczono opłatę 40 zł (wielokrotność przy kilku pytaniach)
□ Czy klient rozumie RÓŻNICĘ między interpretacją indywidualną (jego
  własna sprawa) a WIS/opinią zabezpieczającą (inne tryby, inne opłaty)
□ Przy ZASKARŻENIU — pamiętaj o TERMINIE 14 DNI (nie 30!) do WSA

---

## ŹRÓDŁA

