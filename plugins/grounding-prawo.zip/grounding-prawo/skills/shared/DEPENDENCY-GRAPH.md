# DEPENDENCY-GRAPH.md — Rejestr zależności modułów shared/

*Wygenerowany: 2026-06-04 | Ostatnia aktualizacja: 2026-08-23 (v3.19 — usunięcie plików bez roli)*
*Aktualizuj przy każdej zmianie odwołań w systemie.*

> ⚠️ **Zakres:** graf opisuje pliki obecne w nim imiennie. Moduły dodane po 2026-07 (m.in.
> `MOD-*` kancelaryjne, `definicje/`, `orka-bas-leksykon/`, `portale-branzowe-rzad-2b/`,
> `DOMAIN-LOCK.md`, `RATE-COMPLETENESS.md`, `MOD-GENERATOR-AKTU.md`) są zarejestrowane
> w tabelach „Zawartość katalogu" w `SKILL.md`, ale NIE mają jeszcze wierszy tutaj —
> odnotowane 2026-08-23, nienaprawione w tej sesji (osobne zadanie).

## Legenda

- **ACTIVE** — plik wywołany bezpośrednio przez ≥1 skill poza shared/
- **INTERNAL** — plik używany tylko wewnątrz shared/ (przez inny moduł shared)
- ~~**STUB**~~ — kategoria zniesiona 2026-08-23 (v3.19): stub bez żywego konsumenta jest
  usuwany, nie oznaczany. Ostatni — `MOD-WALIDACJA.md`.
- ~~**ARCHIVE**~~ — kategoria martwa: katalog `shared/archive/` nie istnieje (2026-06-14).
  Plik wycofany jest usuwany, a powód zapisywany w `references/CHANGELOG.md`.

---

## Moduły walidacyjne

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `MOD-WALIDACJA_v2.md` | **ACTIVE — KANONICZNY** | pisma-procesowe-v3, pisma-proste-v2, prawny-router-v3 |
| `HYBRID-VALIDATION.md` | ACTIVE | pisma-procesowe-v3, pisma-proste-v2, analizator-umow-v1, prawny-router-v3 |
| `POST-VALIDATION.md` | ACTIVE | analizator-umow-v1, pisma-procesowe-v3 |
| `FACT-SOURCE-LOCK.md` | INTERNAL | wywoływany przez MOD-WALIDACJA_v2.md (Blok J), FAKTY_v2.md |
| `LEGAL-STATUS-LOCK.md` | INTERNAL | wywoływany przez MOD-WALIDACJA_v2.md (Blok J), FAKTY_v2.md |
| `FORMAL-CHECK.md` | ACTIVE | pisma-procesowe-v3 (W3.4, via AUTOMAT-STANOW.md/W3-WERYFIKACJA.md) |
| `FORMAT-CYTOWANIA.md` | ACTIVE — KANONICZNY | pisma-procesowe-v3 (W3.1, W3.6, MOD-PRAWO, MOD-SZABLONY), pisma-proste-v2 (KROK 9d), via HYBRID-VALIDATION / FORMAL-CHECK / AUDYT-KONCOWY / PRAWO-HARDGATE wszystkie skille generujące dokument |
| `agents/*.md` (3) | ACTIVE (Claude Code) | pisma-procesowe-v3 W3.1/W3.2/W3.7 (W3-WERYFIKACJA), MOD-PEER-REVIEW |
| `BRAKI-FORMALNE.md` | ACTIVE | pisma-procesowe-v3 (W3.4, via AUTOMAT-STANOW.md/W3-WERYFIKACJA.md) |
| `WARUNKI-SKUTECZNOSCI.md` | ACTIVE | pisma-procesowe-v3 (W3.4, via AUTOMAT-STANOW.md/W3-WERYFIKACJA.md) |
| `QUALITY-CHECK.md` | ACTIVE | pisma-procesowe-v3 (W3.4, via AUTOMAT-STANOW.md/W3-WERYFIKACJA.md) |
| `RISK-ASSESSMENT.md` | ACTIVE | wszystkie DR-skille, pisma-procesowe-v3 |

## Moduły faktów i danych wejściowych

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `FAKTY_v2.md` | ACTIVE | pisma-procesowe-v3, pisma-proste-v2 |
| `INTAKE-GAP.md` | ACTIVE | analizator-umow-v1, pisma-procesowe-v3, pisma-proste-v2, przewodnik-prawny-v2, dr-11 (mod-RODO-GDPR) |

## Moduły terminów i procedury

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `terminy.md` | ACTIVE | analizator-dowodow-v3, pisma-procesowe-v3, pisma-proste-v2, analiza-sadowa-v6, przewodnik-prawny-v2, analizator-umow-v1 |
| `TERM-CALC.md` | ACTIVE | pisma-procesowe-v3 (W3.4 walidacja formalna) |
| `TRYBY-PROCESOWE.md` | ACTIVE | pisma-procesowe-v3 (W3.4, via AUTOMAT-STANOW.md/W3-WERYFIKACJA.md) |
| `PREKLUZJA-DOWODOWA.md` | ACTIVE | pisma-procesowe-v3 (W3.4, via AUTOMAT-STANOW.md/W3-WERYFIKACJA.md) |
| `DISCLAIMER.md` | ACTIVE | prawny-router-v3, przewodnik-prawny-v2 |

## Moduły dowodowe i orzecznicze

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `DOWODY-METODOLOGIA.md` | ACTIVE | analizator-dowodow-v3, pisma-procesowe-v3 |
| `MOD-DOKUMENT-GATES.md` | ACTIVE | przesluchanie-swiadkow-v2-min90 (PRE-W1a.5), analizator-dowodow-v3 (KROK 0d) — utworzony 2026-08-20z, F-100 A |
| `ORZECZENIA-HIERARCHIA.md` | INTERNAL→ACTIVE | orzeczenia-sadowe-v2, pisma-procesowe-v3 |
| `ROSZCZENIA.md` | INTERNAL→ACTIVE | pisma-procesowe-v3 |
| `STRATEGIA-PROCESOWA.md` | ACTIVE | pisma-procesowe-v3, analiza-sadowa-v6 |

## Moduły prawa materialnego (DR-skille)

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `RISK-ASSESSMENT.md` | ACTIVE | wszystkie DR-01..DR-16 |
| `TEMPORAL-LAW-CHECK.md` | ACTIVE | wszystkie DR-01..DR-16 |
| `ISAP-AUDIT-PROTOCOL.md` | ACTIVE | wszystkie DR-01..DR-16, pisma-procesowe-v3 (via KROK1-detekcja.md, W3-WERYFIKACJA.md) |
| `MODULE-STANDARD-POLISH-LAW.md` | ACTIVE | wszystkie DR-01..DR-16 |
| `LEGAL-QUALITY-GATE.md` | ACTIVE | wszystkie DR-01..DR-16 |
| `ISAP-METRYKI-AKTOW.md` | ACTIVE | wszystkie DR-01..DR-16 |
| `FORMAL-CHECK.md` | ACTIVE | wszystkie DR-01..DR-16 |
| `LEGAL-LIFECYCLE-MANAGEMENT.md` | ACTIVE | wybrane DR-skille |
| `PRAWO-HARDGATE.md` | ACTIVE | wszystkie skille z przepisami |
| `PRAWO-HARDGATE-ORZECZENIA.md` | ACTIVE | skille cytujące ORZECZENIA — załącznik do powyższego, wyzwalacz binarny: sygnatura w tekście (podział F-111, 2026-08-23h) |
| `CBOSA-ADAPTER.md` | ACTIVE | HIERARCHIA-ZRODEL, SYGNATURY, DOSTEP-MASZYNOWY-API, PRAWO-HARDGATE-ORZECZENIA, MCP-INTEGRACJA; direct NSA/WSA przed fallbackiem indeksowym |

## Moduły scalone do shared/ 2026-07-12 (audyt komercyjny — ci_check_shared.py)

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `NAZEWNICTWO-STRON.md` | ACTIVE | shared/FORMAL-CHECK.md, analizator-dowodow-v3, pisma-proste-v2 |
| `STALKING-NEKANIE.md` | ACTIVE | dr-03 (mod-KK-art190a-stalking.md, mod-KK-kwalifikator-karnomaterialny.md) |
| `PRZESLUCHANIE-SWIADKOW-KPC.md` | ACTIVE | dr-16 (ramowy KPC art. 258-305 — nie mylić z pełnym skillem przesluchanie-swiadkow-v2-min90) |

## Narzędzia deweloperskie (kod, nie markdown — poza pipeline'em LLM)

| Plik | Status | Rola |
|------|--------|------|
| `audyt-systemu-v4/scripts/ci_check_shared.py` | ACTIVE (dev/CI) | Wykrywa zerwane odwołania view() i duplikaty MD5 w całym silniku; git pre-commit hook |
| `tools/walidator_cytowan.py` | ACTIVE (produkcyjna bramka, poza LLM) | Sprawdza, czy każde powołanie w finalnym piśmie ma odpowiadające zdarzenie weryfikacji w logu sesji API — uruchamiane przez portal przed present_files, nie przez skille |
| `tools/extract_api_verification_log.py` | ACTIVE (produkcyjna bramka, poza LLM) | Dodany 2026-07-13d. Buduje log sesji wymagany przez walidator_cytowan.py automatycznie z surowej konwersacji Claude API (bloki server_tool_use/*_tool_result) — domyka lukę integracyjną opisaną w README (krok 1) |
| `tools/export_gate.py` | ACTIVE (produkcyjna bramka, poza LLM) | Dodany 2026-07-13d. Łączy extract_api_verification_log.py + walidator_cytowan.py w jedno wywołanie — jedyny punkt, który portal musi wpiąć w pipeline przed present_files/eksportem |
| `MCP-INTEGRACJA.md` + `KONEKTORY-REKOMENDOWANE.md` + `SCHEMAT-ODPOWIEDZI-MCP.md` | ACTIVE (protokół ładowany przez router) | Skonsolidowane 2026-07-13f z osobnego skilla mcp-zrodla-prawa-v1 (usunięty). Warstwa MCP jako uzupełnienie PRAWO-HARDGATE.md — patrz `required_modules` w prawny-router-v3 |
| `tools/test_mcp_protocol.py` + `tools/connector_health_check.py` | ACTIVE (testy/narzędzia dev, poza LLM) | Skonsolidowane 2026-07-13f razem z MCP-INTEGRACJA.md. Klasyfikacja odpowiedzi connectora (6 testów jednostkowych) + health-check dostępności connectorów. ⚠️ Nieobecne na dysku 2026-08-27→2026-09-26d mimo statusu ACTIVE tutaj (usunięte tym samym mergem `d3385b9` co pliki F-206, spoza jego pierwotnie opisanego zakresu) — przywrócone 2026-09-26d, 6/6 testów i `--self-test` PASS |
| `AUDIT-TRAIL-SPEC.md` | ACTIVE (specyfikacja, poza silnikiem) | Skonsolidowane 2026-07-13f z osobnego skilla audit-trail-portal-v1 (usunięty). Specyfikacja logu hash-chain zgodnego z art. 12 AI Act, do wdrożenia po stronie portalu |
| `tools/hash_chain_verify.py` + `append_event.py` + `router_event_parser.py` | ACTIVE (referencyjne, poza LLM) | Skonsolidowane 2026-07-13f razem z AUDIT-TRAIL-SPEC.md. Zapis/weryfikacja/parsowanie logu hash-chain. ⚠️ Nieobecne na dysku 2026-08-27→2026-09-26d mimo statusu ACTIVE tutaj (usunięte tym samym mergem `d3385b9` co pliki F-206, spoza jego pierwotnie opisanego zakresu) — przywrócone 2026-09-26d, zweryfikowane end-to-end (zapis 3-wpisowego łańcucha + wykrycie ręcznie spreparowanego naruszenia) |


## Moduły orkiestratora i routingu

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `ACTIVATION-MATRIX.md` | ACTIVE | prawny-router-v3 |
| `CROSS-DOMAIN-CONFLICT-ROUTER.md` | ACTIVE | prawny-router-v3, prawo-polskie-v2 |
| `SYGNATURY.md` | ACTIVE | orzeczenia-sadowe-v2, prawny-router-v3 |

## Moduły pokrycia prawnego (matryce)

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `POLISH-LAW-COMPLETENESS-MATRIX.md` | ACTIVE | DR-skille, audyt-systemu-v4 |
| `POLISH-LAW-FINAL-COMPLETENESS-GATE.md` | ACTIVE | DR-skille |
| `POLISH-LAW-MAX-COVERAGE-STANDARD.md` | ACTIVE | DR-skille |
| `LEGAL-KNOWLEDGE-GRAPH.md` | ACTIVE | DR-skille, analiza-sadowa-v6 |
| `LEGAL-REGISTRY.md` | ACTIVE | DR-skille |
| `EXPERT-OPINION-AUDIT.md` | ACTIVE | analiza-sadowa-v6, analizator-dowodow-v3 |

## Moduły zarządzania systemem

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `DEDUPLICATION-POLICY.md` | ACTIVE (deweloper) | audyt-systemu-v4 |

## Raporty i integracje

| Plik | Status | Wywołujące skille |
|------|--------|-------------------|
| `raport-sytuacyjny-integracja.md` | ACTIVE | prawny-router-v3 |

---

## Zasady utrzymania

1. **MOD-WALIDACJA_v2.md** jest jedynym plikiem kanonicznym walidacji. Nie twórz v3 bez usunięcia v2.
2. **Stubów nie tworzymy i nie utrzymujemy.** Przy zmianie nazwy pliku kanonicznego poprawia się
   wywołania u konsumentów, nie zostawia przekierowania (v3.19, 2026-08-23).
3. **Plik bez konsumenta jest usuwany**, nie oznaczany jako nieaktywny. Uzasadnienie i data —
   `references/CHANGELOG.md`. Wyjątek: pliki wskazane przez otwarte flagi F- (np. `tools/`
   przy F-8/F-10/F-11) mają konsumenta odroczonego, nie zerowego.
4. Pliki **INTERNAL** są ładowane tylko przez inne moduły shared/ — nie wymagają odwołań z zewnątrz.
5. Przy dodawaniu nowego pliku do shared/ — zaktualizuj ten graf i SKILL.md.
