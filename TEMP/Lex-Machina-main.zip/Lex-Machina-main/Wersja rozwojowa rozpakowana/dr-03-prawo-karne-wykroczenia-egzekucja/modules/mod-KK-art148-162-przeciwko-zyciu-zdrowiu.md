# Przestępstwa przeciwko życiu i zdrowiu — ujęcie systemowe (art. 148-162 KK) v1.0.0 (dodany 2026-07-16)

> ⛔ Do 2026-07-16 przepisy tego rozdziału pojawiały się fragmentarycznie
> (art. 148 i 156/157 incydentalnie w kwalifikatorze) bez systemowego
> drzewa odróżniającego typy zabójstwa i relacji między nimi. Ten moduł
> naprawia lukę.
> ⚠️ Zweryfikowane 2026-07-16 — do potwierdzenia na isap.sejm.gov.pl.

---

## DRZEWO Z.1 — TYPY ZABÓJSTWA (art. 148 KK) — hierarchia od najsurowszego

```
START: Czy sprawca umyślnie spowodował śmierć człowieka?
│
├─ NIE (nieumyślnie) → art. 155 KK (nieumyślne spowodowanie śmierci,
│  3 m-ce – 5 lat) — NIE zabójstwo w rozumieniu art. 148
│
└─ TAK → sprawdź OKOLICZNOŚCI KWALIFIKUJĄCE/UPRZYWILEJOWUJĄCE:
   │
   ├─ Typ podstawowy (art. 148 §1) → 10-30 lat pozbawienia wolności
   │  lub dożywocie (⚠️ POPRAWKA 2026-07-26, F-15/MOD-PROPAGACJA-
   │  NOWELIZACJI: USUNIĘTO "25 lat" — ta odrębna kategoria kary
   │  ZNIESIONA reformą z 7.07.2022, Dz.U. 2022 poz. 2600, w życie 1.10.2023;
   │  zastąpiona jednolitą karą terminową do 30 lat. Potwierdzone w 8+
   │  źródłach: chmielniak.com.pl, hplegal.pl, weredynscy.pl,
   │  jhcadwokaci.pl, durajreck.com, gov.pl [J. Kluza, Prokuratura i
   │  Prawo], zzbudowlani.pl, lawyersoffice.pl)
   │
   ├─ Typ KWALIFIKOWANY (art. 148 §2) — jeśli sprawca działał:
   │  ze szczególnym okrucieństwem / w związku z wzięciem zakładnika,
   │  zgwałceniem, rozbojem / w wyniku motywacji zasługującej na
   │  szczególne potępienie / z użyciem broni palnej lub materiałów
   │  wybuchowych → 15-30 lat lub dożywocie (⚠️ POPRAWKA 2026-07-26:
   │  było błędnie "12-30 lat, 25 lat" — dolna granica to 15 lat, nie
   │  12, i bez odrębnej kary 25 lat; potwierdzone dosłownym brzmieniem
   │  w lexlege.pl i arslege.pl: "podlega karze pozbawienia wolności na
   │  czas nie krótszy od lat 15")
   │
   ├─ Typ SZCZEGÓLNIE KWALIFIKOWANY (art. 148 §3) — zabójstwo więcej niż
   │  jednej osoby jednym czynem, LUB sprawca był wcześniej prawomocnie
   │  skazany za zabójstwo → 15-30 lat lub dożywocie (⚠️ ta sama
   │  poprawka co §2 — §3 KK odsyła wprost do zagrożenia z §2, "karze
   │  określonej w §2 podlega...")
   │
   ├─ Typ UPRZYWILEJOWANY — DZIECIOBÓJSTWO (art. 149 KK): matka zabija
   │  dziecko w okresie porodu, POD WPŁYWEM JEGO PRZEBIEGU → 3 m-ce –
   │  5 lat (znacznie łagodniej niż art. 148 — przesłanka podmiotowa:
   │  szczególny stan emocjonalny związany z porodem, wąsko interpretowana)
   │
   ├─ Typ UPRZYWILEJOWANY — ZABÓJSTWO W AFEKCIE (art. 148 §4): pod
   │  wpływem silnego wzburzenia usprawiedliwionego okolicznościami →
   │  1-10 lat (test obiektywny usprawiedliwienia — nie każde wzburzenie
   │  subiektywne sprawcy się kwalifikuje)
   │
   ├─ EUTANAZJA (art. 150 KK) — zabójstwo na żądanie ofiary i pod wpływem
   │  współczucia dla niej → 3 m-ce – 5 lat, sąd MOŻE zastosować
   │  nadzwyczajne złagodzenie lub odstąpić od wymierzenia kary (§2)
   │
   └─ POMOC/NAMOWA DO SAMOBÓJSTWA (art. 151 KK) — jeśli doszło do
      targnięcia się na życie (dokonanego lub usiłowanego) → 3 m-ce –
      5 lat. ⚠️ Odróżnij od art. 148: tu ofiara SAMA pozbawia się życia,
      sprawca tylko nakłania lub pomaga — jeśli sprawca sam wykonuje
      czynność zabójczą "na życzenie" ofiary → to eutanazja (art. 150),
      nie art. 151
```

⚠️ **Usiłowanie nieudolne przy zabójstwie** (np. sprawca strzela do
osoby już martwej, nie wiedząc o tym) — kwalifikuj z art. 13 §2 w zw.
z art. 148, z fakultatywnym nadzwyczajnym złagodzeniem lub odstąpieniem
od wymierzenia kary (art. 14 §2 KK).

---

## DRZEWO Z.2 — USZKODZENIE CIAŁA / USZCZERBEK NA ZDROWIU (art. 156-157 KK)

```
START: Jaki był SKUTEK zdrowotny?
│
├─ CIĘŻKI uszczerbek (art. 156 §1) — katalog zamknięty: pozbawienie
│  wzroku/słuchu/mowy/zdolności płodzenia, inne ciężkie kalectwo,
│  choroba realnie zagrażająca życiu, choroba psychiczna trwale
│  nieuleczalna, całkowita/znaczna trwała niezdolność do pracy,
│  trwałe, istotne zeszpecenie/zniekształcenie → 3-20 lat
│  (umyślnie; art. 156 § 1 w brzmieniu obowiązującym od 1.10.2023);
│  §2 (nieumyślnie) → do 3 lat
│  │
│  └─ Ze skutkiem śmiertelnym (sprawca chciał ciężkiego uszczerbku,
│     śmierć była skutkiem nieumyślnym — art. 156 §3, zbieg umyślno-
│     -nieumyślny) → co najmniej 5 lat albo dożywotnie pozbawienie
│     wolności — ⚠️ NIE MYLIĆ z zabójstwem (148),
│     kluczowa jest strona podmiotowa co do SKUTKU ŚMIERTELNEGO
│     (musi być nieumyślna, inaczej to już 148)
│
├─ ŚREDNI uszczerbek (art. 157 §1) — naruszenie czynności narządu ciała
│  lub rozstrój zdrowia na okres > 7 dni → 3 m-ce – 5 lat, ŚCIGANIE
│  Z URZĘDU
│
└─ LEKKI uszczerbek (art. 157 §2) — naruszenie/rozstrój ≤7 dni →
   do 2 lat, ŚCIGANIE PRYWATNOSKARGOWE (§4) — WYJĄTEK: jeśli
   pokrzywdzonym jest osoba najbliższa wspólnie zamieszkująca ze
   sprawcą → ściganie z urzędu (§ 4, kontekst przemocy domowej —
   patrz mod-KK-art207-przemoc-domowa.md)
```

⚠️ **Próg 7 dni jest kryterium MEDYCZNYM** (czas trwania naruszenia
czynności narządu / rozstroju zdrowia wg opinii biegłego), nie czasem
zwolnienia lekarskiego czy subiektywną oceną pokrzywdzonego — zawsze
wymaga opinii biegłego, nie ustalaj sam na podstawie samych dokumentów.

---

## ⭐⭐ DRZEWO Z.3 — BÓJKA I POBICIE (art. 158-159 KK) — dodane 2026-07-21

> Moduł OBIECYWAŁ w tytule "art. 148-162", ale treść urywała się na
> art. 156-157 — art. 158-162 UZUPEŁNIONE poniżej.

```
START: Czy w zdarzeniu brały udział CO NAJMNIEJ TRZY osoby (dwie
strony konfliktu, z których KAŻDA liczy min. 1 osobę, ŁĄCZNIE min. 3)?

├─ BÓJKA (art. 158 §1) — starcie WZAJEMNE, gdzie KAŻDY z uczestników
│  jest JEDNOCZEŚNIE napastnikiem i broniącym się (role NIEROZRÓŻNIALNE)
│  → udział w bójce, w KTÓREJ naraża się człowieka na bezpośrednie
│     niebezpieczeństwo utraty życia/ciężkiego uszczerbku → do 3 lat
│
├─ POBICIE (art. 158 §1, forma alternatywna) — JEDNA strona wyraźnie
│  NAPADA, DRUGA broni się (role ROZRÓŻNIALNE — napastnicy vs ofiara)
│  → TA SAMA sankcja co bójka (do 3 lat) — ustawa TRAKTUJE oba warianty
│     ŁĄCZNIE w jednym przepisie
│
├─ TYP KWALIFIKOWANY — SKUTEK w postaci CIĘŻKIEGO uszczerbku (art. 158
│  §2) → OD ROKU DO LAT 10
│  ⛔ NIE „6 m-cy – 8 lat" — to brzmienie SPRZED nowelizacji z 7.07.2022
│     (Dz.U. 2022 poz. 2600), obowiązującej od 1.10.2023
│
└─ TYP KWALIFIKOWANY — SKUTEK śmiertelny (art. 158 §3) → OD LAT 2 DO 15
   ⛔ NIE „1-10 lat" — jw., wartość sprzed 1.10.2023. Dolna granica 2 lata
      ma znaczenie procesowe: wyklucza warunkowe zawieszenie bez
      nadzwyczajnego złagodzenia i przesuwa ocenę przesłanek TA.
   ✅ [VER: arslege.pl/udzial-w-bojce-lub-pobiciu + inforlex (przypis
      nowelizacyjny [108]-[110] do art. 158), odczyt 2026-08-25]
   ⚠️ Typ podstawowy §1: od 3 miesięcy do lat 5 (też podniesiony tą samą
      nowelizacją)

⭐⭐ KLUCZOWA CECHA DOWODOWA — ODPOWIEDZIALNOŚĆ ZBIOROWA: przy bójce/
pobiciu ZAKOŃCZONYM ciężkim uszczerbkiem/śmiercią, GDY nie da się
USTALIĆ, KTÓRY KONKRETNIE z uczestników spowodował dany skutek —
WSZYSCY uczestnicy odpowiadają za sam UDZIAŁ w zdarzeniu zagrażającym
takim skutkiem (art. 158), NIEZALEŻNIE od indywidualnego "sprawstwa"
konkretnego ciosu — to WYJĄTEK od zasady indywidualizacji odpowiedzialności
karnej, uzasadniony TRUDNOŚCIĄ dowodową w chaosie bójki/pobicia

✅ **ZWERYFIKOWANE (2026-08-18, F-26):** Art. 159 KK (typ KWALIFIKOWANY
przez UŻYCIE broni/niebezpiecznego narzędzia w bójce/pobiciu) — treść:
"Kto, biorąc udział w bójce lub pobiciu człowieka, używa broni palnej,
noża lub innego podobnie niebezpiecznego przedmiotu, podlega karze
pozbawienia wolności od 6 miesięcy do lat 8." Źródła zbieżne (arslege.pl,
kruczek.pl, lukaszoles.pl, adwokat-skoczylas.pl, standardyprawa.pl).
⭐ **Rozróżnienie kluczowe dla obrony (doktryna, orzecznictwo cytowane w
standardyprawa.pl):** przepis wymaga **"UŻYCIA"**, nie samego posiadania
lub demonstrowania przedmiotu — samo trzymanie noża w kieszeni czy nawet
pokazanie go innym uczestnikom NIE wypełnia znamion; wymagane jest
funkcjonalne wykorzystanie (zadanie ciosu, strzał). Katalog "innych
podobnie niebezpiecznych przedmiotów" ustalany kazuistycznie w
orzecznictwie (żyletka, śrubokręt, nunczako, kastet, metalowy pręt,
stłuczona butelka "tulipan", młotek gumowy — wszystkie potwierdzone w
orzecznictwie SA/SN wg standardyprawa.pl, bez odczytu poszczególnych
sygnatur w tej sesji).
```

---

## ⭐⭐ DRZEWO Z.4 — NARAŻENIE NA NIEBEZPIECZEŃSTWO (art. 160 KK) — dodane 2026-07-21

```
START: Czy sprawca NARAZIŁ człowieka na BEZPOŚREDNIE niebezpieczeństwo
utraty życia albo CIĘŻKIEGO uszczerbku na zdrowiu?

├─ TYP PODSTAWOWY (art. 160 §1) → do 3 lat

├─ ⭐⭐ TYP KWALIFIKOWANY PRZEZ GWARANTA (art. 160 §2) — sprawca ma
│  PRAWNY, SZCZEGÓLNY obowiązek TROSKI o narażoną osobę (np. LEKARZ
│  pełniący DYŻUR/przyjmujący pacjenta, RODZIC wobec dziecka,
│  OPIEKUN) → do 5 lat
│  ⭐⭐⭐ TO KLUCZOWE ROZRÓŻNIENIE od art. 162 (nieudzielenie pomocy,
│  patrz DRZEWO Z.6 niżej): art. 162 dotyczy POWSZECHNEGO,
│  "ludzkiego" obowiązku solidarności (KAŻDY przechodzień), art. 160
│  §2 dotyczy ZAWODOWEGO/prawnego, SZCZEGÓLNEGO obowiązku opieki
│  (np. lekarz-GWARANT bezpieczeństwa WŁASNEGO pacjenta) — TA SAMA
│  bierność (zaniechanie pomocy) kwalifikuje się RÓŻNIE w zależności
│  od tego, CZY sprawcę łączyła z poszkodowanym więź GWARANCYJNA
│
├─ NIEUMYŚLNE narażenie (art. 160 §3) → grzywna/ograniczenie
│  wolności/do roku
│
└─ ⭐ TRYB ŚCIGANIA: art. 160 §1 i §2 — Z URZĘDU; art. 160 §3
   (NIEUMYŚLNE) — ⚠️ WYŁĄCZNIE NA WNIOSEK pokrzywdzonego (⚠️
   zweryfikuj dokładny tryb na ISAP — częsty punkt sporny)
```

---

## ⭐ DRZEWO Z.5 — NARAŻENIE NA ZARAŻENIE CHOROBĄ (art. 161 KK) — dodane 2026-07-21

> ⛔ **KOREKTA STRUKTURALNA 2026-08-18 (F-26):** poniższy opis operował na
> PRZESTARZAŁEJ wersji przepisu sprzed nowelizacji. Art. 161 KK został
> istotnie znowelizowany — **§1 i dawny §2 zostały POŁĄCZONE w jeden
> przepis**, a stary §2 jest dziś **UCHYLONY**. To odwrotność wcześniejszego
> założenia modułu (że HIV i inne choroby są nadal rozdzielone na dwa
> paragrafy o różnym zagrożeniu karą).

**Aktualna treść (Dz.U. 2025 poz. 383 t.j., źródła zbieżne: arslege.pl,
lexlege.pl, inforlex.pl):**
```
□ Art. 161 §1 — POŁĄCZONY typ: "Kto, wiedząc, że jest zarażony wirusem
  HIV lub dotknięty chorobą weneryczną lub zakaźną, ciężką chorobą
  nieuleczalną lub realnie zagrażającą życiu, naraża bezpośrednio inną
  osobę na zarażenie tym wirusem lub taką chorobą" → od 3 miesięcy do
  lat 5. HIV i inne choroby zakaźne/weneryczne/nieuleczalne/zagrażające
  życiu (np. COVID) mają TERAZ TĘ SAMĄ sankcję — dawne rozróżnienie
  zniesione nowelizacją (uzasadnienie MS: wyrównanie sankcji, wcześniej
  HIV było karane surowiej co budziło zarzut stygmatyzacji).
□ Art. 161 §2 — (UCHYLONY). NIE POWOŁYWAĆ jako odrębnego typu — to
  relikt numeracji sprzed nowelizacji.
□ Art. 161 §3 — typ KWALIFIKOWANY: narażenie WIELU osób → od roku do
  lat 10.
□ Art. 161 §4 — TRYB ŚCIGANIA: NA WNIOSEK pokrzywdzonego (potwierdzone
  wprost, nie wymaga dalszej weryfikacji).
```
⚠️ **Historia zmian (dla spraw o zdarzenia sprzed nowelizacji — stan
prawny w dacie czynu, nie w dacie orzekania, jest kluczowy):** źródła
wskazują na wcześniejszą wersję z odrębnymi §1 (HIV, do lat 3 pierwotnie,
później podniesione do lat 8 przez tarczę antykryzysową z 31.03.2020) i
§2 (inne choroby, grzywna/ograniczenie wolności/do roku) — **dokładne
daty wejścia w życie kolejnych wersji NIE ustalone w tej sesji**, istotne
tylko przy czynach z konkretnego okresu historycznego.

---

## ⭐⭐⭐ DRZEWO Z.6 — NIEUDZIELENIE POMOCY (art. 162 KK) — dodane 2026-07-21

> BEZPOŚREDNIA odpowiedź na pytanie użytkownika — dotąd CAŁKOWICIE
> nieobecne mimo obietnicy w tytule modułu.

### Elementy przestępstwa (art. 162 §1)

```
Odpowiedzialności karnej PODLEGA ten, kto:
  1) WIDZI (ma wiedzę o) człowieku ZNAJDUJĄCYM SIĘ w położeniu
     GROŻĄCYM BEZPOŚREDNIM niebezpieczeństwem UTRATY ŻYCIA albo
     CIĘŻKIEGO uszczerbku na zdrowiu (pojęcie "ciężkiego uszczerbku"
     — DEFINIOWANE w art. 156 §1 KK, patrz DRZEWO Z.2 wyżej w TYM
     module: pozbawienie wzroku/słuchu/mowy/zdolności płodzenia,
     inne ciężkie kalectwo, choroba REALNIE zagrażająca życiu,
     trwała ISTOTNA niezdolność do pracy w zawodzie)
  2) MAJĄC MOŻLIWOŚĆ udzielenia pomocy — NIE ROBI tego
  3) Możliwość ta ISTNIEJE BEZ narażenia SIEBIE LUB innej osoby na
     niebezpieczeństwo utraty życia/ciężkiego uszczerbku
□ SANKCJA: pozbawienie wolności DO 3 LAT
□ ⭐⭐ PRZESTĘPSTWO POWSZECHNE — obowiązek dotyczy KAŻDEGO (nie tylko
  określonej grupy zawodowej) — to WYRAZ ogólnej, "ludzkiej"
  solidarności, w PRZECIWIEŃSTWIE do art. 160 §2 (obowiązek
  GWARANTA, patrz DRZEWO Z.4 wyżej)
□ ⭐ Przepis NIE ULEGŁ ZMIANIE od 1997 r. — RZADKI w polskim prawie
  przypadek STABILNOŚCI (⚠️ i tak zweryfikuj aktualny t.j. na ISAP)
```

### ⭐ Kontratyp — kiedy brak reakcji NIE JEST przestępstwem (art. 162 §2)

```
NIE POPEŁNIA przestępstwa, kto NIE UDZIELA pomocy, DO KTÓREJ:
  1) KONIECZNE jest poddanie się ZABIEGOWI LEKARSKIEMU (np. laik NIE
     MA obowiązku wykonywać czynności WYMAGAJĄCYCH wiedzy/uprawnień
     medycznych)
  2) MOŻLIWA jest NIEZWŁOCZNA pomoc ze strony INSTYTUCJI lub osoby DO
     TEGO POWOŁANEJ (np. na miejscu JEST już RATOWNIK/lekarz/służby —
     dublowanie działań przez przypadkowego świadka NIE jest wymagane)
```

### ⭐⭐ Zasady interpretacyjne — praktyczne niuanse

```
⭐ ZAKAZ "OCENIANIA" ofiary jako przesłanki zwalniającej: prawo NIE
POZWALA świadkowi usprawiedliwiać bierności twierdzeniem, że
poszkodowany "sam się w to wpakował" lub "chciał się zabić" —
obowiązek ochrony życia MA charakter BEZWZGLĘDNY, NIEZALEŻNY od oceny
"winy" ofiary za własne położenie

⭐ PRÓG "ciężkiego uszczerbku" WYŁĄCZA drobne obrażenia — obowiązek z
art. 162 NIE POWSTAJE, gdy poszkodowany doznał JEDYNIE lekkich obrażeń
(poniżej progu z art. 156 §1) — sprawdź ZAWSZE, czy sytuacja
OBIEKTYWNIE odpowiada temu progowi, nie polegaj na SAMEJ subiektywnej
ocenie zgłaszającego

⭐⭐⭐ ROZGRANICZENIE od art. 160 §2 (GWARANT) — NAJWAŻNIEJSZA różnica
w PRAKTYCE: LEKARZ pełniący DYŻUR (np. na SOR), przyjmujący W
przychodni, JADĄCY na wizytę DOMOWĄ, lub OPIEKUJĄCY SIĘ pacjentami W
szpitalu — jest wobec TYCH pacjentów GWARANTEM bezpieczeństwa. JEŚLI
TAKI lekarz ZANIECHA działania wobec WŁASNEGO pacjenta — odpowiada NIE
za art. 162 (łagodniejszy, do 3 lat), lecz za ZNACZNIE SUROWSZY art.
160 §2 (do 5 lat) — TEN SAM przypadkowy PRZECHODZIEŃ, obserwujący
OBCĄ osobę w potrzebie, BEZ więzi gwarancyjnej — odpowiada z
ŁAGODNIEJSZEGO art. 162

Checklist praktyczny:
□ Czy sytuacja OBIEKTYWNIE osiągała próg "ciężkiego uszczerbku" (art.
  156 §1) — jeśli NIE, brak obowiązku z art. 162 w OGÓLE
□ Czy klient MÓGŁ pomóc BEZ narażenia SIEBIE lub INNYCH — kluczowa
  przesłanka WYŁĄCZAJĄCA odpowiedzialność
□ Czy pomoc WYMAGAŁA zabiegu LEKARSKIEGO (poza możliwościami LAIKA) —
  kontratyp z §2
□ Czy NA MIEJSCU była już OBECNA osoba/instytucja POWOŁANA do
  udzielenia pomocy (ratownik, lekarz, służby) — kontratyp z §2
□ Czy klienta ŁĄCZYŁA z poszkodowanym więź GWARANCYJNA (lekarz-
  pacjent, rodzic-dziecko, opiekun-podopieczny) — jeśli TAK, sprawdź
  ZAMIAST tego SUROWSZY art. 160 §2, NIE łagodniejszy art. 162
□ PRAKTYCZNA rekomendacja dla ŚWIADKA w razie wątpliwości: MINIMUM to
  ZADZWONIENIE pod 112 — TO SAMO w sobie zwykle WYPEŁNIA obowiązek
  "udzielenia pomocy" bez narażania się, NAWET bez fizycznej interwencji
```

---

## 3. TABELA SZYBKIEGO ODCZYTU

| Typ | Przepis | Zagrożenie | Tryb |
|---|---|---|---|
| Zabójstwo podstawowe | art. 148 §1 | 10-30 lat / dożywocie (⚠️ usunięto "25 lat" — kategoria zniesiona 1.10.2023) | z urzędu |
| Zabójstwo kwalifikowane | art. 148 §2-3 | 15-30 lat / dożywocie (⚠️ było błędnie "12-30 lat, 25 lat") | z urzędu |
| Dzieciobójstwo | art. 149 | 3 m-ce – 5 lat | z urzędu |
| Zabójstwo w afekcie | art. 148 §4 | 1-10 lat | z urzędu |
| Eutanazja | art. 150 | 3 m-ce – 5 lat (możliwe odstąpienie) | z urzędu |
| Pomoc/namowa do samobójstwa | art. 151 | 3 m-ce – 5 lat | z urzędu |
| Ciężki uszczerbek (umyślnie) | art. 156 § 1 | 3-20 lat | z urzędu |
| Średni uszczerbek | art. 157 §1 | 3 m-ce – 5 lat | z urzędu |
| Lekki uszczerbek | art. 157 §2 | do 2 lat | prywatnoskargowy (wyjątek: przemoc domowa) |

⚠️ WSZYSTKIE zagrożenia do potwierdzenia na isap.sejm.gov.pl przed
użyciem w piśmie (PRAWO-HARDGATE).

---

## CROSS-REFERENCJE

- Nieumyślne spowodowanie śmierci w wypadku drogowym → `mod-PRD-nowe-przestepstwa-drogowe-BRD.md`
  (lex specialis dla kontekstu ruchu drogowego, nie stosuj art. 155 wprost).
- Uszczerbek na zdrowiu w kontekście przemocy domowej (znęcanie się,
  art. 207) → `mod-KK-art207-przemoc-domowa.md`.
- Nieletni sprawca zabójstwa/ciężkiego uszczerbku — szczególny reżim
  wiekowy → `mod-KK-art10-odpowiedzialnosc-nieletnich.md` DRZEWO N.1.
- Kontratypy mogące wyłączyć bezprawność (obrona konieczna, stan
  wyższej konieczności) → `mod-KK-kwalifikator-karnomaterialny.md`
  DRZEWO K.1/K.2.
- ⚠️ DODANE 2026-07-30 (na żądanie użytkownika) — ŚMIERTELNY WYPADEK
  PRZY PRACY, aspekt KARNY: jeśli śmierć pracownika nastąpiła wskutek
  niedopełnienia obowiązków BHP przez osobę odpowiedzialną — DWA
  MOŻLIWE, ODRĘBNE reżimy prawne, NIE MYL ICH:
  (a) art. 220 KK ("narażenie życia/zdrowia pracownika") — stosuje
      się TYLKO do samego NARAŻENIA na niebezpieczeństwo (skutek =
      stan zagrożenia, NIE sama śmierć) — do 3 lat (umyślnie) / do
      roku (nieumyślnie)
  (b) jeśli śmierć FAKTYCZNIE NASTĄPIŁA wskutek naruszenia BHP — TO
      NIE jest odrębny typ przestępstwa "wypadkowego" — stosuje się
      WPROST **art. 155 KK** (nieumyślne spowodowanie śmierci, 3
      miesiące — 5 lat) — TA SAMA podstawa co przy każdej innej
      śmierci nieumyślnej, tylko z odpowiedzialną osobą = pracodawca/
      osoba kierująca BHP zamiast np. kierowcy
  → Jeśli BRAK dowodu na bezpośredni związek przyczynowy MIĘDZY
    naruszeniem a zagrożeniem życia (art. 220 wymaga BEZPOŚREDNIOŚCI
    niebezpieczeństwa) — możliwa WYŁĄCZNIE odpowiedzialność za
    WYKROCZENIE z art. 283 §1 Kodeksu pracy (nie przestępstwo)
  → Pełne aspekty ADMINISTRACYJNE/pracownicze (klasyfikacja wypadku,
    obowiązki zgłoszeniowe pracodawcy, świadczenia dla rodziny) →
    `dr-04-prawo-pracy-zus-swiadczenia/modules/mod-wypadek-przy-pracy-choroba-zawodowa.md` — TEN moduł
    (dr-03) dostarcza WYŁĄCZNIE aspekt KARNY, unikaj duplikacji
  Potwierdzone w 6+ zgodnych źródłach, w tym PIP (pip.gov.pl, Rząd 1)
  i orzecznictwem SN (V KK 64/12).

  ⭐ DODANE 2026-07-30 (na żądanie użytkownika) — "CZYSTY" NIESZCZĘŚLIWY
  WYPADEK (np. awaria maszyny, BEZ naruszenia BHP): jeśli BRAK
  dowodów na niedopełnienie obowiązku BHP (a więc BRAK podstaw do
  art. 220/155 KK powyżej) — sprawa NIE KOŃCZY SIĘ tym samym
  wnioskiem po stronie CYWILNEJ. Odpowiedzialność karna (wymaga
  WINY) i odpowiedzialność cywilna na ZASADZIE RYZYKA (art. 435 KC —
  NIE wymaga winy) to DWA NIEZALEŻNE reżimy — BRAK winy = brak
  przestępstwa, ALE NIE oznacza automatycznie braku obowiązku
  odszkodowawczego. Pełna analiza (w tym KLUCZOWE ustalenie: sama
  "awaria maszyny" TYPOWO NIE kwalifikuje się jako "siła wyższa"
  wyłączająca odpowiedzialność) → DR-02, `mod-KC-cywilne-
  zobowiazania-odpowiedzialnosc.md`, sekcja "Szczególne podstawy
  odpowiedzialności (zasada ryzyka)".
